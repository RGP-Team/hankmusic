<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App;
use App\Http\Requests;

class IndexController extends Controller
{
	protected $settings;	
	public function __construct()
	{
		$this->settings = \App\Models\Setting::find(1);
	}
	
	public function index()
	{

		return view('index', compact('data'));
	}
	
	public function pageNotFound()
	{
		////App::abort(404);
		return view('errors.404');
	}
	
}
