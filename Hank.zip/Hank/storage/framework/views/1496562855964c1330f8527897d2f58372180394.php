<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-9">
						<div class="row">
							<div class="col-md-12">
								<a name="submit-form"></a>
								<h3 class="breadcrum"><?php echo e(CustomHelper::lang('lang-chat-section')); ?></h3>
							</div>
						</div>
						<?php if( ! Auth::guest()): ?>
						<div class="submit-form-container">
							<div class="row">
								<div class="col-md-12">
									<h3 class="submit-a-post"><?php echo e(CustomHelper::lang('lang-welcome')); ?> <?php echo e(CustomHelper::lang($channel->id, true)); ?> <?php echo e(CustomHelper::lang('lang-channel')); ?> <br/><small></small></h3>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-12 chat-wrapper form-field">
											<div class="img-responsive form-control channel-message-container">
												<div class="messages-container">
													<ul class="messages"></ul>
												</div>
											</div>
										</div>
									</div>
									<div class="row chat-action-container top-margin-10 bottom-margin-20">
										<input type="hidden" name="category_id" value="<?php echo e($channel->id); ?>">
										<input type="hidden" name="chat-csrf" value="<?php echo e(csrf_token()); ?>">
										<div class="col-md-9 bottom-margin-10">
											<input type="text" class="form-control channel-message" name="message" autocomplete="off" />
											<div class="sending-container top-margin-5">
												<span class="sending"></span>
											</div>
										</div>
										<div class="col-md-3 text-right">
											<button type="button" onclick="sendChatMessage(this)" data-url="<?php echo e(url('/')); ?>/<?php echo e($channel->slug); ?>/channel/message" class="channel-btn"><?php echo e(CustomHelper::lang('lang-send')); ?></button>
										</div>
									</div>
								</div>
							</div>
							
							
							</form>
						</div>
						<?php endif; ?>
					</div>
					<div class="col-md-3">
						<div class="channel-users">
							<h4><?php echo e(CustomHelper::lang('lang-channel-users')); ?></h4>
							<ul>
								<li>
									<div class="users-container">
										<div class="profile">
										<?php if($users->count()): ?>
											<?php foreach($users as $user): ?>
											<div class="dropdown user-profile">	
												<?php if($user->photo): ?>
													<?php ($profile_photo = $user->photo->url); ?>
													<img src="<?php echo e($profile_photo); ?>" alt="">
												<?php else: ?>
													<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
												<?php endif; ?>
												<a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($user->id); ?>"><?php echo e(ucwords($user->first_name)); ?> <?php echo e(ucwords($user->last_name)); ?></a>
											</div>
											<?php endforeach; ?>
										<?php endif; ?>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>