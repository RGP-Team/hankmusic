<div class="row">
	<div class="col-md-12 admin-data-table bottom-margin-50">
		<div class="row bottom-margin-40">
			<div class="col-md-12">
				<h3><?php echo e($data->heading); ?> <?php if($data->entity !== 'comments'): ?>&nbsp;<button type="submit" onclick="location.href='<?php echo e(url('/admin')); ?>/<?php echo e($data->entity); ?>/new'" class="btn btn-sm btn-primary">New</button><?php endif; ?></h3>
				<?php if(session()->has('success_message')): ?>
					<div class="alert alert-success">
						<?php echo e(session()->get('success_message')); ?>

					</div>
				<?php endif; ?>
				<?php if(count($errors->all())): ?>
					<div class="alert alert-danger">
						<ul>
						<?php foreach($errors->all() as $error): ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; ?>
						</ul>
					</div>
				<?php else: ?>
					<?php if(session()->has('error_message')): ?>
					<div class="alert alert-danger">
						<?php echo e(session()->get('error_message')); ?>

					</div>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<?php echo $__env->make('admin.includes.table-only', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
			</div>
		</div>
	</div>
</div>
