<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-40">
								<div class="col-md-12">
									<h3>Banners<br/><small>Banner sizes are predefined based on the homepage's design layout</small></h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-9">																						
											<!-- Subscription Plans -->
											<a name="banner-form-location"></a>			
											<div class="row">
												<div class="col-md-12 bottom-margin-30">
													<button id="toggle-banner" class="btn btn-default margin-t-5"><i class="fa fa-edit"></i> <span>New Banner</span></button>
												</div>
											</div>
											
											<div class="banner-container noshow bottom-margin-50">
												<?php echo Form::open(array('route' => 'admin.banners.save', 'method' => 'POST', 'id' => 'banner-form')); ?>

												<input type="hidden" name="photo">
												<input type="hidden" name="banner_id">
												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Title</label>
												  <div class="col-sm-9">
													<input type="text" name="title" class="form-control" placeholder="Your Banner Title">
												  </div>
												</div>
												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Sub Title</label>
												  <div class="col-sm-9">
													<input type="text" name="sub_title" class="form-control" placeholder="Your Banner Sub Title (optional)">
												  </div>
												</div>
												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Category</label>
												  <div class="col-sm-9">
													<select id="banner-category" name="category_id" class="form-control">
													  <option value="">-- Choose category</option>
													  <?php if(isset($data)): ?>
														<?php foreach($data->categories as $category): ?>
															<?php ($selected = ''); ?>
															<?php if(isset($data->info)): ?>
																<?php if((int)$data->info->category->parent->id === (int)$category->id): ?>
																	<?php ($selected = 'selected'); ?>
																<?php endif; ?>
															<?php endif; ?>
															
															<option value="<?php echo e($category->id); ?>" <?php echo e($selected); ?>><?php echo e($category->name); ?></option>
														<?php endforeach; ?>
													  <?php endif; ?>
													</select>
												  </div>
												</div>
												<div class="form-group row">
													<label class="col-sm-3 col-form-label">Banner Size</label>
													<div class="col-sm-9">
														
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="banner_size" value="630x350">
																630 x 350
															  </label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="banner_size" value="945x106">
																945 x 106
															  </label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="banner_size" value="368x256">
																368 x 256
															  </label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="banner_size" value="300x106">
																300 x 106
															  </label>
															</div>
														
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-3 col-form-label">Type</label>
													<div class="col-sm-9">
														
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="type" value="advertisement">
																Advertisement
															  </label>
															</div>
															<div class="form-check">
															<label class="form-check-label">
																<input type="radio" class="form-check-input" name="type" value="content" checked>
																Content &nbsp;<small>(plain image content for display)</small>
															  </label>
															</div>
														
													</div>
												</div>	
												<div class="form-group current-banner-container row noshow">
													<label class="col-sm-3 col-form-label">Current Banner Image<br/><small>(upload new image to override current)</small></label>
													<div class="col-sm-9">
														<img id="current-banner" class="img-responsive">
													</div>
												</div>
												<?php echo Form::close(); ?>

												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Banner Image</label>
												  <div class="col-sm-9">
													
														<?php echo Form::open(array('route' => 'admin.photos.upload', 'method' => 'POST', 'id' => 'photo-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

															<button id="upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> Upload Image</button>
															<div id="img-thumb-preview" class="noshow">
															  <span class="processing-msg" style="display:none;">Processing, please wait...</span>
															  <div class="img-thumbnail">
																<img id="img-thumb" class="user size-lg img-responsive photo-select" src="">
															  </div>
															</div>
														<?php echo Form::close(); ?>

													
												  </div>
												</div>
												<div class="row">
													<div class="col-md-12 top-margin-20 text-right">
														<button onclick="jQuery('#banner-form').get(0).submit()" class="btn btn-primary">Save Banner</button>
													</div>
												</div>
											</div>														
											
											
											<div class="row">
												<div class="col-md-12">
													
													<table id="datatable" data-entity="banners" class="table table-striped table-bordered">
													  <thead>
														<tr>
														  <?php foreach($data->headers as $header): ?>
															<?php if($header === 'category_id'): ?>
																<?php ($header = 'category'); ?>
															<?php endif; ?>
															<?php if($header !== 'url'): ?>
															<th><?php echo e(ucwords(str_replace('_', ' ', $header))); ?></th>
															<?php endif; ?>
														  <?php endforeach; ?>
														  <th id="action" width="15%">Action</th>
														</tr>
													  </thead>
													  <tbody ng-model="listings">
															<?php foreach($data->collection as $item): ?>																			
															<tr class="table-row" data-id="<?php echo e($item->id); ?>" data-item="<?php echo e($item); ?>" data-entity="banners">
																<?php foreach($data->headers as $header): ?>
																	<?php ($content = $item[$header]); ?>
																	<?php if($header === 'category_id'): ?>
																		<?php ($content = $item->category->name); ?>
																	<?php endif; ?>
																	<?php if($header !== 'url'): ?>
																	<td><?php echo e($content); ?></td>
																	<?php endif; ?>
																<?php endforeach; ?>																			
																<td align="center" class="action-item">
																	<a href="javascript://" class="action-button" data-action="delete" data-id="<?php echo e($item->id); ?>" data-entity="banners"><i class="fa fa-trash-o action-icons"></i> Delete</a>
																</td>
															</tr>
															<?php endforeach; ?>																		
													  </tbody>
													</table>	
													<a id="gotoLocation" href="#banner-form-location"></a>
													
												</div>
											</div>
																															
											<!-- /Subscription Plans -->
										</div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>