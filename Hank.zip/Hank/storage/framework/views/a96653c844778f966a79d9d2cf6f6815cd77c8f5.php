<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-your-messages')); ?></h4>
								</div>
								<?php if(session()->has('success_message')): ?>
									<div class="alert alert-success">
										<?php echo e(session()->get('success_message')); ?>

									</div>
								<?php endif; ?>
								<?php if(count($errors->all())): ?>
									<div class="alert alert-danger">
										<ul>
										<?php foreach($errors->all() as $error): ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; ?>
										</ul>
									</div>
								<?php else: ?>
									<?php if(session()->has('error_message')): ?>
									<div class="alert alert-danger">
										<?php echo e(session()->get('error_message')); ?>

									</div>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
						<?php if($messages->count()): ?>
							<?php foreach($messages as $item): ?>
								<?php ($name = 'System Notification'); ?>
								<?php if((int)$item->source_id > -1): ?>
									<?php ($user = $item->source); ?>
									<?php ($name = $user->first_name . ' ' . $user->last_name); ?>
								<?php endif; ?>
								
								<div class="row pad-bottom-bold bottom-line pad-top adjust-row-margin messages <?php if(! $item->is_read): ?><?php echo e('message-unread'); ?><?php endif; ?>">
									<div class="col-md-2 user-profile text-center">
									<?php if((int)$item->source_id > -1): ?>
										<?php if($user->photo): ?>
											<?php ($profile_photo = $user->photo->url); ?>
											<img src="<?php echo e($profile_photo); ?>" alt="">
										<?php else: ?>
											<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
										<?php endif; ?>
									<?php else: ?>
										&nbsp;
									<?php endif; ?>
									</div>
									<div class="col-md-10 no-pad-left adjust-bottom">
										<div class="topic-title item-title"><?php echo e($name); ?><span class="topic-hour"><?php echo e(CustomHelper::lang('lang-posted')); ?> <?php echo e(CustomHelper::show_elapsed_time($item->created_dt)); ?></span></div>
										<div class="col-md-8 no-pad-left">
											<p>
											<?php echo nl2br(e($item->message)); ?>

											</p>
											<?php if(! $item->is_read): ?>
											<div class="button-container">
												<form method="POST" action="<?php echo e(url('/messages/marked')); ?>">
												<?php echo csrf_field(); ?>

												<input type="hidden" name="message_id" value="<?php echo e($item->id); ?>" />
												<button class="action-buttons share"><i class="fa fa-check"></i> <?php echo e(CustomHelper::lang('lang-marked-as-read')); ?></button>
												</form>
											</div>
											<?php endif; ?>
										</div>
										<div class="col-md-1"></div>
										<div class="col-md-3 text-right no-pad-right">
											<?php if((int)$item->source_id > -1): ?>
											<div class="button-container">
												<input type="hidden" name="source_id" value="<?php echo e(Auth::user()->id); ?>" />
												<input type="hidden" name="target_id" value="<?php echo e($user->id); ?>" />
												<a href="javascript://" onclick="sendMessage(this)" class="action-buttons share"><i class="fa fa-mail-reply"></i> <?php echo e(CustomHelper::lang('lang-reply')); ?></a>
											</div>
											<?php endif; ?>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						<?php else: ?>
							<div class="row pad-bottom-bold min-height-300 adjust-row-margin top-margin-40">
								<div class="col-md-12 text-center top-margin-40">
									<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

								</div>
							</div>
						<?php endif; ?>
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>