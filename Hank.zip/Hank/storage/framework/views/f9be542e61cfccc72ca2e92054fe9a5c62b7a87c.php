<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 public-articles">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-12">
								<div class="bottom-margin-40">
									<h3><?php echo e(CustomHelper::lang('lang-latest-articles')); ?></h3>
								</div>
							</div>
						</div>
						<?php if($articles->count()): ?>
							<?php foreach($articles as $article): ?>
							<div class="row pad-bottom-bold bottom-margin-20">
								<div class="col-md-2 text-center">
									<div class="article-thumbnail bg-primary">
										<a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore">
											<?php ( $doc = new DOMDocument() ); ?>
											<?php ( $doc->loadHTML($article->content) ); ?>
											<?php ( $img = $doc->getElementsByTagName('img')->item(0) ); ?>	
											
											<?php if(! empty($img)): ?>
												<?php ($src = $img->getAttribute('src')); ?>
												<img class="img-responsive latest-post-item" src="<?php echo e($src); ?>" border="0" />
											<?php else: ?>
												<img class="img-responsive latest-post-item" src="<?php echo e(URL::asset('images/no-image.png')); ?>" border="0" />
											<?php endif; ?>		
										</a>
									</div>
								</div>
								<div class="col-md-10 no-pad-left adjust-bottom">
									<div class="topic-title item-title"><a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore"><?php echo e(strtoupper($article->title)); ?></a><span class="topic-hour"><?php echo e(CustomHelper::lang('lang-posted')); ?> <?php echo e(CustomHelper::show_elapsed_time($article->created_dt)); ?></span></div>
									<span class="uploaded-by"><?php echo e(CustomHelper::lang('lang-by')); ?> <?php echo e($article->user->first_name); ?> <?php echo e($article->user->last_name); ?>, <?php echo e($article->views); ?> <?php echo e(CustomHelper::lang('lang-views')); ?></span>
									<p>
										<?php ($content = strip_tags($article->content)); ?>
										<?php if(strlen($content) > 280): ?>
											<?php ($content = substr($content, 0, 280) . '...'); ?>
										<?php endif; ?>
										
										<?php echo nl2br(e($content)); ?> <a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore"><small><?php echo e(CustomHelper::lang('lang-read-more')); ?></small></a>
									</p>
									<div class="col-md-12 text-right">
										<div class="social-media-buttons text-primary">
											<?php echo $__env->make('pages.partials._social_media_buttons', ['article' => $article], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						<?php else: ?>
							<div class="row pad-bottom-bold min-height-200">
								<div class="col-md-12 text-center top-margin-30">
									<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

								</div>
							</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-md-12">
								<?php echo e($articles->links()); ?>

							</div>
						</div>
						
						
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>