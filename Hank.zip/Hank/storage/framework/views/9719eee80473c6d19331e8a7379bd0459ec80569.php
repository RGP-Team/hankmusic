<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>CGNetworks Admin</title>
    <?php echo e(Html::style('bootstrap/css/bootstrap.min.css')); ?>

    <?php echo e(Html::style('font-awesome/css/font-awesome.min.css')); ?>

	<?php echo e(Html::style('css/magnific-popup.css')); ?>

	<?php echo e(Html::style('css/dataTables.bootstrap.min.css')); ?>

	<?php echo e(Html::style('css/bootstrap-dialog.min.css')); ?>

	
	<?php echo e(Html::style('css/admin.css')); ?>

</head>
<body>
    <nav id="navbar-white" class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="navbar-header">
      <button href="#menu-toggle" class="slidebar-toggle" id="menu-toggle">
        <span class="sr-only">Toggle sidebar</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <span><a id="logo" href="<?php echo e(url('/admin/dashboard')); ?>" border="0"><img src="<?php echo e(URL::asset('images/logo-200.png')); ?>" alt="CG Networks Logo" border="0" /></a></span>
    </div>
    
    <div class="navbar-collapse collapse">
    
      <div class="container-fluid">
        <ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
			  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-user"></i> Welcome, <?php echo e(Auth::guard('admins')->user()->name); ?> <b class="caret"></b></a>
			  <ul class="dropdown-menu">
				<li><a href="<?php echo e(url('/admin/admins/edit')); ?>/<?php echo e(Auth::guard('admins')->user()->id); ?>"><i class="fa fa-globe"></i> Edit Account</a></li>
				<li><a href="<?php echo e(url('/admin/logout')); ?>"><i class="fa fa-power-off"></i> Logout</a></li>         
			  </ul>
			</li>
        </ul>
      </div>
    </div>
  </nav>  
    


  <div id="wrapper">    
	<div id="slidebar-white" class="slidebar-nav">
      <nav id="navbar-white" class="navbar navbar-default" role="navigation">
        <ul class="nav navbar-nav">
          <li class="dashboard-brand"><a class="navbar-brand dashboard" href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Administration</a></li>
          <?php if(Auth::guard('admins')->user()->can_manage_post): ?>
		  <li class="dropdown">
			<a id="posts" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list"></i> Posts <b class="caret"></b></a>
			  <ul class="dropdown-menu"> 
				<li><a id="all-posts" href="<?php echo e(url('/admin/posts')); ?>"><i class="fa fa-dot-circle-o"></i> All Posts</a></li>
				<li><a id="posts-new" href="<?php echo e(url('/admin/posts/new')); ?>"><i class="fa fa-dot-circle-o"></i> Add New</a></li>
				<li><a id="all-comments" href="<?php echo e(url('/admin/comments')); ?>"><i class="fa fa-dot-circle-o"></i> Comments</a></li>
			  </ul>
		  </li>
		  <?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_user || Auth::guard('admins')->user()->can_manage_admin): ?>
        <li class="dropdown">
          <a id="users" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-group"></i> Users <b class="caret"></b></a>
          <ul class="dropdown-menu">
		    <?php if(Auth::guard('admins')->user()->can_manage_user): ?>
            <li><a id="all-users" href="<?php echo e(url('/admin/users')); ?>"><i class="fa fa-dot-circle-o"></i> All Users</a></li>
            <li><a id="users-new" href="<?php echo e(url('/admin/users/new')); ?>"><i class="fa fa-dot-circle-o"></i> Add New</a></li>
			<?php endif; ?>
			<?php if(Auth::guard('admins')->user()->can_manage_admin): ?>
			<li><a id="all-admins" href="<?php echo e(url('/admin/admins')); ?>"><i class="fa fa-dot-circle-o"></i> Site Admins</a></li>
			<?php endif; ?>
          </ul>
        </li>
		<?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_category): ?>
		<li class="dropdown">
          <a id="categories" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cubes"></i> Categories <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a id="all-categories" href="<?php echo e(url('/admin/categories')); ?>"><i class="fa fa-dot-circle-o"></i> All Categories</a></li>
            <li><a id="categories-new" href="<?php echo e(url('/admin/categories/new')); ?>"><i class="fa fa-dot-circle-o"></i> Add New</a></li>
          </ul>
        </li>
		<?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_approval): ?>
		<li class="dropdown">
          <a id="approvals" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-check-square-o"></i> Pending Approvals <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a id="approval-freelancer" href="<?php echo e(url('/admin/approval/freelancers')); ?>"><i class="fa fa-dot-circle-o"></i> Freelancers</a></li>
            <li><a id="approval-writer" href="<?php echo e(url('/admin/approval/writers')); ?>"><i class="fa fa-dot-circle-o"></i> Writers</a></li>
			<li><a id="approval-video" href="<?php echo e(url('/admin/approval/videos')); ?>"><i class="fa fa-dot-circle-o"></i> Videos</a></li>
          </ul>
        </li>
		<?php endif; ?>
		<li class="dropdown">
          <a id="subscribers" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope-o"></i> Subscribers <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a id="all-subscribers" href="<?php echo e(url('/admin/subscribers')); ?>"><i class="fa fa-dot-circle-o"></i> Newsletter</a></li>
          </ul>
        </li>
		<li class="dropdown">
          <a id="settings" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-gears"></i> Settings <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a id="general-settings" href="<?php echo e(url('/admin/settings')); ?>"><i class="fa fa-dot-circle-o"></i> General</a></li>
			<li><a id="banner-setting" href="<?php echo e(url('/admin/banners')); ?>"><i class="fa fa-dot-circle-o"></i> Banners</a></li>
			<li><a id="multi-language-setting" href="<?php echo e(url('/admin/languages')); ?>"><i class="fa fa-dot-circle-o"></i> Languages</a></li>
          </ul>
        </li>
		<li class="dropdown">
          <a href="<?php echo e(url('/admin/logout')); ?>" class="dropdown-toggle"> <i class="fa fa-power-off"></i> &nbsp;Logout </a>
        </li>
        </ul>
      </nav>
    </div>
    <main id="page-wrapper6">
      <?php echo $__env->yieldContent('content'); ?>
    </main>
  </div>
	<input type="hidden" id="menu" name="menu" value="<?php echo e($data->menu); ?>" />
	<input type="hidden" id="sub_menu" name="sub_menu" value="<?php echo e($data->sub_menu); ?>" />
	
    <?php echo e(Html::script('js/jquery-1.12.3.min.js')); ?>

    <?php echo e(Html::script('bootstrap/js/bootstrap.min.js')); ?>

	<?php echo e(Html::script('js/jquery.dataTables.min.js')); ?>

	<?php echo e(Html::script('js/dataTables.bootstrap.min.js')); ?>

	<?php echo e(Html::script('js/jquery.magnific-popup.min.js')); ?>

	<?php echo e(Html::script('js/dropzone.js')); ?>

	<?php echo e(Html::script('js/bootstrap-dialog.min.js')); ?>

    <?php echo e(Html::script('js/admin.js')); ?>

	
	<script>
		jQuery(document).ready(function(){
			
			jQuery('.table-row td:not(:last-child)').on('click', function(){
				var id = jQuery(this).parent().attr('data-id');
				var entity = jQuery(this).parent().attr('data-entity');
				var item = jQuery(this).parent().attr('data-item');
				
				if (entity === 'plans')
				{
					if (item.length > 0) 
					{
						item = jQuery.parseJSON( item );
						form = jQuery('form#plan-form');
						
						form.find('input[name="plan_id"]').val(item.id);
						form.find('input[name="title"]').val(item.title);
						form.find('textarea[name="description"]').val(item.description);
						form.find('input[name="page_limit"]').val(item.page_limit);
						form.find('input[name="word_limit"]').val(item.post_word_limit);
						form.find('input[name="amount"]').val(item.amount);
						
						if (jQuery('button#toggle-plan').find('span').html() === 'New Plan') jQuery('button#toggle-plan').trigger('click');
						location.href = '#plan-form-location';
					}
				}else{
					if (entity === 'banners')
					{
						if (item.length > 0) 
						{
							item = jQuery.parseJSON( item );
							form = jQuery('form#banner-form');
							
							form.find('input[name="banner_id"]').val(item.id);
							form.find('input[name="title"]').val(item.title);
							form.find('input[name="sub_title"]').val(item.sub_title);
							form.find('select[name="category_id"]').val(item.category_id);
							form.find('input[name="banner_size"][value="' + item.width + 'x' + item.height + '"]').prop("checked", true);
							form.find('input[name="type"][value="' + item.type + '"]').prop("checked", true);
							form.find('img#current-banner').attr('src', item.url);
							form.find('.current-banner-container').show();
							
							if (jQuery('button#toggle-banner').find('span').html() === 'New Banner') jQuery('button#toggle-banner').trigger('click');
							location.href = '#banner-form-location';
						}
					}else{
						if (entity !== 'subscribers') preview(id, entity);
					}
				}
			});
			
			jQuery('.table-row a.action-button').on('click', function(){
				var action = jQuery(this).attr('data-action');
				var id = jQuery(this).attr('data-id');
				var entity = jQuery(this).attr('data-entity');
				
				switch (action)
				{
					case 'delete':
						deleteEntity(id, entity);
						break;
				}
			});
			
			setTimeout(function(){
				var notice = jQuery('div.alert.alert-success');
				if (notice.is(':visible')) notice.fadeOut(1000, 'linear');
					
				var notice2 = jQuery('div.alert.alert-danger');
				if (notice2.is(':visible')) notice2.fadeOut(1000, 'linear');
			}, 5000);
			
			jQuery('#datatable').dataTable();
			
			jQuery('#toggle-plan').on('click', function(){
				if (jQuery('.plan-container').is(':visible'))
				{
					jQuery('.plan-container').hide();
					jQuery(this).find('span').html('New Plan');
				}else{
					jQuery(this).find('span').html('Close Form');
					jQuery('.plan-container').show();					
				}
			});
			
			jQuery('#toggle-banner').on('click', function(){
				if (jQuery('.banner-container').is(':visible'))
				{
					jQuery('.banner-container').hide();
					jQuery(this).find('span').html('New Banner');
				}else{
					jQuery(this).find('span').html('Close Form');
					jQuery('.banner-container').show();	
					loadDropZone();
				}
			});
			
			
			jQuery('#post-category').on('change', function(){
				
				var id = jQuery(this).val();
				var parent = jQuery(this).parent();
				var tm = new Date().getTime();
				var url = "<?php echo e(url('/')); ?>/admin/topics/load/" + id + "?" + tm;
				
				jQuery('option', jQuery('#post-topics')).not(':eq(0)').remove();
				if (id.length > 0)
				{
					jQuery('#post-spinner').html('<small><i class="fa fa-refresh fa-spin"></i> <i>Loading...</i></small>');
					jQuery.ajax({
						type: "GET",
						url: url,
						dateType: 'json',
						success: function( data ) {
							jQuery('#post-spinner').html('');
							if (data.success)
							{
								if (data.topics) 
								{
									for(var i=0; i<data.topics.length; i++)
									{
										topic = data.topics[i];
										jQuery('#post-topics').append('<option value="' + topic.id + '">' + topic.name + '</option>');
									}
								}
							}
						}
					});
				}			
			});
			
			
			if (jQuery('#photo-dropzone').is(':visible'))
			{
			  loadDropZone();
			}  
			
			
			jQuery('.video-preview').magnificPopup({
			  delegate: 'a',
			  type: 'iframe',
			  iframe: {
				  markup: '<div class="mfp-iframe-scaler">'+
							'<div class="mfp-close"></div>'+
							'<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
						  '</div>',
				  patterns: {
					youtube: {
					  index: 'youtube.com/',
					  id: 'v=',
					  src: '//www.youtube.com/embed/%id%?autoplay=1'
					},
					vimeo: {
					  index: 'vimeo.com/',
					  id: '/',
					  src: '//player.vimeo.com/video/%id%?autoplay=1'
					}
				  },
				  srcAction: 'iframe_src',
				}
			});
			
		});
		
		function loadDropZone()
		{
			Dropzone.options.photoDropzone = {
				uploadMultiple: false,
				acceptedFiles: 'image/*',
				addRemoveLinks: false,
				dictDefaultMessage: '',
				init: function() {
				  this.on("addedfile", function(file) {
					$('#img-thumb-preview #img-thumb').hide();
					$('#img-thumb-preview').show();
					$('.processing-msg').show();
				  });
				  this.on("thumbnail", function(file, dataUrl) {
					$('.dz-image-preview').hide();
					$('.dz-file-preview').hide();
				  });
				  this.on("success", function(file, res) {
					$('.processing-msg').hide();  
					$('#img-thumb').attr('src', res.path);
					$('#img-thumb-preview #img-thumb').show();
					$('#img-thumb-preview').show();
					
					if (jQuery('#post-form').is(':visible')) jQuery('#post-form').find('input[name="photo"]').val(res.path);
					if (jQuery('#banner-form').is(':visible')) jQuery('#banner-form').find('input[name="photo"]').val(res.path);
				  });
				}
			  };
			  var photoDropzone = new Dropzone("#photo-dropzone");
			 
			  $('#upload-submit').on('click', function(e) {
				e.preventDefault();
				$("#photo-dropzone").trigger('click');
			  });
		}
		
		function deleteEntity(id, entity)
		{
			BootstrapDialog.confirm({
                type: BootstrapDialog.TYPE_WARNING,
                title: "CG Networks Alerts",
                message: "Are you sure you want to permanently delete this item?",
                btnCancelLabel: 'Cancel',
				btnOKLabel: 'Delete',
				callback: function(result) {
					if (result) {
						window.location.href = "<?php echo e(url('/admin')); ?>/"+entity+"/delete/"+id;
					}
				}
            }); 
		}
		
		function preview(id, entity)
		{
			location.href = "<?php echo e(url('/admin')); ?>/"+entity+"/edit/"+id;
		}
	</script>
</body>
</html>