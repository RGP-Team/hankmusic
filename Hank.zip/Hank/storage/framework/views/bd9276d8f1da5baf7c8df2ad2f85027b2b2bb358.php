<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4>Your Feed</h4>
								</div>
							</div>
						</div>
						<div class="row pad-bottom-bold bottom-line">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
								<div class="profile-followers">
									<i class="fa fa-group"></i> 2,000
								</div>
							</div>
							<div class="col-md-10 no-pad-left adjust-bottom">
								<div class="topic-title item-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
						<div class="row pad-bottom-bold bottom-line">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
								<div class="profile-followers">
									<i class="fa fa-group"></i> 2,000
								</div>
							</div>
							<div class="col-md-10 no-pad-left adjust-bottom">
								<div class="topic-title item-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
						<div class="row pad-bottom-bold bottom-line">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
								<div class="profile-followers">
									<i class="fa fa-group"></i> 2,000
								</div>
							</div>
							<div class="col-md-10 no-pad-left adjust-bottom">
								<div class="topic-title item-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
						<div class="row pad-bottom-bold bottom-line">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
								<div class="profile-followers">
									<i class="fa fa-group"></i> 2,000
								</div>
							</div>
							<div class="col-md-10 no-pad-left adjust-bottom">
								<div class="topic-title item-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
						<div class="row pad-bottom-bold bottom-line">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
								<div class="profile-followers">
									<i class="fa fa-group"></i> 2,000
								</div>
							</div>
							<div class="col-md-10 no-pad-left adjust-bottom">
								<div class="topic-title item-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>