<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>CGNetworks Admin</title>
    <?php echo e(Html::style('bootstrap/css/bootstrap.min.css')); ?>

    <?php echo e(Html::style('css/admin.css')); ?>

    <?php echo e(Html::style('font-awesome/css/font-awesome.min.css')); ?>

</head>
<body>
    
    <div class="container-fluid">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
	
	
    <!-- JQuery JavaScript -->
    <?php echo e(Html::script('js/jquery-1.12.3.min.js')); ?>

	<!-- Bootstrap JavaScript -->
    <?php echo e(Html::script('bootstrap/js/bootstrap.min.js')); ?>

    <!-- Custom JavaScript -->
    <?php echo e(Html::script('js/admin.js')); ?>

</body>
</html>