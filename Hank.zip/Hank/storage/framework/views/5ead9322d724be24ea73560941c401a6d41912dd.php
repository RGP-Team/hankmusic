<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12 admin-data-table">
					
					
					<div class="row">
						<div class="col-md-4 bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">
									<h3>Category</h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-12 form">
											

											<!-- General -->
														
											<?php echo Form::open(array('route' => 'admin.categories.save', 'method' => 'POST', 'id' => 'category-form')); ?>

											<?php if(isset($data->info)): ?>
												<input type="hidden" name="category_id" value="<?php echo e($data->info->id); ?>">
											<?php endif; ?>
											<div class="form-group row">
											  <label class="col-sm-4 col-form-label">Name</label>
											  <div class="col-sm-8">
												<?php if(isset($data->info)): ?>
													<input type="text" name="name" class="form-control" value="<?php echo e($data->info->name); ?>" placeholder="Category name here...">
												<?php else: ?>
													<input type="text" name="name" class="form-control" placeholder="Category name here...">
												<?php endif; ?> 
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-4 col-form-label">Spanish (es)</label>
											  <div class="col-sm-8">
												<?php if(isset($data->info)): ?>
													<input type="text" name="es" class="form-control" value="<?php echo e($data->info->es); ?>" placeholder="Category name in spanish here...">
												<?php else: ?>
													<input type="text" name="es" class="form-control" placeholder="Category name in spanish...">
												<?php endif; ?> 
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-4 col-form-label">Chinese (zh)</label>
											  <div class="col-sm-8">
												<?php if(isset($data->info)): ?>
													<input type="text" name="zh" class="form-control" value="<?php echo e($data->info->zh); ?>" placeholder="Category name in chinese here...">
												<?php else: ?>
													<input type="text" name="zh" class="form-control" placeholder="Category name in chinese...">
												<?php endif; ?> 
											  </div>
											</div>
											<fieldset class="form-group row">
											  <label class="col-sm-4">Status</label>
											  <div class="col-sm-8">
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="status" value="1" checked>
													Active
												  </label>
												</div>
												<div class="form-check">
												  <label class="form-check-label">
													<?php if(isset($data->info) && (! $data->info->active)): ?>
														<input class="form-check-input" type="radio" name="status" value="0" checked>
													<?php else: ?>
														<input class="form-check-input" type="radio" name="status" value="0">
													<?php endif; ?>
													Inactive
												  </label>
												</div>
											  </div>
											</fieldset>
											<div class="row">
												<div class="col-md-12 top-margin-20">
													<button class="btn btn-primary">Save Category</button>
												</div>
											</div>
											<?php echo Form::close(); ?>

											
											<!-- /General -->							
											
											
										</div>
									</div>	
									
									
								</div>
							</div>
						</div>
						<div class="col-md-1"></div>
						<div class="col-md-7">
							
							<?php if(isset($data->topics)): ?>
							<!-- Requests -->
							<div class="row bottom-margin-20">
								<div class="col-md-12 sub-topic-label"><h4>Topics &nbsp;<button type="submit" onclick="location.href='<?php echo e(url('/admin')); ?>/topics/new/<?php echo e($data->info->id); ?>'" class="btn btn-sm btn-primary">New</button><br/><small>Manage topics under this category</small></h4></div>
							</div>											
							<div class="row">
								<div class="col-md-12 bottom-margin-50">
									<?php echo $__env->make('admin.includes.table-only', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
								</div>
							</div>
																											
							<!-- /Requests -->
							<?php endif; ?>
							
							
						</div>
						
						
					</div>
					
					

				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>