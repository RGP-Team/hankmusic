<?php if($comments->count()): ?>
	<?php foreach( $comments as $comment): ?>
	<div class="row bottom-margin-5">
		<?php if(empty($comment->comment_id)): ?>
			<div class="col-md-1 text-center"></div>
			<div class="col-md-11">
		<?php else: ?>
			<div class="col-md-12">
		<?php endif; ?>
			
			<div class="row">
				<div class="col-md-1 col-sm-1 col-xs-1 text-center">
					<div class="user-profile hidden-sm hidden-xs">
						<?php if($comment->user->photo): ?>
							<?php ($profile_photo = $comment->user->photo->url); ?>
							<img src="<?php echo e($profile_photo); ?>" alt="">
						<?php else: ?>
							<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
						<?php endif; ?>
					</div>
				</div>
				<div class="col-md-11 col-sm-11 col-xs-11 adjust-padding">
					<a name="<?php echo e('p'.$comment->post_id.'c'.$comment->id); ?>"></a>
					<div class="topic-title add-spacer"><a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($comment->user->id); ?>"><?php echo e($comment->user->first_name . ' ' . $comment->user->last_name); ?></a><span class="topic-hour"><?php echo e(CustomHelper::lang('lang-posted')); ?> <?php echo e(CustomHelper::show_elapsed_time($comment->created_dt)); ?></span></div>
					<p class="text-left">
					<?php echo nl2br(e($comment->message)); ?>

					</p>
					<?php if($comment->photos->count()): ?>
						<div class="photo-gallery">
							<?php foreach( $comment->photos as $photo ): ?>
								<a href="<?php echo e($photo->photo->url); ?>"><img class="gallery-item" src="<?php echo e($photo->photo->url); ?>" border="0" /></a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<?php if( ! Auth::guest() && ((int)$comment->user->id !== (int)Auth::user()->id)): ?>
					<div class="bottom-margin-10">
						<form class="form-inline" role="form" method="POST" action="<?php echo e(url('/posts/votedown')); ?>">
						<?php echo csrf_field(); ?>	
						<input type="hidden" name="post_id" value="<?php echo e($comment->post_id); ?>" />
						<input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>" />
						<input type="hidden" name="type" value="comment" />
						<a href="javascript://" onclick="submitVote(this);" title="Vote Down" class="action-buttons"><i class="fa fa-chevron-down"></i> <?php echo e($comment->down_votes); ?></a>
						</form>
						<form class="form-inline" role="form" method="POST" action="<?php echo e(url('/posts/voteup')); ?>">
						<?php echo csrf_field(); ?>

						<input type="hidden" name="post_id" value="<?php echo e($comment->post_id); ?>" />
						<input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>" />
						<input type="hidden" name="type" value="comment" />
						<a href="javascript://" onclick="submitVote(this);" title="Vote Up" class="action-buttons"><i class="fa fa-chevron-up"></i> <?php echo e($comment->up_votes); ?></a>
						</form>
						<a href="javascript://" class="action-buttons toggle-comment-box" title="Add Comment"><i class="fa fa-mail-reply"></i> <?php echo e(CustomHelper::lang('lang-reply')); ?></a>
						<span>
							<input type="hidden" name="source_id" value="<?php echo e(Auth::user()->id); ?>" />
							<input type="hidden" name="target_id" value="<?php echo e($comment->user->id); ?>" />
							<a href="javascript://" onclick="sendMessage(this)" class="action-buttons" title="Send Message"><i class="fa fa-envelope-o"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-send-a-message')); ?></a>
						</span>
						<a href="javascript://" onclick="sharePostComment(this);" class="action-buttons share"><?php echo e(CustomHelper::lang('lang-share')); ?></a>
						<div class="reply-container" style="display:none;">
							<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/posts/comment')); ?>" onsubmit="return checkComment(this);">
							<?php echo csrf_field(); ?>	
							<input type="hidden" name="post_id" value="<?php echo e($comment->post_id); ?>" />
							<input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>" />
							<div class="row">
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-12">
											<textarea class="img-responsive form-control comment" name="comment" placeholder="<?php echo e(CustomHelper::lang('lang-your-comment-here')); ?>"></textarea>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<span class="limit-counter"></span>
											<div class="row hidden-container attachment-container">
												<div class="col-md-12 photos-videos-container">
													<span class="photos-container"></span>&nbsp;
													<span class="videos-container"></span>
												</div>
											</div>
										</div>
										<div class="col-md-8 text-right">
											<a href="#upload_image_form" class="btn photos-popup"><?php echo e(CustomHelper::lang('lang-upload-image')); ?></a>
											<button class="btn"><?php echo e(CustomHelper::lang('lang-submit')); ?></button>
										</div>
									</div>
								</div>
							</div>
							</form>
						</div>
					</div>
					<?php else: ?>
					<p class="text-right votes">
						<i class="fa fa-thumbs-down font-red"></i> <?php echo e($comment->down_votes); ?>, &nbsp;<i class="fa fa-thumbs-up font-green"></i> <?php echo e($comment->up_votes); ?>

					</p>
					<?php endif; ?>
				</div>
			</div>
			
		</div>
	</div>
	<?php endforeach; ?>
<?php endif; ?>