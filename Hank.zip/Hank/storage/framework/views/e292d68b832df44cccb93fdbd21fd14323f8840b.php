<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-8">
						<div class="row">
							<div class="col-md-12">
								<h3>Entertainment</h3>
							</div>
						</div>
						<div class="row">
							<div class="col-md-7 margin-topbottom">
								<h4>Submit a Post (150 Word Limit)</h4>
							</div>
							<div class="col-md-5 margin-topbottom text-right">
								<input type="text" id="freelancer_code" name="" value="" placeholder="Freelancer Code #" />
							</div>
						</div>
						<div class="row">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
							</div>
							<div class="col-md-10 no-pad-left">
								<!--<input id="post-title" type="text" name="" value="" placeholder="Title..." />-->
								<textarea class="img-responsive" placeholder="Post Content..."></textarea>
							</div>
						</div>
						<div class="row pad-bottom">
							<div class="col-md-12 text-right">
								<a href="#embed_video_form" class="btn popup">Embed Video</a>
								<a href="#upload_image_form" class="btn popup">Upload Image</a>
								<a href="" class="btn">Submit</a>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><i class="fa fa-comments-o"></i> Sub-Topics</h4>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 text-center">
								<h4 class="heading">Health</h4>
							</div>
						</div>
						<div class="row pad-bottom-bold">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
							</div>
							<div class="col-md-10 no-pad-left">
								<div class="topic-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
						<div class="row pad-bottom-bold">
							<div class="col-md-2 text-center"></div>
							<div class="col-md-10">
								
								<div class="row">
									<div class="col-md-2 text-center">
										<div class="profile-pic">
										</div>
									</div>
									<div class="col-md-10 no-pad-left">
										<div class="topic-title">NAME GOES HERE<span class="topic-hour">Today 11:45 AM</span></div>
										<p>
											Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
										</p>
										<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
										<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
										<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
										<a href="" class="action-buttons share">Share</a>
									</div>
								</div>
								
							</div>
						</div>
						<div class="row pad-bottom-bold">
							<div class="col-md-2 text-center"></div>
							<div class="col-md-10">
								
								<div class="row">
									<div class="col-md-2 text-center">
										<div class="profile-pic">
										</div>
									</div>
									<div class="col-md-10 no-pad-left">
										<div class="topic-title">NAME GOES HERE<span class="topic-hour">Today 11:45 AM</span></div>
										<p>
											Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
										</p>
										<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
										<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
										<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
										<a href="" class="action-buttons share">Share</a>
									</div>
								</div>
								
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="line-border"></div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 text-center">
								<h4 class="heading">Living</h4>
							</div>
						</div>
						<div class="row pad-bottom-bold">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
							</div>
							<div class="col-md-10 no-pad-left">
								<div class="topic-title">NAME GOES HERE<span class="topic-hour">10 hours ago</span></div>
								<p>
									Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec convallis urna eget tellus sagittis eget cursus elit mollis. Sed luctus malesuada tincidunt. Quisque elementum urna justo. Cras in mauris ac sem vestibulum pellentesque.
								</p>
								<a href="" class="action-buttons"><i class="fa fa-chevron-down"></i> 4</a>
								<a href="" class="action-buttons"><i class="fa fa-chevron-up"></i> 6</a>
								<a href="" class="action-buttons"><i class="fa fa-mail-reply"></i> Reply</a>
								<a href="" class="action-buttons share">Share</a>
							</div>
						</div>
					</div>
					<div class="col-md-1"></div>
					<div class="col-md-3">
						<div class="container-topics">
							<h4>Sub Topics</h4>
							<ul>
								<li>Health</li>
								<li>Living</li>
								<li>Food</li>
								<li>Nutrition</li>
								<li>Beauty</li>
								<li>Cosmetics</li>
								<li>Medical</li>
								<li>Transportation</li>
								<li>School</li>
								<li>Children</li>
								<li>Home</li>
								<li>World</li>
								<li>Region</li>
								<li>Neighbourhoods</li>
								<li>Others</li>
							</ul>
						</div>
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>