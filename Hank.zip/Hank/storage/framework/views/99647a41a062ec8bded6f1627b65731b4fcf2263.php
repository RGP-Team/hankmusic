<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-40">
								<div class="col-md-12">
									<h3>Banners<br/><small>Banner sizes are predefined based on the homepage's design layout</small></h3>
									
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-9">																						
											<!-- Subscription Plans -->
														
											<div class="row">
												<div class="col-md-12 bottom-margin-30">
													<button id="toggle-plan" class="btn btn-default margin-t-5"><i class="fa fa-edit"></i> <span>New Banner</span></button>
												</div>
											</div>
											
											<div class="plan-container noshow bottom-margin-50">
												<?php echo Form::open(array('route' => 'articles.create', 'method' => 'POST')); ?>

												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Title</label>
												  <div class="col-sm-9">
													<input type="email" class="form-control" placeholder="Your Banner Title">
												  </div>
												</div>
												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Sub Title</label>
												  <div class="col-sm-9">
													<input type="email" class="form-control" placeholder="Your Banner Sub Title (optional)">
												  </div>
												</div>
												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Category</label>
												  <div class="col-sm-9">
													<select class="form-control">
													  <option value="">-- Choose category</option>
													  <option>Education</option>
													  <option>Travel</option>
													  <option>Technology</option>
													  <option>World</option>
													</select>
												  </div>
												</div>
												<div class="form-group row">
													<label class="col-sm-3 col-form-label">Banner Size</label>
													<div class="col-sm-9">
														
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="" value="option1">
																630 x 350
															  </label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="" value="option1">
																945 x 106
															  </label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="" value="option1">
																368 x 256
															  </label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="" value="option2">
																300 x 106
															  </label>
															</div>
														
													</div>
												</div>
												<div class="form-group row">
													<label class="col-sm-3 col-form-label">Type</label>
													<div class="col-sm-9">
														
															<div class="form-check">
															  <label class="form-check-label">
																<input type="radio" class="form-check-input" name="optionsRadios" value="option1">
																Advertisement
															  </label>
															</div>
															<div class="form-check">
															<label class="form-check-label">
																<input type="radio" class="form-check-input" name="optionsRadios" value="option2" checked>
																Content &nbsp;<small>(plain image content for display)</small>
															  </label>
															</div>
														
													</div>
												</div>												
												<div class="form-group row">
												  <label class="col-sm-3 col-form-label">Banner Image</label>
												  <div class="col-sm-9">
													
														<?php echo Form::open(array('route' => 'photos.upload', 'method' => 'POST', 'id' => 'photo-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

															<button id="upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> Upload Image</button>
															<div id="img-thumb-preview" class="noshow">
															  <span class="processing-msg" style="display:none;">Processing, please wait...</span>
															  <div class="img-thumbnail">
																<img id="img-thumb" class="user size-lg img-responsive photo-select" src="">
															  </div>
															</div>
														<?php echo Form::close(); ?>

													
												  </div>
												</div>
												<div class="row">
													<div class="col-md-12 top-margin-10 text-right">
														<button class="btn btn-primary">Save Banner</button>
													</div>
												</div>
												<?php echo Form::close(); ?>

											</div>														
											
											
											<div class="row">
												<div class="col-md-12">
													<table id="datatable" data-entity="" class="table table-striped table-bordered">
													  <thead>
														<tr>
														  <th>Title</th>
														  <th>Banner Size</th>
														  <th>Category</th>
														  <th id="action" width="15%">Action</th>
														</tr>
													  </thead>
													  <tbody ng-model="listings">
															<tr>
																<td>Top Banner</td>
																<td>945 x 106</td>
																<td>Education</td>
																<td align="center" class="action-item">
																	<a href="javascript://"><i class="fa fa-trash-o action-icons"></i> Delete</a>
																</td>
															</tr>
															<tr>
																<td>Sidebar Banner</td>
																<td>300 x 106</td>
																<td>Technology</td>
																<td align="center" class="action-item">
																	<a href="javascript://"><i class="fa fa-trash-o action-icons"></i> Delete</a>
																</td>
															</tr>											
													  </tbody>
													</table>		
												</div>
											</div>
																															
											<!-- /Subscription Plans -->
										</div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>