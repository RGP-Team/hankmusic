<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12">
						
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-membership-update')); ?></h4>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>			
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 top-margin-30"></div>
						</div>
						<div class="row">
							<div class="col-md-1"></div>
							<div class="col-md-10 profile-area">
								
								<!-- profile -->		
								<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/membership/update')); ?>">
									<?php echo csrf_field(); ?>

									
									<input type="hidden" name="proceed" value="true">
									<div class="form-group">
										<legend><?php echo e(CustomHelper::lang('lang-billing')); ?></legend>
										<small class="profile-notes"><?php echo e(CustomHelper::lang('lang-previous-plan-cancel')); ?></small>
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-membership-plans')); ?></label>

										<div class="col-md-7">
											<?php ($noshow = ''); ?>
											<?php if($data->plans): ?>
												<?php foreach( $data->plans as $plan ): ?>
												<?php ($checked = ''); ?>
												<?php if((int)$plan->id === (int)$data->user->plan_id): ?> 
													<?php ($checked = 'checked'); ?>
													<?php if((int)$plan->amount === 0): ?>
														<?php ($noshow = 'noshow'); ?>
													<?php endif; ?>
												<?php endif; ?>
												<?php if(empty($checked)): ?>
													<div class="row bottom-margin-20">
														<div class="col-md-2 width-10">
															<input type="radio" name="plan_id" class="billing-option" data-amount="<?php echo e($plan->amount); ?>" value="<?php echo e($plan->id); ?>" <?php echo e($checked); ?>>
														</div>
														<div class="col-md-10 width-90">
															<strong><?php echo e($plan->title); ?> &nbsp;<span class="monthly-bill">($<?php echo e($plan->amount); ?> per month)</span></strong><br/>
															<?php echo e($plan->description); ?>

														</div>
													</div>
												<?php endif; ?>
												<?php endforeach; ?>
											<?php endif; ?>
										</div>
									</div>
									
									<div class="form-group card-information <?php echo e($noshow); ?>">
										<legend><?php echo e(CustomHelper::lang('lang-credit-card')); ?></legend>
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-card-number')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="card_number" placeholder="<?php echo e(CustomHelper::lang('lang-credit-card-number')); ?>">
										</div>
									</div>
									
									<div class="form-group card-information <?php echo e($noshow); ?>">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-expiration-date')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="card_expiration_date" placeholder="<?php echo e(CustomHelper::lang('lang-credit-card-expiration')); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<div class="col-md-7 col-md-offset-5">
											<button type="submit" class="btn btn-primary">
												<i class="fa fa-btn fa-user"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-update-membership')); ?>

											</button>
										</div>
									</div>
								</form>	
								<!-- profile -->
							
							</div>
							<div class="col-md-1"></div>
						</div>
						
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>						
						