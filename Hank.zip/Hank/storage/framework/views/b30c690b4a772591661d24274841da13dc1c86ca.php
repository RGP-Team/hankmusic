<footer>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<!-- footer -->
				
				
			
				<!-- /footer -->
			</div>
		</div>
	</div>
</footer>
<div class="cc_banner-wrapper ">
	<div class="cc_banner cc_container cc_container--open">
		<!--<a href="#null" data-cc-event="click:dismiss" target="_blank" class="cc_btn cc_btn_accept_all">Got it!</a>
		<p class="cc_message">This website uses cookies to ensure you get the best experience on our website </p>
		<a class="cc_logo" target="_blank" href="http://silktide.com/cookieconsent">Cookie Consent plugin for the EU cookie law</a>-->
		<div class="row">
			<div class="col-md-6">
				<div id="waveform"></div>
			</div>
			<div class="col-md-6">
				<button class="btn btn-primary btn-play-audio">Play Audio</button>
				<button class="btn btn-primary btn-open-login">Login</button>
				<button class="btn btn-primary btn-open-signup">Sign up</button>
			</div>
		</div>
	</div>
</div>
<!-- form templates -->
<div id="login_form" class="white-popup mfp-hide modal_form">
	<div class="container">
		<div class="row">
			<div class="col-md-5"></div>
			<div class="col-md-7">
				<?php echo Form::open(array('route' => 'user.login', 'method' => 'POST')); ?>

				<div class="row form-heading">
					<div class="col-md-12">
						<h3>LOG IN TO YOUR ACCOUNT<small>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet lacus ut mauris rutrum sodales.</small></h3>
					</div>
				</div>
				
				<div class="row form">
					<div class="form-group col-md-12 extend-bg border-line-top remove-bottom-margin">
						<label class="form-control-label" for="user_email">EMAIL ADDRESS *</label>
						<div class="controls">
							<input type="text" id="user_email" name="user_email" class="form-control" placeholder="hank@music.com" required autocomplete="off">
							<small class="help-inline text-muted"></small>
						</div>
					</div>

					<div class="form-group col-md-12 extend-bg border-line-top border-line-bottom">
						<label class="form-control-label" for="user_pass">PASSWORD *</label>
						<div class="controls">
							<input type="password" id="user_pass" name="user_pass" class="form-control" placeholder="********" required autocomplete="off">
							<small class="help-inline text-muted"></small>
						</div>
					</div>
					
					<div class="form-group col-md-12">
						<div class="controls text-center">
							<button class="btn btn-primary col-md-12">LOG IN</button><br/>
							<a href="">Forgot Password?</a>
						</div>
					</div>
				</div>
				
				<div class="row sign-up">
					<div class="col-md-12 text-center">
						Don't have an account? <a href="">Sign up</a>
					</div>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<div id="signup_form" class="white-popup mfp-hide modal_form">
	<div class="container">
		<div class="row">
			<div class="col-md-5"></div>
			<div class="col-md-7">
				<?php echo Form::open(array('route' => 'user.login', 'method' => 'POST')); ?>

				<div class="row form-heading">
					<div class="col-md-12">
						<h3>SIGNUP WITH EMAIL<small>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet lacus ut mauris rutrum sodales.</small></h3>
					</div>
				</div>
				
				<div class="row form">
					<div class="form-group col-md-12 extend-bg border-line-top remove-bottom-margin">
						<label class="form-control-label" for="user_name">NAME *</label>
						<div class="controls">
							<input type="text" id="user_name" name="user_name" class="form-control" placeholder="Hank Music" required autocomplete="off">
							<small class="help-inline text-muted"></small>
						</div>
					</div>
					
					<div class="form-group col-md-12 extend-bg border-line-top remove-bottom-margin">
						<label class="form-control-label" for="user_email">EMAIL ADDRESS *</label>
						<div class="controls">
							<input type="text" id="user_email" name="user_email" class="form-control" placeholder="hank@music.com" required autocomplete="off">
							<small class="help-inline text-muted"></small>
						</div>
					</div>
					
					<div class="form-group col-md-12 extend-bg border-line-top remove-bottom-margin">
						<label class="form-control-label" for="user_pass">PASSWORD *</label>
						<div class="controls">
							<input type="password" id="user_pass" name="user_pass" class="form-control" placeholder="********" required autocomplete="off">
							<small class="help-inline text-muted"></small>
						</div>
					</div>

					<div class="form-group col-md-12 extend-bg border-line-top border-line-bottom">
						<label class="form-control-label" for="user_mobile_number">MOBILE NUMBER <i>( Optional )</i></label>
						<div class="controls">
							<input type="text" id="user_mobile_number" name="user_mobile_number" class="form-control" placeholder="+63 912-123-4567" required autocomplete="off">
							<small class="help-inline text-muted"></small>
						</div>
					</div>
					
					<div class="form-group col-md-12">
						<div class="controls text-center">
							<button class="btn btn-primary col-md-12">CREATE ACCOUNT</button><br/>
							Requires e-mail verification
						</div>
					</div>
				</div>
				
				<div class="row sign-up">
					<div class="col-md-12 text-center">
						Already have an account? <a href="">Sign in</a>
					</div>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<!-- /form templates -->

<script src=""></script>
		<script>
			/*var wavesurfer = WaveSurfer.create({
				container: '#waveform',
				waveColor: 'violet',
				progressColor: 'purple',
				/*height: 2,*/
				/*barWidth: 1,*
			});
			wavesurfer.load('audio/my_mule.wav');
			wavesurfer.on('ready', function () {
				alert(123);
				wavesurfer.play();
			});*/
			/*
			wavesurfer.pause(), wavesurfer.skipBackward(), wavesurfer.skipForward(), wavesurfer.toggleMute()
			*/
		</script>

<!-- JQuery/External JavaScript -->
<?php echo e(Html::script('//code.jquery.com/jquery-1.12.4.js')); ?>

<?php echo e(Html::script('//code.jquery.com/ui/1.12.0/jquery-ui.js')); ?>

<?php echo e(Html::script('//cdnjs.cloudflare.com/ajax/libs/wavesurfer.js/1.0.52/wavesurfer.min.js')); ?>


<!-- Bootstrap JavaScript -->
<?php echo e(Html::script('bootstrap/js/bootstrap.min.js')); ?>


<!-- Other JavaScript Libraries -->
<?php echo e(Html::script('js/jquery.magnific-popup.min.js')); ?>

<?php echo e(Html::script('js/dropzone.js')); ?>

<?php echo e(Html::script('js/bootstrap-dialog.min.js')); ?>



<?php echo e(Html::script('js/script.js')); ?>

