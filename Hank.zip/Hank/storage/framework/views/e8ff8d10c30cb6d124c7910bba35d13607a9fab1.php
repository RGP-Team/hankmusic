<?php 
	$friend_requests = array();
	if (! Auth::guest()) $friend_requests = \App\Models\FriendRequest::where('target_id', Auth::user()->id)->get();
	
	$unread_messages = array();
	if (! Auth::guest()) $unread_messages = \App\Models\Message::where('target_id', Auth::user()->id)->where('is_read', false)->get();
?>
<?php ($info = CustomHelper::checkPageLimit()); ?>
<?php if((int)$info['remaining_slot'] === 0): ?>
<div class="row">
	<div class="col-md-12">
		<div class="alert alert-warning"><strong><?php echo e(CustomHelper::lang('lang-warning')); ?></strong> &nbsp;
			<?php echo e(str_replace('%%i%%', Auth::user()->page_limit, CustomHelper::lang('lang-reached-limit'))); ?>

		</div>
	</div>
</div>
<?php endif; ?>
<div class="row">
	<div class="col-md-6">
		<h4 class="text-primary navigation-profile"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?> &nbsp;&nbsp;<a href="<?php echo e(url('/profile/edit')); ?>" class="edit-profile"><?php echo e(CustomHelper::lang('lang-edit-profile')); ?></a></h4>
	</div>
	<div class="col-md-6 text-right">
		<h4><i class="fa fa-gear text-primary"></i> <?php echo e(CustomHelper::lang('lang-membership')); ?>: <?php echo e(\App\Models\Plan::find(Auth::user()->plan_id)->title); ?></h4>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-2">
				<a href="<?php echo e(url('/photos')); ?>" class="nav-section">
					<img src="<?php echo e(URL::asset('images/photos.png')); ?>" border="0" />
					<div class="nav-section-label">
						<?php echo e(CustomHelper::lang('lang-photos')); ?>

					</div>
				</a>
			</div>
			<div class="col-md-2">
				<a href="<?php echo e(url('/videos')); ?>" class="nav-section">
					<i class="fa fa-file-video-o"></i>
					<div class="nav-section-label">
						<?php echo e(CustomHelper::lang('lang-videos')); ?>

					</div>
				</a>
			</div>
			<div class="col-md-2">
				<a href="<?php echo e(url('/friends')); ?>" class="nav-section">
					<img src="<?php echo e(URL::asset('images/group.png')); ?>" border="0" />
					<div class="nav-section-label">
						<?php echo e(CustomHelper::lang('lang-friends')); ?>

					</div>
				</a>
			</div>
			<div class="col-md-2">
				<a href="<?php echo e(url('/works')); ?>" class="nav-section">
					<img src="<?php echo e(URL::asset('images/writings.png')); ?>" border="0" />
					<div class="nav-section-label">
						<?php echo e(CustomHelper::lang('lang-works')); ?>

					</div>
				</a>
			</div>
			<div class="col-md-2">
				<a href="<?php echo e(url('/messages')); ?>" class="nav-section">
					<img src="<?php echo e(URL::asset('images/messages.png')); ?>" border="0" />
					<?php if(! empty($unread_messages)): ?>
						<?php if($unread_messages->count()): ?>
							<div class="messages-count"><?php echo e($unread_messages->count()); ?></div>
						<?php endif; ?>
					<?php endif; ?>
					<div class="nav-section-label">
						<?php echo e(CustomHelper::lang('lang-messages')); ?>

					</div>
				</a>
			</div>
			<div class="col-md-2">
				<a href="<?php echo e(url('/requests')); ?>" class="nav-section">
					<img src="<?php echo e(URL::asset('images/group.png')); ?>" border="0" />
					<?php if(! empty($friend_requests)): ?>
						<?php if($friend_requests->count()): ?>
							<div class="items-count"><?php echo e($friend_requests->count()); ?></div>
						<?php endif; ?>
					<?php endif; ?>
					<div class="nav-section-label">
						<?php echo e(CustomHelper::lang('lang-friend-requests')); ?>

					</div>
				</a>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 spacer"></div>
</div>