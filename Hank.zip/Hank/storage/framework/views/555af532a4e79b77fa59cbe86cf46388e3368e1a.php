<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">
									<h3>Approval (<?php echo e(ucwords($data->info->type)); ?>)<br/><small>You are only allowed to approve or deny pending approval request in this area</small></h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-8 form">
											

											<!-- Approval -->
														
											<?php echo Form::open(array('route' => 'admin.approvals.save', 'method' => 'POST', 'id' => 'approval-form')); ?>

											<?php if(isset($data->info)): ?>
												<input type="hidden" name="approval_id" value="<?php echo e($data->info->id); ?>">
											<?php endif; ?>
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Review Submission</label>
												<div class="col-sm-9">
													<small>Click the link below to check out the submission</small><br/>
													<?php if($data->info->type === 'freelancer'): ?><a href="<?php echo e(url('/user')); ?>/profile/<?php echo e($data->info->user->id); ?>#artworks" target="_blank">Open Art Works</a><?php endif; ?>
													<?php if($data->info->type === 'writer'): ?><a href="<?php echo e(url('/user')); ?>/profile/<?php echo e($data->info->user->id); ?>#writings" target="_blank">Open Articles</a><?php endif; ?>
													<?php if($data->info->type === 'video'): ?>
														<div class="video-preview">
															<?php ($video = $data->info->video); ?>
															<a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>">Open Video</a>
														</div>
													<?php endif; ?>
												</div>
											</div>
											<fieldset class="form-group row">
											  <label class="col-sm-3">Request Action</label>
											  <div class="col-sm-9">
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="approval" value="1" checked>
													Approve
												  </label>
												</div>
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="approval" value="0">
													Deny
												  </label>
												</div>
											  </div>
											</fieldset>
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Message</label>
												<div class="col-sm-9">
													<textarea class="form-control" name="message" rows="7" placeholder="Your custom message for approving or denying a request..."></textarea>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12 top-margin-20">
													<button class="btn btn-primary">Submit Approval</button>
												</div>
											</div>
											<?php echo Form::close(); ?>										
											
											<!-- /Approval -->
											
											
											
											
											
										</div>
										<div class="col-md-1"></div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>