<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 friends-container">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-your-friends')); ?></h4>
								</div>
								<?php if(session()->has('success_message')): ?>
									<div class="alert alert-success">
										<?php echo e(session()->get('success_message')); ?>

									</div>
								<?php endif; ?>
								<?php if(count($errors->all())): ?>
									<div class="alert alert-danger">
										<ul>
										<?php foreach($errors->all() as $error): ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; ?>
										</ul>
									</div>
								<?php else: ?>
									<?php if(session()->has('error_message')): ?>
									<div class="alert alert-danger">
										<?php echo e(session()->get('error_message')); ?>

									</div>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 min-height-300 top-margin-40">
								<div class="row search-results">
									<?php if($friends->count()): ?>
										<?php foreach($friends as $item): ?>
											<?php ($user = $item->friend); ?>
											<div class="col-md-6 search-item user-profile text-left">
												<div class="col-md-3">
													<?php if($user->photo): ?>
														<?php ($profile_photo = $user->photo->url); ?>
														<img src="<?php echo e($profile_photo); ?>" alt="">
													<?php else: ?>
														<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
													<?php endif; ?>
												</div>
												<div class="col-md-9">
													<h3 class="profile-name"><a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($user->id); ?>"><?php echo e(ucwords($user->first_name)); ?> <?php echo e(ucwords($user->last_name)); ?></a>
													<small class="mutual-friends-container">
														 (<strong><?php echo e(CustomHelper::getMutualFriendsCount( $user->id, Auth::user()->id )); ?></strong> <?php echo e(CustomHelper::lang('lang-mutual-friends')); ?>)
													</small>
													</h3>
													<small class="member"><?php echo e(CustomHelper::lang('lang-member-since')); ?> <?php echo e(CustomHelper::show_elapsed_time($user->created_at)); ?></small><br/>									
													<small class="address">
													<?php if(! empty($user->city)): ?><?php echo e($user->city); ?><?php endif; ?>
													<?php if(! empty($user->state)): ?><?php echo e(', '.$user->state); ?><?php endif; ?>
													<?php if(! empty($user->zip)): ?><?php echo e(' '.$user->zip); ?><?php endif; ?>
													<?php if(! empty($user->country)): ?><?php echo e(', '.$user->country); ?><?php endif; ?>
													</small>
													<small>
														<input type="hidden" name="source_id" value="<?php echo e(Auth::user()->id); ?>" />
														<input type="hidden" name="target_id" value="<?php echo e($user->id); ?>" />
														<button type="button" onclick="sendMessage(this)" class="btn btn-primary btn-xs"><i class="fa fa-envelope-o"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-send-a-message')); ?></button>
													</small>
												</div>
											</div>
										<?php endforeach; ?>
									<?php else: ?>
										<div class="col-md-12 text-center top-margin-40">
											<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

										</div>
									<?php endif; ?>
								</div>
								<div class="row">
									<div class="col-md-12">
										<?php echo e($friends->links()); ?>

									</div>
								</div>
							</div>
						</div>
						<!--<div class="row pad-bottom-bold bottom-line">
							<div class="col-md-2 text-center">
								<div class="profile-pic">
								</div>
								<div class="profile-followers">
									<i class="fa fa-group"></i> 2,000
								</div>
							</div>
							<div class="col-md-10 no-pad-left adjust-bottom">
								<div class="col-md-9">
									<div class="topic-title item-title">NAME GOES HERE</div>
									<p>
										Basic info goes here, Location, Career, Group, etc.
									</p>
									<div class="mutual-friends">
										16 Mutual Friends
									</div>
								</div>
								<div class="col-md-3">
									<div class="social-media-buttons text-primary">
										<i class="fa fa-rss"></i>
										<i class="fa fa-pinterest"></i>
										<i class="fa fa-linkedin"></i>
										<i class="fa fa-facebook"></i>
										<i class="fa fa-twitter"></i>
									</div>
								</div>
							</div>
						</div>-->
						
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>