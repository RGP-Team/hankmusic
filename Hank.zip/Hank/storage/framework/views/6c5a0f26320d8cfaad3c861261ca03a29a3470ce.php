<?php $__env->startSection('content'); ?>
	

<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 profile-section">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-2">
								<div class="account-profile">
									<div class="dropdown public-profile top-margin-20">
										<?php if($user->photo): ?>
											<?php ($profile_photo = $user->photo->url); ?>
											<img src="<?php echo e($profile_photo); ?>" class="img-responsive">
										<?php else: ?>
											<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" class="img-responsive">
										<?php endif; ?>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="top-margin-30 bottom-margin-30">
									<input type="hidden" name="search-csrf" value="<?php echo e(csrf_token()); ?>">
									<h3 class="profile-name"><?php echo e(ucwords($user->first_name)); ?> <?php echo e(ucwords($user->last_name)); ?></h3>
									<small class="member"><?php echo e(CustomHelper::lang('lang-member-since')); ?> <?php echo e(CustomHelper::show_elapsed_time($user->created_at)); ?></small><br/>									
									<small class="address">
									<?php if(! empty($user->city)): ?><?php echo e($user->city); ?><?php endif; ?>
									<?php if(! empty($user->state)): ?><?php echo e(', '.$user->state); ?><?php endif; ?>
									<?php if(! empty($user->zip)): ?><?php echo e(' '.$user->zip); ?><?php endif; ?>
									<?php if(! empty($user->country)): ?><?php echo e(', '.$user->country); ?><?php endif; ?>
									</small>
									<br/><?php if(! empty($user->city)): ?><br/><?php endif; ?>
									<?php if(! Auth::guest()): ?>
										<?php if(! CustomHelper::isFriendWith( $user->id, Auth::user()->id )): ?>
											<?php if($user->id !== Auth::user()->id): ?>
											<small>
												<?php if($user->pendingRequest): ?>
													<span class="pending-request"> - <?php echo e(CustomHelper::lang('lang-pending-friend-request')); ?> - </span>
												<?php else: ?>
													<button class="btn btn-primary btn-xs" data-url="<?php echo e(url('/friends/add/request')); ?>" data-id="<?php echo e($user->id); ?>" onclick="addFriend(this)"><i class="fa fa-user-plus"></i> &nbsp;Add as Friend</button><span class="loader"></span><span class="pending-request noshow"> - Pending Friend Request - </span>
												<?php endif; ?>
											</small>
											<?php endif; ?>
										<?php else: ?>
											<small>
												<input type="hidden" name="source_id" value="<?php echo e(Auth::user()->id); ?>" />
												<input type="hidden" name="target_id" value="<?php echo e($user->id); ?>" />
												<button type="button" onclick="sendMessage(this)" class="btn btn-primary btn-xs"><i class="fa fa-envelope-o"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-send-a-message')); ?></button>
											</small>
										<?php endif; ?>
									<?php else: ?>
										<span class="login-note"><i>- <?php echo e(CustomHelper::lang('lang-login-to-interact')); ?> -</i></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-md-6">
								<div class="top-margin-30">
									<div class="col-md-3 text-center"><?php echo e(CustomHelper::lang('lang-posts')); ?> <br/><span class="stat-count"><?php echo e($user->posts->count()); ?></span></div>
									<div class="col-md-3 text-center"><?php echo e(CustomHelper::lang('lang-comments')); ?> <br/><span class="stat-count"><?php echo e($user->comments->count()); ?></span></div>
									<div class="col-md-3 text-center"><?php echo e(CustomHelper::lang('lang-down-voted')); ?> <br/><span class="stat-count"><?php echo e($user->downVotes()); ?></span></div>
									<div class="col-md-3 text-center"><?php echo e(CustomHelper::lang('lang-up-voted')); ?> <br/><span class="stat-count"><?php echo e($user->upVotes()); ?></span></div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 padding-on-side">
						
								<div class="row top-margin-40">
									<a name="artworks"></a>
									<div class="col-md-12">
										<div class="sub-topic-label">
											<h4><?php echo e(CustomHelper::lang('lang-art-works')); ?></h4>
										</div>
									</div>
								</div>
								<div class="row works-container">
									<div class="col-md-12">
										<div class="row works">
										<?php if($works->count() && ($user->freelancer || Auth::guard('admins')->check())): ?>
											<?php foreach($works as $artwork): ?>
											<div class="col-md-4 text-center">
												<div class="work-item bg-primary">
													<a href="<?php echo e($artwork->url); ?>"><img class="img-responsive" src="<?php echo e($artwork->url); ?>" border="0" /></a>
												</div>
												<div class="clear"></div>
												<span class="posted-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($artwork->created_dt))); ?></span>
												<i class="fa fa-trash-o delete-photo" onclick="confirmDeleteArtwork(<?php echo e($artwork->id); ?>)" title="Delete Artwork"></i>
											</div>
											<?php endforeach; ?>
										<?php else: ?>
											<div class="col-md-12 text-center top-margin-30">
												<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

											</div>
										<?php endif; ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<?php if($works->count() && ($user->freelancer || Auth::guard('admins')->check())): ?>
										<?php echo e($works->fragment('artworks')->links()); ?>

										<?php endif; ?>
									</div>
								</div>						
								
								<div class="clear"></div>
								<div class="row">
									<div class="col-md-12 bottom-margin-15">&nbsp;</div>
								</div>
								<div class="row">
									<a name="writings"></a>
									<div class="col-md-12">
										<div class="sub-topic-label">
											<h4><?php echo e(CustomHelper::lang('lang-writings')); ?></h4>
										</div>
									</div>
								</div>
								<?php if($articles->count() && ($user->writer || Auth::guard('admins')->check())): ?>
									<?php foreach($articles as $article): ?>
									<div class="row pad-bottom-bold bottom-margin-20 top-margin-20">
										<div class="col-md-2 text-center">
											<div class="article-thumbnail bg-primary">
												<a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore">
													<?php ( $doc = new DOMDocument() ); ?>
													<?php ( $doc->loadHTML($article->content) ); ?>
													<?php ( $img = $doc->getElementsByTagName('img')->item(0) ); ?>	
													
													<?php if(! empty($img)): ?>
														<?php ($src = $img->getAttribute('src')); ?>
														<img class="img-responsive latest-post-item" src="<?php echo e($src); ?>" border="0" />
													<?php else: ?>
														<img class="img-responsive latest-post-item" src="<?php echo e(URL::asset('images/no-image.png')); ?>" border="0" />
													<?php endif; ?>		
												</a>
											</div>
										</div>
										<div class="col-md-10 no-pad-left adjust-bottom">
											<div class="topic-title item-title"><a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore"><?php echo e(strtoupper($article->title)); ?></a><span class="topic-hour"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($article->created_dt))); ?></span></div>
											<p>
												<?php ($content = strip_tags($article->content)); ?>
												<?php if(strlen($content) > 280): ?>
													<?php ($content = substr($content, 0, 280) . '...'); ?>
												<?php endif; ?>
												
												<?php echo nl2br(e($content)); ?> <a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore"><small><?php echo e(CustomHelper::lang('lang-read-more')); ?></small></a>
											</p>
											<div class="col-md-12 text-right">
												<div class="social-media-buttons text-primary">
													<?php echo $__env->make('pages.partials._social_media_buttons', ['article' => $article], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
												</div>
											</div>
										</div>
									</div>
									<?php endforeach; ?>
								<?php else: ?>
									<div class="row pad-bottom-bold min-height-200">
										<div class="col-md-12 text-center top-margin-40">
											<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

										</div>
									</div>
								<?php endif; ?>
								<div class="row">
									<div class="col-md-12">
										<?php if($articles->count() && ($user->writer || Auth::guard('admins')->check())): ?>
										<?php echo e($articles->fragment('writings')->links()); ?>

										<?php endif; ?>
									</div>
								</div>
						
							</div>
						</div>	
							
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>								
	
	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>