<!-- Header -->
<header>
	<div class="container">
		<div id="header-row" class="row">
			<div class="col-md-1"></div>
			<?php if( ! Auth::guest()): ?>
			<div class="col-md-4">
			<?php else: ?>
			<div class="col-md-6">
			<?php endif; ?>
				<div id="logo-container">
					<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('images/logo-200.png')); ?>" alt="CG Networks Logo" border="0" /></a>
				</div>
			</div>
			<?php if( ! Auth::guest()): ?>
			<div class="col-md-6">
			<?php else: ?>
			<div class="col-md-4">
			<?php endif; ?>
				<div class="row">
					<div class="col-md-12">
						<?php if( ! Auth::guest()): ?>
							<div class="col-md-6">
								<form role="form" method="POST" action="<?php echo e(url('/search')); ?>">
								<?php echo csrf_field(); ?>

									<div class="search">
									  <span class="fa fa-search"></span>
									  <input class="search-box" name="keyword" placeholder="<?php echo e(CustomHelper::lang('lang-search-friends')); ?>">
									</div>
								</form>
							</div>
							<div class="col-md-6 text-right no-pad-right">
							
								<div class="account-profile">
									<div class="dropdown user-profile">	
										<?php if(Auth::user()->photo): ?>
											<?php ($profile_photo = Auth::user()->photo->url); ?>
											<img src="<?php echo e($profile_photo); ?>" alt="">
										<?php else: ?>
											<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
										<?php endif; ?>
										
										
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
											<?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?> <span class="caret"></span>
										</a>

										<ul class="dropdown-menu" role="menu">
											<li><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(CustomHelper::lang('lang-dashboard')); ?></a></li>
											<li><a href="<?php echo e(url('/profile/edit')); ?>"><?php echo e(CustomHelper::lang('lang-my-account')); ?></a></li>
											<li><a href="<?php echo e(url('/user/profile')); ?>/<?php echo e(Auth::user()->id); ?>"><?php echo e(CustomHelper::lang('lang-my-public-profile')); ?></a></li>
											<li><a href="<?php echo e(url('/logout')); ?>" class="border-top"><?php echo e(CustomHelper::lang('lang-logout')); ?></a></li>
										</ul>
									</div>
								</div>
								
							</div>
						<?php else: ?>
							<?php if(Route::getCurrentRoute()->getPath() !== "login"): ?>
							<div class="top-login-container">
								<form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
								<?php echo csrf_field(); ?>

								<div class="col-md-5 login-email form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
									<?php echo e(CustomHelper::lang('lang-email')); ?><br/>
									<input type="email" name="email" value="<?php echo e(old('email')); ?>" class="img-responsive form-control" />
								</div>
								<div class="col-md-5 login-password form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
									<?php echo e(CustomHelper::lang('lang-password')); ?><br/>
									<input type="password" name="password" class="img-responsive form-control" />
								</div>
								<div class="col-md-2">
									&nbsp;<br/>
									<button class="btn btn-xs btn-primary"><?php echo e(CustomHelper::lang('lang-login')); ?></button>
								</div>
								</form>
							</div>
							<div class="top-action-buttons">
								<div class="col-md-10 links text-right">
									<a href="<?php echo e(url('/password/reset')); ?>"><?php echo e(CustomHelper::lang('lang-forgot-password')); ?>?</a> <?php echo e(CustomHelper::lang('lang-or')); ?> <a href="<?php echo e(url('/register')); ?>"><?php echo e(CustomHelper::lang('lang-signup')); ?></a>
								</div>
								<div class="col-md-2">&nbsp;</div>
							</div>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
</header>