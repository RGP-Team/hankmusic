<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 friends-container">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-pending-friend-requests')); ?></h4>
								</div>
								<?php if(session()->has('success_message')): ?>
									<div class="alert alert-success">
										<?php echo e(session()->get('success_message')); ?>

									</div>
								<?php endif; ?>
								<?php if(count($errors->all())): ?>
									<div class="alert alert-danger">
										<ul>
										<?php foreach($errors->all() as $error): ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; ?>
										</ul>
									</div>
								<?php else: ?>
									<?php if(session()->has('error_message')): ?>
									<div class="alert alert-danger">
										<?php echo e(session()->get('error_message')); ?>

									</div>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 min-height-300 top-margin-40">
								<div class="row search-results">
									<?php if($requests->count()): ?>
										<?php foreach($requests as $item): ?>
											<?php ($user = $item->source); ?>
											<div class="col-md-6 search-item user-profile text-left">
												<div class="col-md-3">
													<?php if($user->photo): ?>
														<?php ($profile_photo = $user->photo->url); ?>
														<img src="<?php echo e($profile_photo); ?>" alt="">
													<?php else: ?>
														<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
													<?php endif; ?>
												</div>
												<div class="col-md-9">
													<h3 class="profile-name"><a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($user->id); ?>"><?php echo e(ucwords($user->first_name)); ?> <?php echo e(ucwords($user->last_name)); ?></a>&nbsp;
													<small class="mutual-friends-container">
														 (<strong><?php echo e(CustomHelper::getMutualFriendsCount( $user->id, Auth::user()->id )); ?></strong> <?php echo e(CustomHelper::lang('lang-mutual-friends')); ?>)
													</small>
													</h3>
													<small class="member"><?php echo e(CustomHelper::lang('lang-member-since')); ?> <?php echo e(CustomHelper::show_elapsed_time($user->created_at)); ?></small><br/>									
													<small class="address">
													<?php if(! empty($user->city)): ?><?php echo e($user->city); ?><?php endif; ?>
													<?php if(! empty($user->state)): ?><?php echo e(', '.$user->state); ?><?php endif; ?>
													<?php if(! empty($user->zip)): ?><?php echo e(' '.$user->zip); ?><?php endif; ?>
													<?php if(! empty($user->country)): ?><?php echo e(', '.$user->country); ?><?php endif; ?>
													</small>
													<small>
														<?php ($info = CustomHelper::checkPageLimit()); ?>
														<?php if((int)$info['remaining_slot'] !== 0): ?>
														<form method="POST" class="form-inline" action="<?php echo e(url('/friends/add')); ?>">
														<?php echo csrf_field(); ?>

														<input type="hidden" name="id" value="<?php echo e($item->id); ?>">
														<button class="btn btn-primary btn-xs"><i class="fa fa-user-plus"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-add-friend')); ?></button> &nbsp;
														</form>
														<?php endif; ?>
														<form method="POST" class="form-inline" action="<?php echo e(url('/friends/delete/request')); ?>">
														<?php echo csrf_field(); ?>

														<input type="hidden" name="id" value="<?php echo e($item->id); ?>">
														<button class="btn btn-default btn-xs"><i class="fa fa-trash-o"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-delete')); ?></button>
														</form>
													</small>
												</div>
											</div>
										<?php endforeach; ?>
									<?php else: ?>
										<div class="col-md-12 text-center top-margin-40">
											<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>