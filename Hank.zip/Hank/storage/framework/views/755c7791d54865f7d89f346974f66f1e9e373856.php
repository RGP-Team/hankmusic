<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">
									<h3>Settings</h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>	
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-9 form">
											

											<div class="form-tab">	
												<ul class="nav nav-tabs">
													<li class="active"><a  href="#1" data-toggle="tab">General</a></li>
													<?php if(Auth::guard('admins')->user()->can_manage_authorizenet): ?>
													<li><a href="#2" data-toggle="tab">Authorize.Net</a></li>
													<?php endif; ?>
													<li><a href="#3" data-toggle="tab">Default Language</a></li>
													<?php if(Auth::guard('admins')->user()->can_manage_plan): ?>
													<li><a href="#4" data-toggle="tab">Subscription Plans</a></li>
													<?php endif; ?>
												</ul>
												<div class="tab-content ">
													<div class="tab-pane active" id="1">
														<!-- General -->
														
														<?php echo Form::open(array('route' => 'admin.settings.save', 'method' => 'POST', 'id' => 'general-form')); ?>										
														<input type="hidden" name="type" value="general">
														<div class="form-group row">
														  <legend class="legend">Website</legend>
														  <label class="col-sm-3 col-form-label">Site Title</label>
														  <div class="col-sm-9">
															<input type="text" name="website_title" class="form-control" value="<?php echo e($data->settings->website_title); ?>" placeholder="Your site title">
														  </div>
														</div>
														<div class="form-group row">
														  <label class="col-sm-3 col-form-label">Contact Number</label>
														  <div class="col-sm-9">
															<input type="text" name="contact_number" class="form-control" value="<?php echo e($data->settings->contact_number); ?>" placeholder="Your contact number">
														  </div>
														</div>
														<div class="form-group row">
														  <label class="col-sm-3 col-form-label">Contact Notes</label>
														  <div class="col-sm-9">
															<textarea name="contact_notes" rows="5" class="form-control" placeholder="Your contact notes"><?php echo e($data->settings->contact_notes); ?></textarea>
														  </div>
														</div>
														<div class="form-group row">
														  <label class="col-sm-3 col-form-label">E-mail Address</label>
														  <div class="col-sm-9">
															<input type="text" name="email" class="form-control" value="<?php echo e($data->settings->email); ?>" placeholder="Your e-mail address">
														  </div>
														</div>
														<div class="form-group row">
														  <label class="col-sm-3 col-form-label">Copyright Text</label>
														  <div class="col-sm-9">
															<input type="text" name="copyright" class="form-control" value="<?php echo e($data->settings->copyright); ?>" placeholder="Your text for copyright displayed at the footer of the website">
														  </div>
														</div>														
														<div class="form-group row">
														  <legend class="legend">Pagination</legend>
														  <label class="col-sm-3 col-form-label">Items Per Page</label>
														  <div class="col-sm-9">
															<input type="number" name="items_per_page" class="form-control" value="<?php echo e($data->settings->items_per_page); ?>" placeholder="Default number of items displayed per page">
														  </div>
														</div>
														<div class="form-group row">
														  <label class="col-sm-3 col-form-label">Load More Items</label>
														  <div class="col-sm-9">
															<input type="number" name="load_more_items" class="form-control" value="<?php echo e($data->settings->load_more_items); ?>" placeholder="Default number of items to load when the 'Load more' button is clicked">
														  </div>
														</div>
														<div class="form-group row">
														  <label class="col-sm-3 col-form-label">Comments Per Post</label>
														  <div class="col-sm-9">
															<input type="number" name="comments_per_post" class="form-control" value="<?php echo e($data->settings->comments_per_post); ?>" placeholder="Default number of comments initially displayed per post">
														  </div>
														</div>																											
														<div class="row">
															<div class="col-md-12 top-margin-20">
																<button class="btn btn-primary">Save Settings</button>
															</div>
														</div>
														<?php echo Form::close(); ?>

														
														<!-- /General -->
													</div>
													<?php if(Auth::guard('admins')->user()->can_manage_authorizenet): ?>
													<div class="tab-pane" id="2">
														<!-- Authorize.Net -->
														
														<?php echo Form::open(array('route' => 'admin.settings.save', 'method' => 'POST', 'id' => 'authorizenet-form')); ?>

															<input type="hidden" name="type" value="authorizenet">
															<div class="form-group row">
															  <label class="col-sm-3 col-form-label">API Login ID</label>
															  <div class="col-sm-9">
																<input type="text" name="login_id" class="form-control" value="<?php echo e($data->settings->authorizenet_api_login_id); ?>" placeholder="Your API Login ID">
															  </div>
															</div>
															<div class="form-group row">
															  <label class="col-sm-3 col-form-label">Transaction Key</label>
															  <div class="col-sm-9">
																<input type="text" name="trans_key" class="form-control" value="<?php echo e($data->settings->authorizenet_api_trans_key); ?>" placeholder="Your API Transaction Key">
															  </div>
															</div>
														<div class="row">
															<div class="col-md-12 top-margin-20">
																<button class="btn btn-primary">Save Settings</button>
															</div>
														</div>
														<?php echo Form::close(); ?>

														
														<!-- /Authorize.Net -->
													</div>
													<?php endif; ?>
													<div class="tab-pane" id="3">
														<!-- Default Language -->
														
														<?php echo Form::open(array('route' => 'admin.settings.save', 'method' => 'POST', 'id' => 'language-form')); ?>

															<input type="hidden" name="type" value="language">
															<fieldset class="form-group row">
															  <label class="col-sm-2">Language</label>
															  <div class="col-sm-10">
																<div class="form-check">
																  <label class="form-check-label">
																	<input class="form-check-input" type="radio" name="language" value="en" <?php if($data->settings->default_language === 'en'): ?><?php echo e('checked'); ?><?php endif; ?>>
																	English (en/eng)
																  </label>
																</div>
																<div class="form-check">
																  <label class="form-check-label">
																	<input class="form-check-input" type="radio" name="language" value="es" <?php if($data->settings->default_language === 'es'): ?><?php echo e('checked'); ?><?php endif; ?>>
																	Spanish (es/spa)
																  </label>
																</div>
																<div class="form-check disabled">
																  <label class="form-check-label">
																	<input class="form-check-input" type="radio" name="language" value="zh" <?php if($data->settings->default_language === 'zh'): ?><?php echo e('checked'); ?><?php endif; ?>>
																	Chinese (zh/chi)
																  </label>
																</div>
															  </div>
															</fieldset>
														<div class="row">
															<div class="col-md-12 top-margin-20">
																<button class="btn btn-primary">Save Settings</button>
															</div>
														</div>
														<?php echo Form::close(); ?>

														
														<!-- /Default Language -->
													</div>
													<?php if(Auth::guard('admins')->user()->can_manage_plan): ?>
													<div class="tab-pane" id="4">
														<!-- Subscription Plans -->
														<a name="plan-form-location"></a>
														<div class="row">
															<div class="col-md-12 bottom-margin-30">
																<button id="toggle-plan" class="btn btn-default margin-t-5"><i class="fa fa-edit"></i> <span>New Plan</span></button>
															</div>
														</div>
														
														<div class="plan-container noshow bottom-margin-50">
															<?php echo Form::open(array('route' => 'admin.plans.save', 'method' => 'POST', 'id' => 'plan-form')); ?>

																<input type="hidden" name="plan_id">
																<div class="form-group row">
																  <label class="col-sm-3 col-form-label">Plan Title</label>
																  <div class="col-sm-9">
																	<input type="text" name="title" class="form-control" placeholder="Your Plan Title">
																  </div>
																</div>
																<div class="form-group row">
																	<label class="col-sm-3 col-form-label">Description or Benefits</label>
																	<div class="col-sm-9">
																		<textarea name="description" class="form-control" rows="3" placeholder="Describe the benefits of this plan here..."></textarea>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-sm-3 col-form-label">Page Limit</label>
																	<div class="col-sm-9">
																		<input type="number" name="page_limit" class="form-control" placeholder="Total number of pages allowed for this plan">
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-sm-3 col-form-label">Post Word Limit</label>
																	<div class="col-sm-9">
																		<input type="number" name="word_limit" class="form-control" placeholder="Number of words allowed for this plan when creating a post or comment">
																	</div>
																</div>
																<div class="form-group row">
																  <label class="col-sm-3 col-form-label">Recurring Amount</label>
																  <div class="col-sm-9">
																	
																		<div class="form-inline form-group">
																			<label class="sr-only">Amount (in dollars)</label>
																			<div class="input-group">
																			  <div class="input-group-addon">$</div>
																			  <input type="number" step="any" name="amount" class="form-control" placeholder="Amount">	
																			</div>&nbsp;
																			<small class="form-text text-muted">Monthly recurring amount for this plan.</small>
																		</div>
																		
																	
																  </div>
																</div>
															<div class="row">
																<div class="col-md-12 top-margin-10 text-right">
																	<button class="btn btn-primary">Save Plan</button>
																</div>
															</div>
															<?php echo Form::close(); ?>

														</div>														
														
														
														<div class="row">
															<div class="col-md-12">
																<table id="datatable" data-entity="plans" class="table table-striped table-bordered">
																  <thead>
																	<tr>
																	  <?php foreach($data->headers as $header): ?>
																			<th><?php echo e(ucwords(str_replace('_', ' ', $header))); ?></th>
																	  <?php endforeach; ?>
																	  <th id="action" width="15%">Action</th>
																	</tr>
																  </thead>
																  <tbody ng-model="listings">
																		<?php foreach($data->collection as $item): ?>																			
																		<tr class="table-row" data-id="<?php echo e($item->id); ?>" data-item="<?php echo e($item); ?>" data-entity="plans">
																			<?php foreach($data->headers as $header): ?>
																				<?php ($content = $item[$header]); ?>
																				<td><?php echo e($content); ?></td>
																			<?php endforeach; ?>																			
																			<td align="center" class="action-item">
																				<a href="javascript://" class="action-button" data-action="delete" data-id="<?php echo e($item->id); ?>" data-entity="plans"><i class="fa fa-trash-o action-icons"></i> Delete</a>
																			</td>
																		</tr>
																		<?php endforeach; ?>																		
																  </tbody>
																</table>	
																<a id="gotoLocation" href="#plan-form-location"></a>
																	
															</div>
														</div>
														
														
														
														<!-- /Subscription Plans -->
													</div>
													<?php endif; ?>
												</div>
											</div>
											
											
											
											
										</div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>