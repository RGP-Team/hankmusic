<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 dashboard-section">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<a name="artworks"></a>
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-your-art-works')); ?> <?php if(! Auth::user()->freelancer): ?>&nbsp;<small>( Send a request to activate your "Freelancer" privilege <a href="javascript://" onclick="activateRequest(<?php echo e(Auth::user()->id); ?>, 'freelancer')">here</a>, to make your art work(s) public. )</small><?php endif; ?></h4>
								</div>
							</div>
						</div>
						<?php if(session()->has('success_message')): ?>
							<div class="alert alert-success save-message">
								<?php echo e(session()->get('success_message')); ?>

							</div>
						<?php endif; ?>
						<?php if($errors->has('content') || session()->has('error_message')): ?>
							<div class="alert alert-danger save-message">
								<?php if(session()->has('error_message')): ?>
									<?php echo e(session()->get('error_message')); ?>

								<?php else: ?>
									<?php echo e($errors->first('content')); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-md-12 top-margin-20">
							<?php ($info = CustomHelper::checkPageLimit()); ?>
							<?php if((int)$info['remaining_slot'] !== 0): ?>
								<?php if(Auth::user()->freelancer): ?>
									<?php echo Form::open(array('route' => 'works.upload', 'method' => 'POST', 'id' => 'works-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

										<button id="works-upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> <?php echo e(CustomHelper::lang('lang-upload-art-work')); ?></button>
										<div id="img-thumb-preview">
										  <span class="processing-msg" style="display:none;"><?php echo e(CustomHelper::lang('lang-processing')); ?></span>
										</div>
									<?php echo Form::close(); ?>

								<?php endif; ?>
							<?php endif; ?>
							</div>
						</div>
						<div class="row works-container">
							<div class="col-md-12">
								<div class="row works min-height-200">
								<?php if($works->count()): ?>
									<?php foreach($works as $artwork): ?>
									<div class="col-md-4 text-center">
										<div class="work-item bg-primary">
											<a href="<?php echo e($artwork->url); ?>"><img class="img-responsive" src="<?php echo e($artwork->url); ?>" border="0" /></a>
										</div>
										<div class="clear"></div>
										<span class="posted-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($artwork->created_dt))); ?></span>
										<i class="fa fa-trash-o delete-photo" onclick="confirmDeleteArtwork(<?php echo e($artwork->id); ?>)" title="Delete Artwork"></i>
									</div>
									<?php endforeach; ?>
								<?php else: ?>
									<div class="col-md-12 text-center top-margin-30">
										<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

									</div>
								<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?php echo e($works->fragment('artworks')->links()); ?>

							</div>
						</div>						
						
						<div class="clear"></div>
						<div class="row">
							<div class="col-md-12 bottom-margin-15">&nbsp;</div>
						</div>
						<div class="row">
							<a name="writings"></a>
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-your-writings')); ?> <?php if(! Auth::user()->writer): ?>&nbsp;<small>( Send a request to activate your "Writer" privilege <a href="javascript://" onclick="activateRequest(<?php echo e(Auth::user()->id); ?>, 'writer')">here</a>, to make your article(s) public. )</small><?php endif; ?></h4>
								</div>
							</div>
						</div>
						<?php if(session()->has('articles_success_message')): ?>
							<div class="alert alert-success save-message">
								<?php echo e(session()->get('articles_success_message')); ?>

							</div>
						<?php endif; ?>
						<?php ($hasErrors = false); ?>
						<?php if($errors->has('content') || session()->has('articles_error_message')): ?>
							<div class="alert alert-danger save-message">
								<?php if(session()->has('articles_error_message')): ?>
									<?php ($hasErrors = true); ?>
									<ul>
										<?php if(is_array(session()->get('articles_error_message'))): ?>
											<?php foreach(session()->get('articles_error_message') as $error): ?>
												<li><?php echo e($error->message); ?></li>
											<?php endforeach; ?>
										<?php else: ?>
											<?php echo e(session()->get('articles_error_message')); ?>

										<?php endif; ?>
									</ul>
								<?php endif; ?>
							</div>
						<?php endif; ?>
						<?php if(Auth::user()->writer): ?>
							<div class="row">
								<div class="col-md-12 top-margin-20 bottom-margin-20">
									<?php ($info = CustomHelper::checkPageLimit()); ?>
									<?php if((int)$info['remaining_slot'] !== 0): ?>
										<button id="toggle-editor" class="btn btn-default margin-t-5"><i class="fa fa-edit"></i> <span><?php echo e(CustomHelper::lang('lang-new-article')); ?></span></button>
									<?php endif; ?>
								</div>
							</div>
							<div class="row editor-container <?php if(! $hasErrors): ?> noshow <?php endif; ?>">
								<div class="col-md-12">
									<?php echo Form::open(array('route' => 'articles.create', 'method' => 'POST')); ?>

									<div class="row">
										<div class="col-md-12 bottom-margin-10">
											<div class="col-md-2 embed-label"><?php echo e(CustomHelper::lang('lang-article-title')); ?></div>
											<div class="col-md-10 embed-field">
												<input type="text" name="title" value="<?php echo e(Request::old('title')); ?>" placeholder="<?php echo e(CustomHelper::lang('lang-article-title-placeholder')); ?>" />
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<!--<div class="editor min-height-300"></div>-->
											<textarea name="content" class="editor" rows="10" placeholder="<?php echo e(CustomHelper::lang('lang-article-body-placeholder')); ?>"><?php echo e(Request::old('content')); ?></textarea>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 text-right">
											<button class="btn btn-primary"><?php echo e(CustomHelper::lang('lang-submit-article')); ?></button>
										</div>
									</div>
									<?php echo Form::close(); ?>

								</div>
							</div>
						<?php else: ?>
							<div class="row">
								<div class="col-md-12 top-margin-20">&nbsp;</div>
							</div>
						<?php endif; ?>
						<?php if($articles->count()): ?>
							<?php foreach($articles as $article): ?>
							<div class="row pad-bottom-bold bottom-margin-20">
								<div class="col-md-2 text-center">
									<div class="article-thumbnail bg-primary">
										<a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore">
											<?php ( $doc = new DOMDocument() ); ?>
											<?php ( $doc->loadHTML($article->content) ); ?>
											<?php ( $img = $doc->getElementsByTagName('img')->item(0) ); ?>	
											
											<?php if(! empty($img)): ?>
												<?php ($src = $img->getAttribute('src')); ?>
												<img class="img-responsive latest-post-item" src="<?php echo e($src); ?>" border="0" />
											<?php else: ?>
												<img class="img-responsive latest-post-item" src="<?php echo e(URL::asset('images/no-image.png')); ?>" border="0" />
											<?php endif; ?>		
										</a>
									</div>
								</div>
								<div class="col-md-10 no-pad-left adjust-bottom">
									<div class="topic-title item-title"><a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore"><?php echo e(strtoupper($article->title)); ?></a><span class="topic-hour"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($article->created_dt))); ?></span></div>
									<p>
										<?php ($content = strip_tags($article->content)); ?>
										<?php if(strlen($content) > 280): ?>
											<?php ($content = substr($content, 0, 280) . '...'); ?>
										<?php endif; ?>
										
										<?php echo nl2br(e($content)); ?> <a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore"><small><?php echo e(CustomHelper::lang('lang-read-more')); ?></small></a>
									</p>
									<div class="col-md-12 text-right">
										<div class="social-media-buttons text-primary">
											<?php echo $__env->make('pages.partials._social_media_buttons', ['article' => $article], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						<?php else: ?>
							<div class="row pad-bottom-bold min-height-200">
								<div class="col-md-12 text-center top-margin-30">
									<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

								</div>
							</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-md-12">
								<?php echo e($articles->fragment('writings')->links()); ?>

							</div>
						</div>
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>						
						