<div class="container-fluid">  
	<div class="row">
		<div class="col-lg-12">
			<h1>CG Networks <span class="dashboard-label">Dashboard</span> &nbsp;<small class="frontend-link">(Open your <a href="/" target="_blank">frontend website</a> in a new tab)</small></h1>
			<p>This is where you manage and control how your visitors and customers interact with your website. Below are some quick access buttons to each of the functionalities that is being handled and controlled by this Admin Panel.</p>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<h3>Access Admin Sections Quickly Through These Icons</h3>
		</div>
	</div>
	<div class="row quick-access-container">
		<?php if(Auth::guard('admins')->user()->can_manage_post): ?>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/posts')); ?>"><i class="fa fa-pencil-square-o"></i></a> Posts
		</div>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/comments')); ?>"><i class="fa fa-commenting-o"></i></a> Comments
		</div>
		<?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_user): ?>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/users')); ?>"><i class="fa fa-users"></i></a> Users
		</div>
		<?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_admin): ?>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/admins')); ?>"><i class="fa fa-user-secret"></i></a> Admins
		</div>
		<?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_category): ?>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/categories')); ?>"><i class="fa fa-cubes"></i></a> Categories
		</div>
		<?php endif; ?>
		<?php if(Auth::guard('admins')->user()->can_manage_approval): ?>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/approval/freelancers')); ?>"><i class="fa fa-user-plus"></i></a> Freelancer Approvals
		</div>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/approval/writers')); ?>"><i class="fa fa-pencil"></i></a> Writer Approvals
		</div>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/approval/videos')); ?>"><i class="fa fa-video-camera"></i></a> Video Approvals
		</div>
		<?php endif; ?>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/subscribers')); ?>"><i class="fa fa-envelope-o"></i></a> Newsletter Subscribers
		</div>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/settings')); ?>"><i class="fa fa-gears"></i></a> Site Settings
		</div>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/banners')); ?>"><i class="fa fa-map-o"></i></a> Banners
		</div>
		<div class="col-md-3 col-sm-4 col-xs-6 quick-access-item text-center">
			<a href="<?php echo e(url('/admin/languages')); ?>"><i class="fa fa-globe"></i></a> Multilanguage
		</div>
	</div>
</div> 