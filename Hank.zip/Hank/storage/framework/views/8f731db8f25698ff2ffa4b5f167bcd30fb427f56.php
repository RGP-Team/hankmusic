<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 public-videos">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-12">
								<div class="bottom-margin-40">
									<h3><?php echo e(CustomHelper::lang('lang-latest-videos')); ?></h3>
								</div>
							</div>
						</div>
						<div class="row videos-container">
							<div class="col-md-12">
								<div class="row videos min-height-200">
								<?php if($videos->count()): ?>
									<?php foreach($videos as $video): ?>
									<div class="col-md-3 text-center">
										<div class="video-item bg-primary">
											<a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>"><img class="img-responsive" src="<?php echo e(URL::asset('images/play-video.png')); ?>" border="0" /></a>
										</div>
										<div class="clear"></div>
										<?php ($video_title = $video->title); ?>
										<?php if(strlen($video->title) > 30): ?>
											<?php ($video_title = substr($video->title, 0, 26) . '...'); ?>
										<?php endif; ?>
										<div class="video-title"><a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>"><?php echo e($video_title); ?></a></div>
										<span class="uploaded-by"><?php echo e($video->user->first_name); ?> <?php echo e($video->user->last_name); ?></span>
										<span class="topic-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted')); ?> <?php echo e(CustomHelper::show_elapsed_time($video->created_dt)); ?>, <?php echo e($video->views); ?> <?php echo e(CustomHelper::lang('lang-views')); ?></span>
										<div class="bottom-margin-20"></div>
									</div>
									<?php endforeach; ?>
								<?php else: ?>
									<div class="col-md-12 text-center top-margin-30">
										<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

									</div>
								<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 top-margin-10">
								<?php echo e($videos->links()); ?>

							</div>
						</div>
						
						
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>