<?php 
	$photos = array();
	if (! Auth::guest()) $photos = App\Models\Photo::where('user_id', Auth::user()->id)->get();
	
	$popular_articles = \App\Models\Article::popular();
?>
<footer>
	<div class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">
					
					<!-- start of footer content -->
					
					<div class="row">
						<div class="col-md-4">
							<div class="contact-information">
							  <h3><?php echo e(CustomHelper::lang('lang-contact-information')); ?></h3>
							  <div class="contact-number"><i class="fa fa-phone"></i> <?php echo e($settings->contact_number); ?></div>
							  <div class="contact-email"><i class="fa fa-envelope"></i> <?php echo e($settings->email); ?></div>
							  <p class="note"><?php echo nl2br(e($settings->contact_notes)); ?></p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="popular-articles">
							  <h3><?php echo e(CustomHelper::lang('lang-popular-articles')); ?></h3>
							  <ul>
								<?php if($popular_articles->count()): ?>
									<?php foreach($popular_articles as $article): ?>
									<li>
										<?php ($article_title = $article->title); ?>
										<?php if(strlen($article_title) > 25): ?>
											<?php ($article_title = substr($article_title, 0, 25) . '...'); ?>
										<?php endif; ?>
										
										<?php ( $doc = new DOMDocument() ); ?>
										<?php ( $doc->loadHTML($article->content) ); ?>
										<?php ( $img = $doc->getElementsByTagName('img')->item(0) ); ?>	
										
										<table>
										<tr>
											<td width="57" valign="top">
											<a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="readmore">
											<?php if(! empty($img)): ?>
												<?php ($src = $img->getAttribute('src')); ?>
												<img class="img-responsive latest-post-item" width="57" height="37" align="left" src="<?php echo e($src); ?>" border="0" />
											<?php else: ?>
												<img class="img-responsive latest-post-item" width="57" height="37" align="left" src="<?php echo e(URL::asset('images/no-image.png')); ?>" border="0" />
											<?php endif; ?>	
											</a>
											</td>
											<td width="10">&nbsp;</td>
											<td>
											<a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>"><b><?php echo e($article_title); ?></b></a> &nbsp;<span class="comment-count"><?php echo e($article->views); ?> <?php echo e(CustomHelper::lang('lang-views')); ?></span><br/>
											<?php ($content = strip_tags($article->content)); ?>
											<?php if(strlen($content) > 90): ?>
												<?php ($content = substr($content, 0, 90) . '...'); ?>
											<?php endif; ?>
											
											<?php echo nl2br(e($content)); ?>

											</td>
										</tr>
										</table>
									</li>
									<?php endforeach; ?>
								<?php else: ?>
									<li class="pad-bottom">
										No articles available.
									</li>
								<?php endif; ?>
								
								
							  </ul>
							  <a href="<?php echo e(url('/all/articles')); ?>" class="show-all-articles"><?php echo e(CustomHelper::lang('lang-show-all-articles')); ?></a>
							</div>
						</div>
						<div class="col-md-4">
							<?php echo Form::open(array('route' => 'newsletter.subscribe', 'method' => 'POST')); ?>

							<div class="subscribe-newsletter">
							  <h3><?php echo e(CustomHelper::lang('lang-subscribe-newsletter')); ?></h3>
							  <p class="note"><?php echo e(CustomHelper::lang('lang-newsletter-notes')); ?></p>
							  <div class="newsletter-form">
								<input type="text" name="name" placeholder="<?php echo e(CustomHelper::lang('lang-name')); ?>..">
								<input type="text" name="email" placeholder="<?php echo e(CustomHelper::lang('lang-email-address')); ?>..">
								<input type="submit" value="<?php echo e(CustomHelper::lang('lang-subscribe')); ?>">
							  </div>
							</div>
							<?php echo Form::close(); ?>

						</div>
					</div>
					
					<!-- end of footer content -->
					
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
	</div>
	<div id="copyright-links-container" class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10">
				
				<!-- start of footer content -->
				
				<div class="row">
					<div class="col-md-6">
						<div class="copyright"><?php echo e($settings->copyright); ?></div>
					</div>
					<div class="col-md-6">
						<div class="footer-links"><a href="<?php echo e(url('/')); ?>"><?php echo e(CustomHelper::lang('lang-homepage')); ?></a> / <a href=""><?php echo e(CustomHelper::lang('lang-blog-view')); ?></a> / <a href=""><?php echo e(CustomHelper::lang('lang-photo-gallery')); ?></a> / <a href=""><?php echo e(CustomHelper::lang('lang-contact-us')); ?></a></div>
					</div>
				</div>
				
				<!-- end of footer content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
	<div id="embed_video_form"  class="white-popup mfp-hide">
		<div class="embed-container">
			<div class="row"
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-12">
							<h3><?php echo e(CustomHelper::lang('lang-embed-your-video')); ?></h3>
							<span><?php echo e(CustomHelper::lang('lang-embed-video-note')); ?></span>
						</div>
					</div>
					<div class="embed-form-container">
						<div class="row embed-form bottom-margin-10">
							<div class="col-md-2 embed-label"><?php echo e(CustomHelper::lang('lang-url')); ?></div>
							<div class="col-md-10 embed-field">
								<input type="text" name="embed_url" value="" placeholder="<?php echo e(CustomHelper::lang('lang-video-url-placeholder')); ?>" />
							</div>
						</div>
						<div class="row embed-form">
							<div class="col-md-2 embed-label"><?php echo e(CustomHelper::lang('lang-video-title')); ?></div>
							<div class="col-md-10 embed-field">
								<input type="text" name="video_title" value="" placeholder="<?php echo e(CustomHelper::lang('lang-video-title-placeholder')); ?>" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 text-right">
							<button class="btn btn-primary attach-video"><?php echo e(CustomHelper::lang('lang-embed-video-button')); ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="upload_image_form"  class="white-popup mfp-hide">
		<div class="tab-container">
			<div class="row"
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-12">
							<h3><?php echo e(CustomHelper::lang('lang-upload-photo')); ?></h3>
							<span><?php echo e(CustomHelper::lang('lang-upload-photo-note')); ?></span><br/><br/>
						</div>
					</div>
					<div class="tab-form-container">
						
						<ul class="nav nav-tabs">
							<li class="active">
								<a  href="#from-photos" data-toggle="tab"><?php echo e(CustomHelper::lang('lang-from-photos')); ?></a>
							</li>
							<li>
								<a href="#from-computer" data-toggle="tab"><?php echo e(CustomHelper::lang('lang-from-computer')); ?></a>
							</li>
						</ul>

						<div class="tab-content ">
							<div class="tab-pane active" id="from-photos">
								<div class="row photos">
									<?php if(! Auth::guest()): ?>
										<?php if($photos->count()): ?>
											<?php foreach( $photos as $photo ): ?>
												<div class="photo bg-primary">
													<img src="<?php echo e($photo->url); ?>" class="img-responsive photo-select" border="0" />
												</div>
											<?php endforeach; ?>
										<?php else: ?>
											<div class="no-photos">You haven't uploaded any photos yet.</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="tab-pane" id="from-computer">
								<div class="row embed-form">
									<div class="col-md-12 embed-field">
										<?php echo Form::open(array('route' => 'photos.upload', 'method' => 'POST', 'id' => 'photo-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

											<button id="upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> <?php echo e(CustomHelper::lang('lang-upload-picture')); ?></button>
											<div id="img-thumb-preview">
											  <span class="processing-msg" style="display:none;">Processing, please wait...</span>
											  <div class="img-thumbnail">
												<img id="img-thumb" class="user size-lg img-responsive photo-select" src="">
											  </div>
											</div>
										<?php echo Form::close(); ?>

									</div>
								</div>
							</div>
							<input type="hidden" name="photo-selected" value="" />
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-8">
							<div class="selected-status">
								<?php echo e(CustomHelper::lang('lang-no-photo-selected')); ?>

							</div>
						</div>
						<div class="col-md-4 text-right">
							<button class="btn btn-primary attach-photo"><?php echo e(CustomHelper::lang('lang-attach-photos')); ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="share_comment_form"  class="white-popup mfp-hide">
		<div class="share-container">
			<div class="row"
				<div class="col-md-12">
					<form role="form" method="POST" action="<?php echo e(url('/posts/share')); ?>" onsubmit="return checkEmails(this);">
					<?php echo csrf_field(); ?>

					<input type="hidden" name="post_id" value="" />
					<input type="hidden" name="comment_id" value="" />
					<input type="hidden" name="type" value="" />
					<input type="hidden" name="link" value="" />
					<div class="row">
						<div class="col-md-12">
							<h3><?php echo e(CustomHelper::lang('lang-share')); ?></h3>
							<span><?php echo e(CustomHelper::lang('lang-share-note')); ?></span>
						</div>
					</div>
					<div class="embed-form-container">
						<div class="row embed-form">
							<div class="col-md-2 embed-label"><?php echo e(CustomHelper::lang('lang-emails')); ?></div>
							<div class="col-md-10 embed-field">
								<input type="text" name="email_addresses" value="" placeholder="<?php echo e(CustomHelper::lang('lang-share-placeholder')); ?>" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 text-right">
							<button class="btn btn-primary"><?php echo e(CustomHelper::lang('lang-send')); ?></button>
						</div>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div id="send_message_form"  class="white-popup mfp-hide">
		<div class="message-container">
			<div class="row"
				<div class="col-md-12">
					<form role="form" method="POST" action="<?php echo e(url('/messages/send')); ?>" onsubmit="return checkMessage(this);">
					<?php echo csrf_field(); ?>

					<input type="hidden" name="source_id" value="" />
					<input type="hidden" name="target_id" value="" />
					<div class="row">
						<div class="col-md-12">
							<h3><?php echo e(CustomHelper::lang('lang-send-message')); ?></h3>
							<span class="message-form-note"><?php echo e(CustomHelper::lang('lang-send-message-notes')); ?></span>
						</div>
					</div>
					<div class="message-form-container">
						<div class="row">
							<div class="col-md-12">
								<textarea rows="7" name="message" class="message-box" placeholder="<?php echo e(CustomHelper::lang('lang-send-message-placeholder')); ?>"></textarea>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 text-right">
							<button class="btn btn-primary"><?php echo e(CustomHelper::lang('lang-send')); ?></button>
						</div>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div id="activation_form"  class="white-popup mfp-hide">
		<div class="message-container">
			<div class="row"
				<div class="col-md-12">
					<form role="form" method="POST" action="<?php echo e(url('/activation/request')); ?>" onsubmit="return checkMessage(this);">
					<?php echo csrf_field(); ?>

					<input type="hidden" name="type" value="" />
					<input type="hidden" name="user_id" value="" />
					<div class="row">
						<div class="col-md-12">
							<h3><?php echo e(CustomHelper::lang('lang-privilege-activation')); ?></h3>
							<span class="message-form-note"><?php echo e(CustomHelper::lang('lang-privilege-activation-notes')); ?></span>
						</div>
					</div>
					<div class="message-form-container">
						<div class="row">
							<div class="col-md-12">
								<textarea rows="7" name="message" class="message-box" placeholder="Enter your message here..."></textarea>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 text-right">
							<button class="btn btn-primary"><?php echo e(CustomHelper::lang('lang-send-request')); ?></button>
						</div>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<!-- JQuery JavaScript -->
    <?php echo e(Html::script('js/jquery-1.12.3.min.js')); ?>

	<!-- Bootstrap JavaScript -->
    <?php echo e(Html::script('bootstrap/js/bootstrap.min.js')); ?>

    <!-- Custom JavaScript -->
	<?php echo e(Html::script('js/jquery.magnific-popup.min.js')); ?>

	<?php echo e(Html::script('js/jquery.word-and-character-counter.js')); ?>

	
	<!-- Upload Javascript -->
	<?php echo e(Html::script('js/dropzone.js')); ?>

	<?php echo e(Html::script('js/bootstrap-dialog.min.js')); ?>

	<?php echo e(Html::script('js/jquery.easyeditor.js')); ?>

	<?php echo e(Html::script('js/nav.js')); ?>

	
    <?php echo e(Html::script('js/script.js')); ?>

	
	<script>
		var limit = 0;
		<?php if(! Auth::guest()): ?>
			limit = <?php echo e(Auth::user()->post_word_limit); ?>;
		<?php endif; ?>
		
		var photosContainerParent = null;
		var videosContainerParent = null;
		var videosContainer = null;
		jQuery(document).ready(function(){
			jQuery('#post-content').counter({
				type: 'word',
				count: 'down',
				goal: limit,
				append: false,
				target: '#limit-counter',
				msg: "<?php echo e(CustomHelper::lang('lang-words-remaining')); ?>"
			});	
			
			jQuery('.search > .search-box').keydown(function(event) {
				if (event.keyCode == 13) {
					this.form.submit();
					return false;
				}
			});
			
			jQuery('input.billing-option').on('click', function(){
				var amount = jQuery(this).attr('data-amount');
				
				jQuery('.card-information').show();
				if (parseInt(amount) === 0)
				{
					jQuery('.card-information').hide();
				}
			})
			
			jQuery('#toggle-editor').on('click', function(){
				if (jQuery('.editor-container').is(':visible'))
				{
					jQuery('.editor-container').hide();
					jQuery(this).find('span').html("<?php echo e(CustomHelper::lang('lang-new-article')); ?>");
				}else{
					jQuery(this).find('span').html("<?php echo e(CustomHelper::lang('lang-close-editor')); ?>");
					jQuery('.editor-container').show();
					
					initEditor();
				}
			});
			
			setTimeout(function(){
				var notice = jQuery('div.alert.alert-success');
				if (notice.is(':visible')) notice.fadeOut(1000, 'linear');
					
				var notice2 = jQuery('div.alert.alert-danger');
				if (notice2.is(':visible')) notice2.fadeOut(1000, 'linear');
			}, 5000);
			
			jQuery('.loadmore').on('click', function(){
				var tm = new Date().getTime();
				var url = jQuery(this).attr('data-src') + "?" + tm;
				var identifier = jQuery(this).attr('data-identifier');
				var parent = jQuery(this).closest('.post-comments-container-' + identifier);
				
				parent.find('.load-more-container-' + identifier + ' .load-more > .spinner').html('<i class="fa fa-refresh fa-spin"></i>');
				jQuery.ajax({
					type: "GET",
					url: url,
					dateType: 'json',
					success: function( data ) {
						parent.find('.load-more-container-' + identifier + ' .load-more > .spinner').html('');
						if (data.success)
						{
							parent.find('.comments-container-' + identifier).append(data.comments);
							initCommentBoxToggle();
							if (data.loadMore)
							{
								var src = "<?php echo e(url('/')); ?>/topics/loadmore/" + data.pid + "/" + data.pcid + "/" + data.lastId;
								parent.find('.load-more-container-' + identifier + ' .load-more > a').attr('data-src', src);
							}else{
								parent.find('.load-more-container-' + identifier).hide();
							}	
						}
					}
				});				
			})
			
			jQuery("a.scroll").click(function() {
				var slug = jQuery(this).data('slug');
				var topic = jQuery(this).data('topic');
				var id = jQuery(this).data('id');
				
				scroll(slug, topic, id);
			});
			
			/*jQuery('button.add-title').on('click', function(){
				var post_title = jQuery('#title_form input[name="post_title"]').val();
				if (post_title.length > 0)
				{
					jQuery('form[name="post_form"]').find('input[name="title"]').val(post_title);
					jQuery('form[name="post_form"]').get(0).submit();
				}else{
					showMessage('Please enter your post title before you proceed.');
				}
			});*/
			
			jQuery('button.add-category').on('click', function(){
				var category_id = jQuery('#category_form input[name="category_option"]:checked').val();
				if (typeof(category_id) !== 'undefined')
				{
					jQuery('form[name="post_form"]').find('input[name="category_id"]').val(category_id);
					jQuery('form[name="post_form"]').get(0).submit();
				}else{
					showMessage('Please select a sub-topic before you proceed.');
				}
			});
			
			jQuery('.videos-container').magnificPopup({
			  delegate: 'a',
			  type: 'iframe',
			  iframe: {
				  markup: '<div class="mfp-iframe-scaler">'+
							'<div class="mfp-close"></div>'+
							'<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
						  '</div>',
				  patterns: {
					youtube: {
					  index: 'youtube.com/',
					  id: 'v=',
					  src: '//www.youtube.com/embed/%id%?autoplay=1'
					},
					vimeo: {
					  index: 'vimeo.com/',
					  id: '/',
					  src: '//player.vimeo.com/video/%id%?autoplay=1'
					}
				  },
				  srcAction: 'iframe_src',
				},
				callbacks: {
				  beforeOpen: function() {
					var el = this.st.el.get(0);
					jQuery.ajax({ type: "GET", url: "<?php echo e(url('/videos/view')); ?>/" + $(el).attr('data-id') });
				  }
				}
			});
			
			jQuery('button.attach-photo').on('click', function(){
				var url = $('input[name="photo-selected"]').val();
				if (url.length > 0)
				{
					if (photosContainerParent !== null)
					{
						var photo = '<span><a href="'+url+'" title="Click to Preview"><i class="fa fa-file-picture-o"></i></a><input type="hidden" class="attachment_photos" name="photos[]" value="' + url + '" /></span>';
						photosContainerParent.find('.attachment-container span.photos-container').append(photo);
						photosContainerParent.find('div.hidden-container').show();
						$.magnificPopup.close();
						$('input[name="photo-selected"]').val('');
						$('#img-thumb-preview').hide();
						$('.dz-preview').hide();
						resetSelection();
						
						photosContainerParent = null;
					}
				}else{
					showMessage('Please upload or select a photo before you proceed.');
				}
			});
			
			jQuery('button.attach-video').on('click', function(){
				var title = $('input[name="video_title"]').val();
				var url = $('input[name="embed_url"]').val();
				if ((url.length > 0) && (title.length > 0))
				{
					if (validateVideoUrl(url))
					{
						if (videosContainerParent !== null)
						{
							if (videosContainer !== null && videosContainer === 'section')
							{
								videosContainerParent.find('input[name="embed_url"]').val(url);
								videosContainerParent.find('input[name="video_title"]').val(title);
								videosContainerParent.find('form#form-video').get(0).submit();
							}else{
								var video = '<span><a href="'+url+'" title="Click to Preview"><i class="fa fa-file-video-o"></i></a><input type="hidden" class="attachment_videos" name="videos[]" value="' + url + '" /></span>';
								videosContainerParent.find('.attachment-container span.videos-container').append(video);
								videosContainerParent.find('div.hidden-container').show();
							}
							
							$.magnificPopup.close();
							$('input[name="embed_url"]').val('');
							
							videosContainerParent = null;
						}
					}
				}else{
					showMessage('Please enter the url and title of the video you want to embed.');
				}
			});
			
			jQuery('.photos, .img-thumbnail').on('click', 'img', function(){
				var parent = jQuery(this).parent();
				var src = jQuery(this).attr('src');
				var filename = src.substring(src.lastIndexOf('/')+1);
				
				jQuery('img.photo-select').parent().removeClass('photo-selected');
				parent.addClass('photo-selected');
				
				jQuery('.selected-status').html("<?php echo e(CustomHelper::lang('lang-photo-selected')); ?>: "+filename);
				$('input[name="photo-selected"]').val(src);
			});
			
			if (jQuery('#photo-dropzone').is(':visible'))
			{
			  Dropzone.options.photoDropzone = {
				uploadMultiple: false,
				acceptedFiles: 'image/*',
				addRemoveLinks: false,
				dictDefaultMessage: '',
				init: function() {
				  this.on("addedfile", function(file) {
					resetSelection();
					$('#img-thumb-preview #img-thumb').hide();
					$('#img-thumb-preview').show();
					$('.processing-msg').show();
				  });
				  this.on("thumbnail", function(file, dataUrl) {
					$('.dz-image-preview').hide();
					$('.dz-file-preview').hide();
				  });
				  this.on("success", function(file, res) {
					$('.processing-msg').hide();  
					$('#img-thumb').attr('src', res.path);
					$('#img-thumb-preview #img-thumb').show();
					$('#img-thumb-preview').show();
					$('.dz-preview').show();
					updateGallery(res.path);
				  });
				}
			  };
			  var photoDropzone = new Dropzone("#photo-dropzone");
			 
			  $('#upload-submit').on('click', function(e) {
				e.preventDefault();
				$("#photo-dropzone").trigger('click');
			  });
			}  
			  
			if (jQuery('#gallery-dropzone').is(':visible'))
			{
			  Dropzone.options.galleryDropzone = {
				uploadMultiple: false,
				acceptedFiles: 'image/*',
				addRemoveLinks: false,
				dictDefaultMessage: '',
				init: function() {
				  this.on("addedfile", function(file) {
					$('#img-thumb-preview').show();
					$('.processing-msg').show();
				  });
				  this.on("thumbnail", function(file, dataUrl) {
					$('.dz-image-preview').hide();
					$('.dz-file-preview').hide();
				  });
				  this.on("success", function(file, res) {
					$('.processing-msg').hide();
					window.location.href=window.location.href;
				  });
				}
			  };
			  var galleryDropzone = new Dropzone("#gallery-dropzone");
			 
			  $('#gallery-upload-submit').on('click', function(e) {
				e.preventDefault();
				$("#gallery-dropzone").trigger('click');
			  });
			}
			
			if (jQuery('#works-dropzone').is(':visible'))
			{
			  Dropzone.options.worksDropzone = {
				uploadMultiple: false,
				acceptedFiles: 'image/*',
				addRemoveLinks: false,
				dictDefaultMessage: '',
				init: function() {
				  this.on("addedfile", function(file) {
					$('#img-thumb-preview').show();
					$('.processing-msg').show();
				  });
				  this.on("thumbnail", function(file, dataUrl) {
					$('.dz-image-preview').hide();
					$('.dz-file-preview').hide();
				  });
				  this.on("success", function(file, res) {
					$('.processing-msg').hide();
					window.location.href=window.location.href;
				  });
				}
			  };
			  var worksDropzone = new Dropzone("#works-dropzone");
			 
			  $('#works-upload-submit').on('click', function(e) {
				e.preventDefault();
				$("#works-dropzone").trigger('click');
			  });
			}
			
			initEditor();
			initCommentBoxToggle();
			loadChatMessages();
			
			if (jQuery('#profile-photo-dropzone').is(':visible')) loadProfileDropZone();
		});
		Dropzone.autoDiscover = false;
		
		function addFriend(btn)
		{
			var tm = new Date().getTime();
			var url = jQuery(btn).attr('data-url') + "?" + tm;
			var token = jQuery('input[name="search-csrf"]').val();
			var user_id = jQuery(btn).attr('data-id');
			var parent = jQuery(btn).parent();
			
			jQuery(btn).hide();
			parent.find('span.loader').html('<i class="fa fa-refresh fa-spin"></i> &nbsp;<i>processing, please wait...</i>');
			jQuery.ajax({
				type: "POST",
				url: url,
				data: { id: user_id, _token: token },
				dateType: 'json',
				success: function( data ) {
					parent.find('span.loader').html('');
					if (data.success)
					{
						parent.find('span.pending-request').show();
					}
				}
			});				
		}
		
		function loadProfileDropZone()
		{
			Dropzone.options.profilePhotoDropzone = {
				uploadMultiple: false,
				acceptedFiles: 'image/*',
				addRemoveLinks: false,
				dictDefaultMessage: '',
				init: function() {
				  this.on("addedfile", function(file) {
					$('#img-thumb-preview #img-thumb').hide();
					$('#img-thumb-preview').show();
					$('.processing-msg').show();
				  });
				  this.on("thumbnail", function(file, dataUrl) {
					$('.dz-image-preview').hide();
					$('.dz-file-preview').hide();
				  });
				  this.on("success", function(file, res) {
					location.href = location.href;
				  });
				}
			  };
			  var profilePhotoDropzone = new Dropzone("#profile-photo-dropzone");
			 
			  $('#profile-upload-submit').on('click', function(e) {
				e.preventDefault();
				$("#profile-photo-dropzone").trigger('click');
			  });
		}
		
		function validateVideoUrl(url)
		{
			var youtubeUrl = 'https://www.youtube.com/watch?v=';
			var vimeoUrl = 'https://vimeo.com/';
			
			if ((url.indexOf(youtubeUrl) !== -1) || (url.indexOf(vimeoUrl) !== -1))
			{
				return true;
			}else{
				showMessage('Please enter a valid youtube or vimeo video url. Please refer to the sample format:<br/><br/>' + youtubeUrl + '{VIDEO-ID}<br/>' + vimeoUrl + '{VIDEO-ID}<br/><br/>');
			}
			return false;
		}
		
		function initEditor()
		{
			if (! jQuery('.editor-container .easyeditor-toolbar').is(':visible'))
			{
				var easyEditor = new EasyEditor('.editor-container .editor', {
					buttons: ['bold', 'italic', 'underline', 'link', 'h2', 'h3', 'h4', 'alignleft', 'aligncenter', 'alignright', 'quote', 'source', 'x'],
					buttonsHtml: {
						'bold': '<i class="fa fa-bold"></i>',
						'italic': '<i class="fa fa-italic"></i>',
						'underline': '<i class="fa fa-underline"></i>',
						'link': '<i class="fa fa-link"></i>',
						'header-2': '<i class="fa fa-header"></i>2',
						'header-3': '<i class="fa fa-header"></i>3',
						'header-4': '<i class="fa fa-header"></i>4',
						'align-left': '<i class="fa fa-align-left"></i>',
						'align-center': '<i class="fa fa-align-center"></i>',
						'align-right': '<i class="fa fa-align-right"></i>',
						'quote': '<i class="fa fa-quote-left"></i>',
						'remove-formatting': '<i class="fa fa-ban"></i>',
						'source': '<i class="fa fa-code"></i>'
					},
					css: ({
						minHeight: '300px',
						width: '100%'
					}),
				});
				
				if (jQuery('.easyeditor-toolbar').is(':visible'))
				{
					jQuery('button#toggle-editor').find('span').html("<?php echo e(CustomHelper::lang('lang-close-editor')); ?>");
				}else{
					jQuery('button#toggle-editor').find('span').html("<?php echo e(CustomHelper::lang('lang-new-article')); ?>");
				}
			}
		}
		
		function initCommentBoxToggle()
		{
			jQuery('.photos-popup').magnificPopup({
				type: 'inline',
				callbacks: {
				  beforeOpen: function() {
					var el = this.st.el.get(0);
					photosContainerParent = $(el).closest('.row');
				  }
				}
			});
			
			jQuery('.videos-popup').magnificPopup({
				type: 'inline',
				callbacks: {
				  beforeOpen: function() {
					var el = this.st.el.get(0);
					var trigger = $(el).attr('data-trigger');
					
					if (typeof(trigger) !== 'undefined' && trigger === 'section')
					{
						videosContainer = trigger;
						videosContainerParent = $(el).closest('.row').siblings('.videos-container').eq(0);
					}else{
						videosContainerParent = $(el).closest('.row');
					}
				  }
				}
			});
			
			jQuery('.photo-gallery').each(function() {
				jQuery(this).magnificPopup({
					delegate: 'a',
					type: 'image',
					gallery: {
					  enabled:true
					}
				});
			});
			
			jQuery('.gallery-container .gallery, .works-container .works').each(function() {
				jQuery(this).magnificPopup({
					delegate: 'a',
					type: 'image',
					gallery: {
					  enabled:true
					}
				});
			});
			
			jQuery('.photos-container').magnificPopup({
			  delegate: 'a',
			  type: 'image',
			  image: {
				  markup: '<div class="mfp-figure">'+
							'<div class="mfp-close"></div>'+
							'<div class="mfp-img"></div>'+
							'<div class="mfp-bottom-bar">'+
							  '<div class="mfp-title"></div>'+
							  '<div class="mfp-counter"></div>'+
							'</div>'+
						  '</div>',
				  cursor: 'mfp-auto-cursor',
				  titleSrc: 'title',
				  verticalFit: true,
				  tError: '<a href="%url%">The image</a> could not be loaded.'
				}
			});
			
			jQuery('.toggle-comment-box').unbind('click');
			jQuery('.toggle-comment-box').on('click', function(){
				jQuery('.reply-container').not(jQuery(this).parent().find('.reply-container')).hide();
				jQuery(this).parent().find('.reply-container').toggle();
				
				//initialize limit control
				if (jQuery(this).parent().find('.limit-counter').html().length == 0)
				{
					jQuery(this).parent().find('textarea[name="comment"]').counter({
						type: 'word',
						count: 'down',
						goal: limit,
						append: false,
						target: jQuery(this).parent().find('.limit-counter'),
						msg: "<?php echo e(CustomHelper::lang('lang-words-remaining')); ?>"
					});
				}
			});	
		}
		function showMessage(msg)
		{
			BootstrapDialog.show({
                type: BootstrapDialog.TYPE_PRIMARY,
                title: "CG Networks Alerts",
                message: msg,
                buttons: [{
					label: 'Close',
					action: function(dialogItself){
						dialogItself.close();
					}
				}]
            });  
		}
		function confirmDeletePhoto(id)
		{
			BootstrapDialog.confirm({
                type: BootstrapDialog.TYPE_WARNING,
                title: "CG Networks Alerts",
                message: "Are you sure you want to permanently delete the image?",
                btnCancelLabel: 'Cancel',
				btnOKLabel: 'Delete',
				callback: function(result) {
					if (result) {
						window.location.href = "<?php echo e(url('/photos/remove')); ?>/"+id;
					}
				}
            });  
		}
		function confirmDeleteVideo(id)
		{
			BootstrapDialog.confirm({
                type: BootstrapDialog.TYPE_WARNING,
                title: "CG Networks Alerts",
                message: "Are you sure you want to remove the video from your collection?",
                btnCancelLabel: 'Cancel',
				btnOKLabel: 'Remove',
				callback: function(result) {
					if (result) {
						window.location.href = "<?php echo e(url('/videos/remove')); ?>/"+id;
					}
				}
            });  
		}
		function confirmDeleteArtwork(id)
		{
			BootstrapDialog.confirm({
                type: BootstrapDialog.TYPE_WARNING,
                title: "CG Networks Alerts",
                message: "Are you sure you want to remove your art work?",
                btnCancelLabel: 'Cancel',
				btnOKLabel: 'Remove',
				callback: function(result) {
					if (result) {
						window.location.href = "<?php echo e(url('/works/remove')); ?>/"+id;
					}
				}
            });  
		}
		function updateGallery(url)
		{
			jQuery('.no-photos').hide();
			jQuery('.tab-content .photos').append('<div class="photo bg-primary"><img src="' + url + '" class="img-responsive photo-select" border="0" /></div>');
		}
		function resetSelection()
		{
			jQuery('img.photo-select').parent().removeClass('photo-selected');
			jQuery('.selected-status').html("<?php echo e(CustomHelper::lang('lang-no-photo-selected')); ?>");
			jQuery('input[name="photo-selected"]').val('');
		}			
		function checkComment(form)
		{
			var comment = jQuery(form).find('textarea[name="comment"]');
			if (comment.val().length > 0) return true;
			
			showMessage('Ooops! it appears that you\'ve forgotten to enter your message. Please enter your message and try again.');
			return false;
		}
		function submitVote(anchor)
		{
			var form = jQuery(anchor).parent('form');
			form.get(0).submit();
		}
		function sharePostComment(anchor)
		{
			var post_id = jQuery(anchor).parent().find('input[name="post_id"]');
			var comment_id = jQuery(anchor).parent().find('input[name="comment_id"]');
			var type = jQuery(anchor).parent().find('input[name="type"]');
			var url = '<?php echo e(Request::fullUrl()); ?>#p' + post_id.val();
			
			jQuery('#share_comment_form').find('input[name="post_id"]').val(post_id.val());
			if (typeof(comment_id) !== 'undefined') {
				url += 'c' + comment_id.val();
				jQuery('#share_comment_form').find('input[name="comment_id"]').val(comment_id.val());
			}
			jQuery('#share_comment_form').find('input[name="type"]').val(type.val());
			jQuery('#share_comment_form').find('input[name="link"]').val(url);
			
			jQuery.magnificPopup.open({
			  items: {
				src: '#share_comment_form'
			  },
			  type: 'inline'
			});
		}
		function checkEmails(form)
		{
			var emails = jQuery(form).find('input[name="email_addresses"]').val();
			if (emails.length > 0)
			{
				return true;
			}else{
				showMessage('Please enter the email address(es) where you want to share this post or comment.');
			}
			
			return false;
		}
		function sendMessage(anchor)
		{
			var source_id = jQuery(anchor).parent().find('input[name="source_id"]').val();
			var target_id = jQuery(anchor).parent().find('input[name="target_id"]').val();
			
			jQuery('#send_message_form').find('input[name="source_id"]').val(source_id);
			jQuery('#send_message_form').find('input[name="target_id"]').val(target_id);
			
			jQuery.magnificPopup.open({
			  items: {
				src: '#send_message_form'
			  },
			  type: 'inline'
			});
		}
		function activateRequest(id, type)
		{
			jQuery('#activation_form').find('input[name="type"]').val(type);
			jQuery('#activation_form').find('input[name="user_id"]').val(id);
			
			jQuery.magnificPopup.open({
			  items: {
				src: '#activation_form'
			  },
			  type: 'inline'
			});
		}
		function checkMessage(form)
		{
			var message = jQuery(form).find('textarea[name="message"]').val();
			if (message.length > 0)
			{
				return true;
			}else{
				showMessage('Please enter your message before you proceed.');
			}
			
			return false;
		}
		function validateSubmit(form)
		{
			if (checkComment(form))
			{
				var category = jQuery(form).find('input[name="category_id"]').val();
				if (category.length <= 0)
				{
					jQuery.magnificPopup.open({
					  items: {
						src: '#category_form'
					  },
					  type: 'inline'
					});
					return false;
				}
				return true;
			}
			return false;
		}
		function scroll(slug, topic, id){
			var aTag = $("a[name='"+ slug +"']");
			$('html,body').animate({
				scrollTop: aTag.offset().top
			},'slow');
			
			//jQuery('form[name="post_form"]').find('input[name="category_id"]').val('');
			////jQuery('.submit-form-container').hide();
			jQuery('.current-topic').html('');
			if (slug == 'submit-form') {
				//jQuery('form[name="post_form"]').find('input[name="category_id"]').val(id);
				//jQuery('.current-topic').html('&nbsp;Your current post will be submitted to the "'+topic+'" topic.');
				////jQuery('.submit-form-container').show();
				jQuery('#post-content').focus();
			}
		}
		function sendChatMessage(btn)
		{
			var tm = new Date().getTime();
			var container = jQuery(btn).closest('.chat-action-container');
			var url = "<?php echo e(url('/')); ?>/channel/message" + "?" + tm;
			var message = container.find('input[name="message"]').val();
			var category_id = container.find('input[name="category_id"]').val();
			var token = container.find('input[name="chat-csrf"]').val();
			
			var data = {
				category_id: category_id,
				message: message,
				_token: token
			};
			
			container.find('input[name="message"]').val('');
			jQuery('div.sending-container').find('span.sending').html('<i class="fa fa-refresh fa-spin"></i> &nbsp;<i>Sending message, please wait...</i>');
			jQuery.ajax({
				type: "POST",
				url: url,
				data: data,
				dateType: 'json',
				success: function( data ) {
					jQuery('div.sending-container').find('span.sending').html(data.message);
					setTimeout(function(){
						jQuery('div.sending-container').find('span.sending').html('');
					}, 1000);
				}
			});				
		}
		function loadChatMessages()
		{
			var container = jQuery('div.channel-message-container');
			if (container.is(":visible"))
			{	
				jQuery('input.channel-message').on('keypress', function(e){
					if (e.keyCode == 13) {
						e.preventDefault();
						jQuery('button.channel-btn').trigger('click');
					}
				});
				
				var limit = 0;
				var user_id = 0;
				var category_id = 0;
				
				<?php if(! Auth::guest()): ?>
					limit = <?php echo e(Auth::user()->post_word_limit); ?>;
					user_id = "<?php echo e(Auth::user()->id); ?>";
					<?php if(isset($channel)): ?>
						category_id = "<?php echo e($channel->id); ?>";
					<?php endif; ?>
				<?php endif; ?>

				var interval = setInterval(function(){
					
					var tm = new Date().getTime();
					url = "<?php echo e(url('/')); ?>/channel/message/load" + "?" + tm;
					items = container.find('ul.messages li');
					
					last_id = 0;
					if (items.length) last_id = items.last().data('id');
					
					var data = {
						category_id: category_id,
						last_id: last_id
					};

					jQuery.ajax({
						type: "GET",
						url: url,
						data: data,
						dateType: 'json',
						success: function( data ) {
							if (data.messages.length)
							{
								for(var i=0; i<data.messages.length; i++)
								{
									var chat = data.messages[i];
									var owner = '';
									var label = '';
									if (parseInt(user_id) == parseInt(chat.user_id)) {
										owner = 'owner';
										label = ' (you)';
									}
									container.find('ul.messages').append('<li data-id="' + chat.id + '"><span class="message-sender ' + owner + '">' + chat.name + label + ':</span> ' + chat.message + '</li>');
								}
								
								var d = $('.channel-message-container');
								d.scrollTop(d.prop("scrollHeight"));
							}
						}
					});	
					
				},3000);			
			}
		}
		
	</script>
</footer>
