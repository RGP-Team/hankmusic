<?php $settings = \App\Models\Setting::find(1); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo e($settings->website_title); ?></title>
        
		<!-- Bootstrap CSS -->
        <?php echo e(Html::style('bootstrap/css/bootstrap.min.css')); ?>

		
		<!-- FontAwesome CSS -->
        <?php echo e(Html::style('font-awesome/css/font-awesome.min.css')); ?>

		
		<!-- Custom CSS -->
		<?php echo e(Html::style('css/magnific-popup.css')); ?>

		<?php echo e(Html::style('css/bootstrap-dialog.min.css')); ?>

		<?php echo e(Html::style('css/easyeditor.css')); ?>

		
		
		<?php echo e(Html::style('css/style.css')); ?>

		<?php echo e(Html::style('css/nav.css')); ?>

		
		<!--<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,400italic&ver=4.3" media="all" rel="stylesheet" type="text/css">-->
		<!--<link rel="stylesheet" id="googlefont-css" href="//fonts.googleapis.com/css?family=Lato%3A300%2C400%2C700%2C400italic&amp;ver=4.3" type="text/css" media="all">-->
        <!--<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
        <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>-->
		
		
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <?php echo e(Html::script('js/html5shiv.js')); ?>

		<?php echo e(Html::script('js/respond.min.js')); ?>

        <![endif]-->

    </head>
    <body id="page-top" class="index <?php echo e($settings->default_language); ?>">
    
		<div id="page-layout">
			<div id="page-head">
				<?php echo $__env->make('layouts.partials._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
				<?php echo $__env->make('layouts.partials._navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div id="page-content">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
			<div id="page-foot">
				<?php echo $__env->make('layouts.partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
		</div>
		
    </body>
</html>