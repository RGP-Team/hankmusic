<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-9">
						<?php if(session()->has('success_message')): ?>
							<div class="alert alert-success save-message">
								<?php echo e(session()->get('success_message')); ?>

							</div>
						<?php endif; ?>
						<?php if($errors->has('content') || session()->has('error_message')): ?>
							<div class="alert alert-danger save-message">
								<?php if(session()->has('error_message')): ?>
									<?php echo e(session()->get('error_message')); ?>

								<?php else: ?>
									<?php echo e($errors->first('content')); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-md-12">
								<a name="submit-form"></a>
								<?php if( $data->subtopic ): ?>
									<h3 class="breadcrum"><a href="<?php echo e(url('/')); ?>/topics/<?php echo e($data->topic->slug); ?>"><?php echo e(CustomHelper::lang($data->topic->id, true)); ?></a> &nbsp;<i class="fa fa-angle-double-right"></i> <?php echo e(CustomHelper::lang($data->subtopic->id, true)); ?> <small class="current-topic"></small></h3>
								<?php else: ?>
									<h3 class="breadcrum"><?php echo e(CustomHelper::lang($data->topic->id, true)); ?> <small class="current-topic"></small></h3>
								<?php endif; ?>
							</div>
						</div>
						<?php if( ! Auth::guest()): ?>
						<div class="submit-form-container">
							<form class="form-horizontal" name="post_form" role="form" method="POST" action="<?php echo e(url('/posts')); ?>" onsubmit="return validateSubmit(this);">
							<?php echo csrf_field(); ?>	
							<input type="hidden" name="category_id" value="<?php echo e($data->subtopic->id); ?>" />
							<div class="row">
								<div class="col-md-6">
									<h3 class="submit-a-post"><?php echo e(CustomHelper::lang('lang-submit-a-post')); ?></h3>
								</div>
								<div class="col-md-6 text-right">
									<div class="channel-link">
										<a href="<?php echo e(url('/')); ?>/<?php echo e($data->topic->slug); ?>/channel"><?php echo e(CustomHelper::lang('lang-goto-chat')); ?></a>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-12 form-field <?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
											<textarea id="post-content" class="img-responsive form-control" name="comment" placeholder="<?php echo e(CustomHelper::lang('lang-post-content')); ?>..."></textarea>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5">
											<span id="limit-counter"></span>
											<div class="row hidden-container attachment-container">
												<div class="col-md-12 photos-videos-container">
													<span class="photos-container"></span>&nbsp;
													<span class="videos-container"></span>
												</div>
											</div>
										</div>
										<div class="col-md-7 text-right">
											<a href="#upload_image_form" class="btn photos-popup"><?php echo e(CustomHelper::lang('lang-upload-image')); ?></a>
											<button class="btn"><?php echo e(CustomHelper::lang('lang-submit')); ?></button>
										</div>
									</div>
								</div>
							</div>
							
							
							</form>
						</div>
						<?php endif; ?>

						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><i class="fa fa-comments-o"></i> <?php echo e(CustomHelper::totalComments($data->subtopic->id)); ?> <?php echo e(CustomHelper::lang('lang-comments')); ?></h4>
								</div>
							</div>
						</div>
						
							
							<div class="row">
								<div class="col-md-12 text-center top-margin-20">
									<a name=""></a>
									<h4 class="heading"></h4>
								</div>
							</div>
							
							<?php ($counter = 0); ?>
							<?php if($data->subtopic->posts->count()): ?>
							
								<?php foreach($data->subtopic->posts as $post): ?>
								
								<?php if($counter > 0): ?>
								<div class="row">
									<div class="col-md-12 bottom-margin-20">
										<div class="bottom-line">&nbsp;</div>
									</div>
								</div>
								<?php endif; ?>
								
								<?php ($counter++); ?>
								
								<div class="row bottom-margin-5">
									<div class="col-md-1 text-center">
										<div class="user-profile hidden-sm hidden-xs">
											<?php if($post->user->photo): ?>
												<?php ($profile_photo = $post->user->photo->url); ?>
												<img src="<?php echo e($profile_photo); ?>" alt="">
											<?php else: ?>
												<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
											<?php endif; ?>
										</div>
									</div>
									<div class="col-md-11">
										<a name="<?php echo e('p'.$post->id); ?>"></a>
										<div class="topic-title add-spacer"><a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($post->user->id); ?>"><?php echo e($post->user->first_name . ' ' . $post->user->last_name); ?></a><span class="topic-hour"><?php echo e(CustomHelper::lang('lang-posted')); ?> <?php echo e(CustomHelper::show_elapsed_time($post->created_dt)); ?></span></div>
										<p class="text-left">
										<?php echo nl2br(e($post->content)); ?>

										</p>
										<?php if($post->photos->count()): ?>
											<div class="photo-gallery">
												<?php foreach( $post->photos as $photo ): ?>
													<a href="<?php echo e($photo->photo->url); ?>"><img class="gallery-item" src="<?php echo e($photo->photo->url); ?>" border="0" /></a>
												<?php endforeach; ?>
											</div>
										<?php endif; ?>
										<?php if( ! Auth::guest() && ((int)$post->user->id !== (int)Auth::user()->id)): ?>
										<div class="bottom-margin-30">
											<form class="form-inline" role="form" method="POST" action="<?php echo e(url('/posts/votedown')); ?>">
											<?php echo csrf_field(); ?>	
											<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
											<input type="hidden" name="type" value="post" />
											<a href="javascript://" onclick="submitVote(this);" title="Vote Down" class="action-buttons"><i class="fa fa-chevron-down"></i> <?php echo e($post->down_votes); ?></a>
											</form>
											<form class="form-inline" role="form" method="POST" action="<?php echo e(url('/posts/voteup')); ?>">
											<?php echo csrf_field(); ?>

											<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
											<input type="hidden" name="type" value="post" />
											<a href="javascript://" onclick="submitVote(this);" title="Vote Up" class="action-buttons"><i class="fa fa-chevron-up"></i> <?php echo e($post->up_votes); ?></a>
											</form>
											<a href="javascript://" class="action-buttons toggle-comment-box" title="Add Comment"><i class="fa fa-mail-reply"></i> <?php echo e(CustomHelper::lang('lang-reply')); ?></a>
											<span>
												<input type="hidden" name="source_id" value="<?php echo e(Auth::user()->id); ?>" />
												<input type="hidden" name="target_id" value="<?php echo e($post->user->id); ?>" />
												<a href="javascript://" onclick="sendMessage(this)" class="action-buttons" title="Send Message"><i class="fa fa-envelope-o"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-send-a-message')); ?></a>
											</span>
											<a href="javascript://" onclick="sharePostComment(this);" class="action-buttons share"><?php echo e(CustomHelper::lang('lang-share')); ?></a>
											<div class="reply-container" style="display:none;">
												<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/posts/comment')); ?>" onsubmit="return checkComment(this);">
												<?php echo csrf_field(); ?>	
												<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
												<div class="row">
													<div class="col-md-12">
														<div class="row">
															<div class="col-md-12">
																<textarea class="img-responsive form-control comment" name="comment" placeholder="<?php echo e(CustomHelper::lang('lang-your-comment-here')); ?>"></textarea>
															</div>
														</div>
														<div class="row">
															<div class="col-md-3">
																<span class="limit-counter"></span>
																<div class="row hidden-container attachment-container">
																	<div class="col-md-12 photos-videos-container">
																		<span class="photos-container"></span>&nbsp;
																		<span class="videos-container"></span>
																	</div>
																</div>
															</div>
															<div class="col-md-9 text-right">
																<a href="#upload_image_form" class="btn photos-popup"><?php echo e(CustomHelper::lang('lang-upload-image')); ?></a>
																<button class="btn"><?php echo e(CustomHelper::lang('lang-submit')); ?></button>
															</div>
														</div>
													</div>
												</div>
												</form>
											</div>
										</div>
										<?php else: ?>
										<p class="text-right votes">
											<i class="fa fa-thumbs-down font-red"></i> <?php echo e($post->down_votes); ?>, &nbsp;<i class="fa fa-thumbs-up font-green"></i> <?php echo e($post->up_votes); ?>

										</p>
										<?php endif; ?>
									</div>
								</div>
								
								<?php echo $__env->make('pages.comments', ['comments' => $post->comments, 
															'paginated_comments' => $post->paginated_comments, 
															'post_id' => $post->id,
															'comment_id' => 0,
															'indent' => true,
															'identifier' => 'pid'.$post->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									
								
								<?php endforeach; ?>
							
								
							<?php else: ?>
										
								<!-- No post found under this subtopic -->
								<div class="row">
									<div class="col-md-12 text-center be-the-first">
										<?php if( Auth::guest() ): ?>
											<small><a href="<?php echo e(url('/login')); ?>"><?php echo e(CustomHelper::lang('lang-sign-in')); ?></a> <?php echo e(CustomHelper::lang('lang-and-be-the-first')); ?></small>
										<?php else: ?>
											<small><?php echo e(CustomHelper::lang('lang-be-the-first')); ?> <a class="scroll" href="javascript://" data-slug="submit-form" data-id="<?php echo e($data->topic->id); ?>" data-topic="<?php echo e(ucfirst($data->topic->name)); ?>"><?php echo e(CustomHelper::lang('lang-click-here')); ?></a></small>.
										<?php endif; ?>
									</div>
								</div>
								
							<?php endif; ?>
						
						

						
						<div class="row">
							<div class="col-md-12">&nbsp;</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="container-subtopics">
							<h4><?php echo e(CustomHelper::lang('lang-sub-topics')); ?></h4>
							<ul>
								<?php ($subtopics = $data->topic->children); ?>
								<?php foreach( $subtopics as $subtopic ): ?>
									<li><a class="subtopic" data-id="<?php echo e($subtopic->id); ?>" href="<?php echo e(url('/')); ?>/topics/<?php echo e($data->topic->slug); ?>/<?php echo e($subtopic->slug); ?>"><?php echo e(CustomHelper::lang($subtopic->id, true)); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>