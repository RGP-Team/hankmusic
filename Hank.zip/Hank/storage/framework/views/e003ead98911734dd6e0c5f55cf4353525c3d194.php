<div class="container-fluid">  
	<div class="row">
		<div class="col-lg-12">
		
			<div class="admin-login-form text-center">
				<p class="logo">
					<img src="<?php echo e(URL::asset('images/logo-200.png')); ?>" alt="CG Networks Logo" border="0" />
				</p>
				
				<?php if(Auth::guard('admins')->check()): ?>
				   <?php /*<p>
						Name: <?php echo e(Auth::guard('admins')->user()->name); ?><br/>
						Email: <?php echo e(Auth::guard('admins')->user()->email); ?>

					</p>*/ ?>
					
					<div class="already-logged-in-block text-success bg-success">
						You are already logged in. Go to your <a class="" href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a>.
					</div>
				<?php else: ?>

					<?php if( $errors->any() ): ?>
						<?php if($errors->has('message')): ?>
							<div class="error-message-block text-danger bg-danger">
								<?php echo e($errors->first('message')); ?>

							</div>
						<?php endif; ?>
					<?php endif; ?>

					<form class="form-horizontal text-left" role="form" method="POST">
						<?php echo csrf_field(); ?>

						<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
							<div class="row">
								<div class="col-md-12">
									<label class="control-label">Email Address</label>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

									<?php if($errors->has('email')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('email')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
							<div class="row">
								<div class="col-md-12">
									<label class="control-label">Password</label>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<input type="password" class="form-control" name="password">

									<?php if($errors->has('password')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('password')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-md-12">
									<input type="checkbox" name="remember"> Remember Me
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-md-4">
									<button type="submit" class="btn btn-primary">
										Log In
									</button>
								</div>
								<div class="col-md-8 text-right">
									<!--<a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>-->
								</div>
							</div>
						</div>
					</form>
					
				<?php endif; ?>
		
			</div>
		
		</div>
	</div>
</div> 
