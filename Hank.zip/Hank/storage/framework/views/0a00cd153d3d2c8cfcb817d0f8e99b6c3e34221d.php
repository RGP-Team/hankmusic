<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12">
						
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-account-information')); ?></h4>	
								</div>
								<?php if(session()->has('success_message')): ?>
									<div class="alert alert-success">
										<?php echo e(session()->get('success_message')); ?>

									</div>
								<?php endif; ?>
								<?php if(count($errors->all())): ?>
									<div class="alert alert-danger">
										<ul>
										<?php foreach($errors->all() as $error): ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; ?>
										</ul>
									</div>
								<?php else: ?>
									<?php if(session()->has('error_message')): ?>
									<div class="alert alert-danger">
										<?php echo e(session()->get('error_message')); ?>

									</div>
									<?php endif; ?>
								<?php endif; ?>		
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 top-margin-30"></div>
						</div>
						<div class="row">
							<div class="col-md-1"></div>
							<div class="col-md-5 profile-area">
								
								<!-- profile -->		
								<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/profile/edit/save')); ?>">
									<?php echo csrf_field(); ?>


									<input type="hidden" name="user_id" value="<?php echo e($data->user->id); ?>" >
									<div class="form-group">
										<legend><?php echo e(CustomHelper::lang('lang-personal')); ?></legend>
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-firstname')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="first_name" value="<?php echo e($data->user->first_name); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-lastname')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="last_name" value="<?php echo e($data->user->last_name); ?>">
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-email-address')); ?></label>

										<div class="col-md-7">
											<input type="email" class="form-control" name="email" value="<?php echo e($data->user->email); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<legend><?php echo e(CustomHelper::lang('lang-bio-description')); ?></legend>
										<small class="profile-notes"><?php echo e(CustomHelper::lang('lang-tell-something')); ?></small>
										<div class="col-md-12">
											<textarea type="text" class="form-control" name="description"><?php echo e($data->user->description); ?></textarea>
										</div>
									</div>
									
									<div class="form-group">
										<legend><?php echo e(CustomHelper::lang('lang-location')); ?></legend>
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-address')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="address" value="<?php echo e($data->user->address); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-city')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="city" value="<?php echo e($data->user->city); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-state')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="state" value="<?php echo e($data->user->state); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-zip')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="zip" value="<?php echo e($data->user->zip); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-country')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="country" value="<?php echo e($data->user->country); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<legend><?php echo e(CustomHelper::lang('lang-keyword-tags')); ?></legend>
										<small class="profile-notes"><?php echo e(CustomHelper::lang('lang-comma-separated-search')); ?></small>
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-tags')); ?></label>

										<div class="col-md-7">
											<input type="text" class="form-control" name="tags" value="<?php echo e($data->user->tags); ?>">
										</div>
									</div>

									<div class="form-group">
										<legend><?php echo e(CustomHelper::lang('lang-security')); ?></legend>
										<small class="profile-notes"><?php echo e(CustomHelper::lang('lang-leave-blank')); ?></small>
										<label class="col-md-5 control-label"><?php echo e(CustomHelper::lang('lang-password')); ?></label>

										<div class="col-md-7">
											<input type="password" class="form-control" name="password">
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-5 control-label text-left"><?php echo e(CustomHelper::lang('lang-confirm-password')); ?></label>

										<div class="col-md-7">
											<input type="password" class="form-control" name="password_confirmation">
										</div>
									</div>

									<div class="form-group">
										<div class="col-md-7 col-md-offset-5">
											<button type="submit" class="btn btn-primary">
												<i class="fa fa-btn fa-user"></i> &nbsp;<?php echo e(CustomHelper::lang('lang-save-profile')); ?>

											</button>
										</div>
									</div>
								</form>	
								<!-- profile -->
							
							</div>
							<div class="col-md-1"></div>
							<div class="col-md-4 profile-area">
								<div class="row">
									<div class="col-md-12 top-margin-20 text-center">		
										<?php if($data->user->photo): ?>
											<?php ($profile_photo = $data->user->photo->url); ?>
											<img src="<?php echo e($profile_photo); ?>" alt="">
										<?php else: ?>
											<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
										<?php endif; ?>
										
										<br/>
										<?php echo Form::open(array('route' => 'profile.photo.upload', 'method' => 'POST', 'id' => 'profile-photo-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

											<button id="profile-upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> <?php echo e(CustomHelper::lang('lang-upload-photo')); ?></button>
											<div id="img-thumb-preview" class="noshow">
											  <span class="processing-msg" style="display:none;">Processing, please wait...</span>
											  <div class="img-thumbnail">
												<img id="img-thumb" class="user size-lg img-responsive photo-select" src="">
											  </div>
											</div>
										<?php echo Form::close(); ?>

									</div>
								</div>
								<div class="row">
									<div class="col-md-12 top-margin-50">
										<legend><?php echo e(CustomHelper::lang('lang-membership')); ?></legend>
										<div class="memberships col-md-12">
											<?php echo e(CustomHelper::lang('lang-your-current-membership')); ?> <strong>"<?php echo e($data->plan->title); ?>"</strong></strong>.
											<br/><br/>
											<?php if($data->payment->count()): ?>
											<?php ($next_billing = date("Y-m-d", strtotime("+1 month", strtotime($data->payment->create_dt)))); ?>
											<h5><?php echo e(CustomHelper::lang('lang-subscription-information')); ?></h5>
											<ul class="subscription-info">
												<li><label><?php echo e(CustomHelper::lang('lang-subscription-id')); ?></label>: <?php echo e($data->payment->subscription_id); ?></li>
												<li><label><?php echo e(CustomHelper::lang('lang-monthly-recurring-amount')); ?></label>: $<?php echo e(number_format($data->payment->amount,2)); ?></li>
												<li><label><?php echo e(CustomHelper::lang('lang-date-started')); ?></label>: <?php echo e(date("Y-m-d", strtotime($data->payment->create_dt))); ?></li>
												<li><label><?php echo e(CustomHelper::lang('lang-next-billing')); ?></label>: <?php echo e($next_billing); ?></li>
											</ul><br/>
											<?php echo nl2br(e(CustomHelper::lang('lang-sufficient-funds'))); ?>

											<br/><br/>
											<?php endif; ?>
										</div>
										
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<button class="btn btn-primary" onclick="location.href='<?php echo e(url('/membership/update')); ?>'"><?php echo e(CustomHelper::lang('lang-upgrade-downgrade')); ?></button>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12 top-margin-50">
										<legend><?php echo e(CustomHelper::lang('lang-builtin-privileges')); ?></legend>
										<div class="memberships col-md-12">
											<?php echo e(CustomHelper::lang('lang-as-part-of-your-account')); ?>

											<br/><br/>
											<ul class="built-in-privileges">
											<li><label>Freelancer</label> <?php if($data->user->freelancer): ?><span class="privilege-activated">activated</span><?php else: ?><a href="javascript://" class="click-to-activate" onclick="activateRequest(<?php echo e(Auth::user()->id); ?>, 'freelancer')">(click to activate)</a><?php endif; ?></li>
											<li><label>Writer</label> <?php if($data->user->writer): ?><span class="privilege-activated">activated</span><?php else: ?><a href="javascript://" class="click-to-activate" onclick="activateRequest(<?php echo e(Auth::user()->id); ?>, 'writer')">(click to activate)</a><?php endif; ?></li>
											</ul>
											<br/>
											<?php echo e(CustomHelper::lang('lang-when-activated')); ?>

											<br/><br/>
										</div>
										
									</div>
								</div>
							</div>
							<div class="col-md-1"></div>
						</div>
						
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>						
						