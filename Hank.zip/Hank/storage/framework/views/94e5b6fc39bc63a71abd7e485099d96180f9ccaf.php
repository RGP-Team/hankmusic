<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 dashboard-section">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-your-videos')); ?></h4>
								</div>
							</div>
						</div>
						<?php if(session()->has('success_message')): ?>
							<div class="alert alert-success save-message">
								<?php echo e(session()->get('success_message')); ?>

							</div>
						<?php endif; ?>
						<?php if($errors->has('content') || session()->has('error_message')): ?>
							<div class="alert alert-danger save-message">
								<?php if(session()->has('error_message')): ?>
									<?php echo e(session()->get('error_message')); ?>

								<?php else: ?>
									<?php echo e($errors->first('content')); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-md-12 top-margin-20">
								<?php ($info = CustomHelper::checkPageLimit()); ?>
								<?php if((int)$info['remaining_slot'] !== 0): ?>
								<a href="#embed_video_form" data-trigger="section" class="btn btn-default videos-popup"><i class="fa fa-youtube-play"></i> <?php echo e(CustomHelper::lang('lang-embed-video')); ?></a>
								<?php endif; ?>
							</div>
						</div>
						<div class="row videos-container">
							<div class="col-md-12">
								<?php echo Form::open(array('route' => 'videos.upload', 'method' => 'POST', 'id' => 'form-video')); ?>

									<input type="hidden" name="embed_url" value=""> 
									<input type="hidden" name="video_title" value="">
								<?php echo Form::close(); ?>

								<div class="row videos min-height-200">
								<?php if($videos->count()): ?>
									<?php foreach($videos as $video): ?>
									<div class="col-md-3 text-center">
										<div class="video-item bg-primary">
											<a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>"><img class="img-responsive" src="<?php echo e(URL::asset('images/play-video.png')); ?>" border="0" /></a>
										</div>
										<div class="clear"></div>
										<?php ($video_title = $video->title); ?>
										<?php if(strlen($video->title) > 30): ?>
											<?php ($video_title = substr($video->title, 0, 26) . '...'); ?>
										<?php endif; ?>
										<div class="video-title"><a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>"><?php echo e($video_title); ?></a></div>
										<span class="topic-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($video->created_dt))); ?></span>
										<i class="fa fa-trash-o delete-photo" onclick="confirmDeleteVideo(<?php echo e($video->id); ?>)" title="Delete Video"></i>
									</div>
									<?php endforeach; ?>
								<?php else: ?>
									<div class="col-md-12 text-center top-margin-30">
										<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

									</div>
								<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?php echo e($videos->links()); ?>

							</div>
						</div>
						
						
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>