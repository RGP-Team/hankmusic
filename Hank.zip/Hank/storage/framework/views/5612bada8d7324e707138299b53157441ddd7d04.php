<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-40">
								<div class="col-md-12"><h3><?php echo e($data->heading); ?></h3></div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-6">
											Category Info of <?php echo e($data->info->name); ?>

										</div>
										<div class="col-md-6">
											Sub Topics
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>