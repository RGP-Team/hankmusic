<div class="container-fluid">  
	<div class="row">
		<div class="col-md-9">
			<h2>Post add new form here...</h2>
			<script src="//tinymce.cachefly.net/4.3/tinymce.min.js"></script>
			<script type="text/javascript">
			tinymce.init({
				selector: "textarea",
				plugins: [
					"advlist autolink lists link image charmap print preview anchor",
					"searchreplace visualblocks code fullscreen",
					"insertdatetime media table contextmenu paste"
				],
				toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
			});
			</script>

			<form method="post" action="somepage">
				<textarea name="content" style="width:100%"></textarea>
			</form>
		</div>
		<div class="col-md-3">
			Publish Options
		</div>
	</div>
</div> 