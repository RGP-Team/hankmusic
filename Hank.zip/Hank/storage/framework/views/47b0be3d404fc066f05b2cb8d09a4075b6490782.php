This is the dashboard. 

<p>
<?php if(Auth::guard('admins')->check()): ?>

	Name: <?php echo e(Auth::guard('admins')->user()->name); ?><br/>
	Email: <?php echo e(Auth::guard('admins')->user()->email); ?>


<?php endif; ?>
</p>