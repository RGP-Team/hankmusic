<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 dashboard-section">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12 article-preview">
						<div class="row">
							<div class="col-md-12 bottom-margin-30">
								<div class="article-title">
									<h2><?php echo e($article->title); ?></h2>
									<span class="posted-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted')); ?> <?php echo e(CustomHelper::show_elapsed_time($article->created_dt)); ?>, &nbsp;<i><?php echo e(CustomHelper::lang('lang-by')); ?> <?php echo e($article->user->first_name); ?> <?php echo e($article->user->last_name); ?></i></span>
									<?php echo $__env->make('pages.partials._social_media_buttons', ['article' => $article], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 min-height-300">
								<div class="article-body">
									<?php echo $article->content; ?>

								</div>
							</div>
						</div>
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>						
						