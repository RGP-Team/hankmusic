<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 topics">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12">
						
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4>Membership Update</h4>		
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 top-margin-30"></div>
						</div>
						<div class="row">
							<div class="col-md-1"></div>
							<div class="col-md-10 bottom-margin-80">
								<?php if($success): ?>
									Congratulations! You have successfully <?php echo e($type); ?> your membership to <strong>"<?php echo e($plan->title); ?>"</strong>.
									<?php if(isset($payment)): ?>
										<br/><br/>
										<strong>Your New Subscription Details:</strong><br/>
										Membership Plan: <?php echo e($plan->title); ?><br/>
										Subscription Id: <?php echo e($payment->subscription_id); ?><br/>
										Monthly Recurring Payment: $<?php echo e(number_format($payment->amount,2)); ?>

									<?php endif; ?>
								<?php else: ?>
									<?php echo e($message); ?>

								<?php endif; ?>
							</div>
							<div class="col-md-1"></div>
						</div>
						
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>						
						