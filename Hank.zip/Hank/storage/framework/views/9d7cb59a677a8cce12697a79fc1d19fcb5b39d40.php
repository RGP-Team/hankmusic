<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 dashboard-section">
				
				<!-- start of content -->
				
				<div class="row">
					<div class="col-md-12">
						<!-- partials -->
						<?php echo $__env->make('pages.partials._navsections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- partials -->
						<div class="row">
							<div class="col-md-12">
								<div class="sub-topic-label">
									<h4><?php echo e(CustomHelper::lang('lang-your-photos')); ?></h4>
								</div>
							</div>
						</div>
						<?php if(session()->has('success_message')): ?>
							<div class="alert alert-success save-message">
								<?php echo e(session()->get('success_message')); ?>

							</div>
						<?php endif; ?>
						<?php if($errors->has('content') || session()->has('error_message')): ?>
							<div class="alert alert-danger save-message">
								<?php if(session()->has('error_message')): ?>
									<?php echo e(session()->get('error_message')); ?>

								<?php else: ?>
									<?php echo e($errors->first('content')); ?>

								<?php endif; ?>
							</div>
						<?php endif; ?>
						<div class="row">
							<div class="col-md-12 top-margin-20">
								<?php ($info = CustomHelper::checkPageLimit()); ?>
								<?php if((int)$info['remaining_slot'] !== 0): ?>
									<?php echo Form::open(array('route' => 'photos.upload', 'method' => 'POST', 'id' => 'gallery-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

										<button id="gallery-upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> <?php echo e(CustomHelper::lang('lang-upload-picture')); ?></button>
										<div id="img-thumb-preview">
										  <span class="processing-msg" style="display:none;">Processing, please wait...</span>
										</div>
									<?php echo Form::close(); ?>

								<?php endif; ?>
							</div>
						</div>
						<div class="row gallery-container">
							<div class="col-md-12">
								<div class="row gallery min-height-200">
								<?php if($photos->count()): ?>
									<?php foreach($photos as $photo): ?>
									<div class="col-md-2 text-center">
										<div class="gallery-item bg-primary">
											<a href="<?php echo e($photo->url); ?>"><img class="img-responsive" src="<?php echo e($photo->url); ?>" border="0" /></a>
										</div>
										<i class="fa fa-trash-o delete-photo" onclick="confirmDeletePhoto(<?php echo e($photo->id); ?>)" title="Delete Photo"></i>
									</div>
									<?php endforeach; ?>
								<?php else: ?>
									<div class="col-md-12 text-center top-margin-30">
										<?php echo e(CustomHelper::lang('lang-no-items-found')); ?>

									</div>
								<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?php echo e($photos->links()); ?>

							</div>
						</div>
												
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>