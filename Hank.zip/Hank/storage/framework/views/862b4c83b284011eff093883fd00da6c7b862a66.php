<?php if(count($data->collection)): ?>
	<table id="datatable" data-entity="<?php echo e($data->entity); ?>" class="table table-striped table-bordered">
	  <thead>
		<tr>
		  <?php foreach($data->headers as $header): ?>
			<?php ($label = $header); ?>
			<?php if($label === 'active'): ?>
				<?php ($label = 'status'); ?>	
			<?php endif; ?>
			<?php if($header === 'comment_id'): ?>
				<th>In Response To Comment</th>
			<?php else: ?>
				<?php if($header === 'created_dt'): ?>
					<th>Submitted On</th>
				<?php else: ?>
					<?php if($header === 'user_id'): ?>
						<th>User</th>
					<?php else: ?>
						<?php if(($header === 'entity_id') && ($data->entity === 'approvals')): ?>
							<th>Video Title</th>
						<?php else: ?>
							<th><?php echo e(ucwords(str_replace('_', ' ', $label))); ?></th>
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>
		  <?php endforeach; ?>
		  <?php if(! in_array($data->entity, array('approvals', 'subscribers'))): ?>
		  <th id="action" width="10%">Action</th>
		  <?php endif; ?>
		</tr>
	  </thead>
	  <tbody ng-model="listings">
		<?php foreach($data->collection as $item): ?>
			<?php ($json = json_decode($item)); ?>
			<tr class="table-row" data-id="<?php echo e($item->id); ?>" data-entity="<?php echo e($data->entity); ?>">
				<?php foreach($data->headers as $header): ?>
					<?php ($content = $item[$header]); ?>
					<?php if($header === 'active'): ?>
						<?php ($content = ((bool)$item[$header]) ? 'Active' : 'Inactive'); ?>	
					<?php endif; ?>
					<?php if($header === 'posts'): ?>
						<td><?php echo e($item->posts->count()); ?></td>
					<?php else: ?>
						<?php if($header === 'category'): ?>
							<td><?php echo e($item->category->parent->name); ?></td>
						<?php else: ?>
							<?php if($header === 'topic'): ?>
								<td><?php echo e($item->category->name); ?></td>
							<?php else: ?>
								<?php if($header === 'topics'): ?>
									<td><?php echo e($item->topics->count()); ?></td>
								<?php else: ?>
									<?php if($header === 'comments'): ?>
										<td><?php echo e($item->comments->count()); ?></td>
									<?php else: ?>
										<?php if($header === 'user_id'): ?>
											<td><?php echo e($item->user->first_name); ?> <?php echo e($item->user->last_name); ?></td>
										<?php else: ?>
											<?php if(($header === 'entity_id') && ($data->entity === 'approvals')): ?>
												<td><?php echo e($item->video->title); ?></td>
											<?php else: ?>
												<?php if($header === 'created_dt'): ?>
													<td><?php echo e(date("M. d, Y", strtotime($content))); ?> &nbsp;at <?php echo e(date("g:i A", strtotime($content))); ?></td>
												<?php else: ?>
													<td><?php echo e($content); ?></td>
												<?php endif; ?>
											<?php endif; ?>
										<?php endif; ?>
									<?php endif; ?>
								<?php endif; ?>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endforeach; ?>
				<?php if(! in_array($data->entity, array('approvals', 'subscribers'))): ?>
					<td align="center" class="action-item">
					<?php ($hide = false); ?>
					<?php if((int)$item->id == 1 && $data->entity === 'admins'): ?>
						<?php ($hide = true); ?>
					<?php endif; ?>
					<?php if(! $hide): ?>
						<a href="javascript://" class="action-button" data-action="delete" data-id="<?php echo e($item->id); ?>" data-entity="<?php echo e($data->entity); ?>"><i class="fa fa-trash-o action-icons"></i> Delete</a>
					<?php endif; ?>	
					</td>
				<?php endif; ?>
			</tr>
		<?php endforeach; ?>
	  </tbody>
	</table>	
<?php else: ?>
	<div class="no-items-found top-margin-30 text-center">
		There are currently no items found in this section.
	</div>
<?php endif; ?>