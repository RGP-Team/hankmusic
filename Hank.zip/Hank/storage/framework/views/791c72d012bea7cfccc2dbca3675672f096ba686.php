<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-40">
								<div class="col-md-12"><h3>Writer's Requests<br/><small>Click record or request to preview writer's sample articles</small></h3></div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-12">																						
											<!-- Requests -->
																						
											<div class="row">
												<div class="col-md-12">
													<?php echo $__env->make('admin.includes.table-only', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
												</div>
											</div>
																															
											<!-- /Requests -->
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>