<div class="container-fluid">  
	<div class="row">
		<div class="col-lg-12">
			<?php echo $__env->make('admin.includes.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div> 