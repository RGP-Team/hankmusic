<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-40">
								<div class="col-md-12">
									<h3>Multi-language<br/><small>If no entries are found on the choosen language, it will fall back to English (en).</small></h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>	
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-12">
											
											<div class="row">
												<div class="col-md-3">Keyword</div>
												<div class="col-md-3">English (en/eng)</div>
												<div class="col-md-3">Spanish (es/spa)</div>
												<div class="col-md-3">Chinese (zh/chi)</div>
											</div>
											
											<?php echo Form::open(array('route' => 'admin.languages.save', 'method' => 'POST', 'id' => 'language-form')); ?>

												<?php foreach( $data->languages as $lang ): ?>
													<div class="row top-margin-5">
														<div class="col-md-3">
														<?php echo e($lang->keyword); ?>

														</div>
														<div class="col-md-3">
															<input type="text" name="language[<?php echo e($lang->id); ?>][en]" value="<?php echo e($lang->en); ?>" class="form-control">
														</div>
														<div class="col-md-3">
															<input type="text" name="language[<?php echo e($lang->id); ?>][es]" value="<?php echo e($lang->es); ?>" class="form-control">
														</div>
														<div class="col-md-3">
															<input type="text" name="language[<?php echo e($lang->id); ?>][zh]" value="<?php echo e($lang->zh); ?>" class="form-control">
														</div>
													</div>
													<?php endforeach; ?>
												<div class="row">
													<div class="col-md-12 top-margin-30">
														<button class="btn btn-primary">Save Languages</button>
													</div>
												</div>
											<?php echo Form::close(); ?>

											
											
											<!--<table class="col-md-12">
											<thead>
												<tr>
													<th colspan="2">English (en/eng)</th>
													<th colspan="2">Spanish (es/spa)</th>
													<th colspan="2">Chinese (zh/chi)</th>
												</tr>
											</thead>
											<tbody ng-model="listings">
												<tr>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
												</tr>	
												<tr><td height="10"></td></tr>
												<tr>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
												</tr>	
												<tr><td height="10"></td></tr>
												<tr>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
												</tr>	
												<tr><td height="10"></td></tr>
												<tr>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
													<td width="10"></td>
													<td><input type="text" class="form-control"></td>
												</tr>	
											</tbody>
											</table>
											//-->
											
											
											
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>