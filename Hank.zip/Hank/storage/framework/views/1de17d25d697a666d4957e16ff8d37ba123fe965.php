<!-- Services Section -->
<section>
    <div class="container">
		<?php if(session()->has('success_message')): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('success_message')); ?>

			</div>
		<?php endif; ?>
		<?php if(count($errors->all())): ?>
			<div class="alert alert-danger">
				<ul>
				<?php foreach($errors->all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
				</ul>
			</div>
		<?php else: ?>
			<?php if(session()->has('error_message')): ?>
			<div class="alert alert-danger">
				<?php echo e(session()->get('error_message')); ?>

			</div>
			<?php endif; ?>
		<?php endif; ?>
		<div class="row">
			<div class="col-md-12">		
				<!-- start of content -->

					
					This is home content

				<!-- end of content -->
			</div>
		</div>
    </div>
</section>