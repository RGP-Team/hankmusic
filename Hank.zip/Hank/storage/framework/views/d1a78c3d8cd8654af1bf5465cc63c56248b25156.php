<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">
									<h3>Comment<br/><small>You are only allowed to activate or deactivate comment in this area</small></h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-8 form">
											

											<!-- Comment -->
														
											<?php echo Form::open(array('route' => 'admin.comments.save', 'method' => 'POST', 'id' => 'comment-form')); ?>

											<?php if(isset($data->info)): ?>
												<input type="hidden" name="comment_id" value="<?php echo e($data->info->id); ?>">
											<?php endif; ?>
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Message</label>
												<div class="col-sm-9">
													<?php echo e($data->info->message); ?>

												</div>
											</div>
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Down Votes</label>
												<div class="col-sm-9">
													<?php echo e($data->info->down_votes); ?>

												</div>
											</div>
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Up Votes</label>
												<div class="col-sm-9">
													<?php echo e($data->info->up_votes); ?>

												</div>
											</div>
											<fieldset class="form-group row">
											  <label class="col-sm-3">Status</label>
											  <div class="col-sm-9">
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="status" value="1" checked>
													Active
												  </label>
												</div>
												<div class="form-check">
												  <label class="form-check-label">
													<?php if(isset($data->info) && (! $data->info->active)): ?>
														<input class="form-check-input" type="radio" name="status" value="0" checked>
													<?php else: ?>
														<input class="form-check-input" type="radio" name="status" value="0">
													<?php endif; ?>
													Inactive
												  </label>
												</div>
											  </div>
											</fieldset>
											<div class="row">
												<div class="col-md-12 top-margin-20">
													<button class="btn btn-primary">Save Comment</button>
												</div>
											</div>
											<?php echo Form::close(); ?>										
											
											<!-- /Comment -->
											
											
											
											
											
										</div>
										<div class="col-md-1"></div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>