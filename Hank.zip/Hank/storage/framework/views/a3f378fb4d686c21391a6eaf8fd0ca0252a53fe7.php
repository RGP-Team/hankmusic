Hello <?php echo e($user->name); ?>


This is just a test email....


Thanks.