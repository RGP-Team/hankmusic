<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10">
				
				<!-- start of content -->
				<?php if(session()->has('success_message')): ?>
					<div class="alert alert-success">
						<?php echo e(session()->get('success_message')); ?>

					</div>
				<?php endif; ?>
				<?php if(count($errors->all())): ?>
					<div class="alert alert-danger">
						<ul>
						<?php foreach($errors->all() as $error): ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; ?>
						</ul>
					</div>
				<?php else: ?>
					<?php if(session()->has('error_message')): ?>
					<div class="alert alert-danger">
						<?php echo e(session()->get('error_message')); ?>

					</div>
					<?php endif; ?>
				<?php endif; ?>
				
				<div class="row home-row">
					<div class="col-md-12 pad-bottom">
						<?php if($data->banner945x106): ?>
							<img src="<?php echo e($data->banner945x106->url); ?>" class="img-responsive max945x106" />
						<?php else: ?>
							<div class="ad-background"><?php echo e(CustomHelper::lang('lang-ad-goes-here')); ?></div>
						<?php endif; ?>
					</div>
					<div class="col-md-12">
						<div class="col-md-8">
							<div class="row">
								<div class="col-md-12 no-pad pad-bottom">
									<?php if($data->banner630x350): ?>
										<img src="<?php echo e($data->banner630x350->url); ?>" class="img-responsive max630x350" />
									<?php else: ?>
										<img src="<?php echo e(URL::asset('images/SCG-HOME_06.jpg')); ?>" class="img-responsive" border="0" />
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-5 article">
									<div class="row">
										<div class="col-md-12 no-pad pad-right pad-bottom">
											
											<div class="container-lightgray">
												
												<h4 class="title-content"><?php echo e(CustomHelper::lang('lang-freelancers')); ?> <a href="<?php echo e(url('/freelancers')); ?>" class="show-all-links"><?php echo e(CustomHelper::lang('lang-show-all')); ?></a></h4> 
												<?php if($data->featured_freelancer->count()): ?>
													<?php ($freelancer = $data->featured_freelancer[0]); ?>
													<?php if($freelancer): ?>
													<div class="featured-freelancer">
														<?php if($freelancer->photo): ?>
															<?php ($profile_photo = $freelancer->photo->url); ?>
															<img src="<?php echo e($profile_photo); ?>" class="img-maxwidth">
														<?php else: ?>
															<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" class="img-maxwidth">
														<?php endif; ?>
														<div class="freelancer-name font-medium"><a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($freelancer->id); ?>"><strong><?php echo e($freelancer->first_name); ?> <?php echo e($freelancer->last_name); ?></strong></a> <span class="comment-count indent-left bold"><?php echo e($freelancer->artworks->count()); ?></span></div>
														<p class="font-medium">
														<?php echo nl2br(e($freelancer->description)); ?>

														</p>
													</div>
													<?php endif; ?>
												<?php endif; ?>
												<button class="more-button" onclick="location.href='<?php echo e(url('/freelancers')); ?>'"><?php echo e(CustomHelper::lang('lang-more-freelancers')); ?></button>
											</div>
											
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 no-pad pad-right">
											
											<div class="container-lightgray articles-content">
												<h4 class="title-content"><?php echo e(CustomHelper::lang('lang-latest-articles')); ?></h4> 
												<ul class="font-small">
													<?php if($data->latest_articles->count()): ?>
														<?php foreach($data->latest_articles as $article): ?>
														<li class="pad-bottom">
															<div>
																<?php ($content = strip_tags($article->content)); ?>
																<?php if(strlen($content) > 150): ?>
																	<?php ($content = substr($content, 0, 150) . '...'); ?>
																<?php endif; ?>
																
																<?php echo nl2br(e($content)); ?>

															</div>
															<a href="<?php echo e(url('/articles/view')); ?>/<?php echo e($article->id); ?>" class="more-info-links"><i class="fa fa-angle-double-right"></i> <?php echo e(CustomHelper::lang('lang-read-more')); ?></a>
														</li>
														<?php endforeach; ?>
													<?php else: ?>
														<li class="pad-bottom">
															<?php echo e(CustomHelper::lang('lang-no-articles-available')); ?>.
														</li>
													<?php endif; ?>
												</ul>
												<button class="more-button" onclick="location.href='<?php echo e(url('/all/articles')); ?>'"><?php echo e(CustomHelper::lang('lang-read-more')); ?></button>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-md-7">
									<div class="row">
										<div class="col-md-12 no-pad pad-bottom">
											<?php if(! empty($data)): ?>
											<h4 class="title-content"><?php echo e(CustomHelper::lang($data->topic->id, true)); ?></h4> 
											<?php endif; ?>
											
											<?php if($data->banner368x256): ?>
												<img src="<?php echo e($data->banner368x256->url); ?>" class="img-responsive max368x256" />
											<?php else: ?>
												<img src="<?php echo e(URL::asset('images/SCG-HOME_14.jpg')); ?>" class="img-responsive" border="0" />
											<?php endif; ?>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 no-pad article">
											
											<div class="container-lightgray">
												<?php if($data->latest_posts->count()): ?>
													<?php foreach($data->latest_posts as $post): ?>
														<div class="row pad-bottom-light">
															<div class="col-md-4">
																<a href="<?php echo e(url('/topics')); ?>/<?php echo e($data->topic->slug); ?>#p<?php echo e($post->id); ?>">
																<?php if($post->photos->count()): ?>
																	<?php ($photo = $post->photos[0]); ?>
																	<img class="img-responsive latest-post-item" src="<?php echo e($photo->photo->url); ?>" border="0" />
																<?php else: ?>
																	<img class="img-responsive latest-post-item" src="<?php echo e(URL::asset('images/no-image.png')); ?>" border="0" />
																<?php endif; ?>
																</a>
															</div>
															<?php ($content = explode('.', $post->content)); ?>
															<div class="col-md-8 no-pad-left">
																<div class="article-title"><a href="<?php echo e(url('/topics')); ?>/<?php echo e($data->topic->slug); ?>#p<?php echo e($post->id); ?>"><b><?php echo e($content[0].'.'); ?></b></a> <span class="comment-count"><i class="fa fa-comment-o"></i> <?php echo e($post->comments->count()); ?></span>
																<span class="topic-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($post->created_dt))); ?></span>
																</div>
																<p class="article-short-desc">
																	<?php if(! empty($content[1])): ?>
																		<?php echo e($content[1].'.'); ?> <?php if(! empty($content[2])): ?> <?php echo e($content[2].'.'); ?> <?php endif; ?>
																	<?php else: ?>
																		<?php echo e($content[0].'.'); ?>

																	<?php endif; ?>
																</p>
															</div>
														</div>
													<?php endforeach; ?>
													
													<div class="row">
														<div class="col-md-12">
															<button type="button" class="more-button" onclick="location.href='<?php echo e(url('/topics')); ?>/<?php echo e($data->topic->slug); ?>'"><?php echo e(CustomHelper::lang('lang-read-more')); ?></button>
														</div>
													</div>
												<?php else: ?>
													<div class="row">
														<div class="col-md-12 no-postings-found">
															<?php echo e(CustomHelper::lang('lang-no-postings-discussions')); ?>, <a href="<?php echo e(url('/topics')); ?>/<?php echo e($data->topic->slug); ?>"><?php echo e(CustomHelper::lang('lang-click-here')); ?></a>.
														</div>
													</div>
												<?php endif; ?>
											
												
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="row">
								<div class="col-md-12 no-pad pad-left article pad-bottom">
								
									<div class="container-lightgray">
										
										<div class="row">
											<div class="col-md-12">
												<h4 class="headline"><?php echo e(CustomHelper::lang('lang-trending-topics')); ?></h4> 
											</div>
										</div>
										<div class="row">
											<div class="col-md-12">
												<?php if($data->trending_topics->count()): ?>
													<?php foreach($data->trending_topics as $post): ?>
														<?php if($post->comments->count()): ?>
														<div class="row pad-bottom-light">
															<div class="col-md-4">
																<a href="<?php echo e(url('/topics')); ?>/<?php echo e($post->category->parent->slug); ?>#p<?php echo e($post->id); ?>">
																<?php if($post->photos->count()): ?>
																	<?php ($photo = $post->photos[0]); ?>
																	<img class="img-responsive latest-post-item" src="<?php echo e($photo->photo->url); ?>" border="0" />
																<?php else: ?>
																	<img class="img-responsive latest-post-item" src="<?php echo e(URL::asset('images/no-image.png')); ?>" border="0" />
																<?php endif; ?>
																</a>
															</div>
															<?php ($content = explode('.', $post->content)); ?>
															<div class="col-md-8 no-pad-left">
																<div class="article-title"><a href="<?php echo e(url('/topics')); ?>/<?php echo e($post->category->parent->slug); ?>#p<?php echo e($post->id); ?>"><b><?php echo e($content[0].'.'); ?></b></a> <span class="comment-count"><i class="fa fa-comment-o"></i> <?php echo e(CustomHelper::totalComments($post->category->id)); ?></span>
																<span class="topic-hour posted-date"><?php echo e(CustomHelper::lang('lang-posted-on')); ?> <?php echo e(date('m/d/Y', strtotime($post->created_dt))); ?></span>
																</div>
																<p class="article-short-desc">
																	<?php if(! empty($content[1])): ?>
																		<?php echo e($content[1].'.'); ?> <?php if(! empty($content[2])): ?> <?php echo e($content[2].'.'); ?> <?php endif; ?>
																	<?php else: ?>
																		<?php echo e($content[0].'.'); ?>

																	<?php endif; ?>
																</p>
															</div>
														</div>
														<?php endif; ?>
													<?php endforeach; ?>
													
												<?php else: ?>
													<div class="row">
														<div class="col-md-12 no-postings-found">
															There are currently no postings available.
														</div>
													</div>
												<?php endif; ?>
											</div>
										</div>
									
									</div>
								
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 no-pad pad-left article pad-bottom">
								
									<div class="container-lightgray">
										
										<div class="row">
											<div class="col-md-12">
												<h4 class="headline"><?php echo e(CustomHelper::lang('lang-popular-videos')); ?> <a href="<?php echo e(url('/all/videos')); ?>" class="show-all-links"><?php echo e(CustomHelper::lang('lang-show-all-videos')); ?></a></h4> 
											</div>
										</div>
										<div class="row pad-right font-xsmall home-videos videos-container">
											<?php if($data->popular_videos->count()): ?>
												<?php foreach($data->popular_videos as $video): ?>
													<div class="col-md-4 text-center no-pad-right videos">
														<?php ($video_title = $video->title); ?>
														<?php if(strlen($video->title) > 30): ?>
															<?php ($video_title = substr($video->title, 0, 30) . '...'); ?>
														<?php endif; ?>
														<a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>"><img src="<?php echo e(URL::asset('images/play-video.png')); ?>" class="img-responsive" border="0" /></a>
														<div class="popular-name"><a href="<?php echo e($video->embed_url); ?>" data-id="<?php echo e($video->id); ?>" title="<?php echo e($video->title); ?>"><?php echo e($video_title); ?></a></div>
														<div class="popular-date"><?php echo e($video->views); ?> <?php echo e(CustomHelper::lang('lang-views')); ?></div>
													</div>	
												<?php endforeach; ?>
											<?php else: ?>
												<div class="col-md-12 text-center">
													No videos available.
												</div>
											<?php endif; ?>
										
								
										</div>
										<div class="row">
											<div class="col-md-12">
												<button class="more-button" onclick="location.href='<?php echo e(url('/all/videos')); ?>'"><?php echo e(CustomHelper::lang('lang-videos')); ?></button>
											</div>
										</div>
									
									</div>
								
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 no-pad pad-left pad-bottom">
									
									
									<div class="container-lightgray article top-users">
										<div class="row">
											<div class="col-md-12">
												<h4 class="heading"><?php echo e(CustomHelper::lang('lang-top-users')); ?></h4>
											</div>
										</div>
										
										<?php if($data->top_users->count()): ?>
											<?php foreach($data->top_users as $user): ?>
												<?php if($user->comments->count() > 0): ?>
												<div class="row font-small pad-bottom-light">
													<div class="col-md-4">
														<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" class="img-responsive" align="left" border="0" />
													</div>
													<div class="col-md-8 no-pad-left">
														<div class="user-name">
															<strong><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></strong> <span class="comment-count"><i class="fa fa-comment-o"></i> <?php echo e($user->comments->count()); ?></span>
														</div>
													</div>
												</div>
												<?php endif; ?>
											<?php endforeach; ?>
										<?php endif; ?>
						
											
										<div class="row">
											<div class="col-md-12">
												<button class="more-button" onclick="location.href='<?php echo e(url('/freelancers')); ?>'"><?php echo e(CustomHelper::lang('lang-more-freelancers')); ?></button>
											</div>
										</div>
									</div>
									
									
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 no-pad pad-left">
									<?php if($data->banner300x106): ?>
										<img src="<?php echo e($data->banner300x106->url); ?>" class="img-responsive max300x106" />
									<?php else: ?>
										<div class="ad-background"><?php echo e(CustomHelper::lang('lang-ad-goes-here')); ?></div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>