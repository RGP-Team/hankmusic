<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">
									<h3>Post</h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-8 form">
											

											<!-- General -->
														
											<?php echo Form::open(array('route' => 'admin.posts.save', 'method' => 'POST', 'id' => 'post-form')); ?>

											<input type="hidden" name="photo">
											<?php if(isset($data->info)): ?>
												<input type="hidden" name="post_id" value="<?php echo e($data->info->id); ?>">
											<?php endif; ?>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Category *</label>
											  <div class="col-sm-9">
												<select id="post-category" name="category" class="form-control">
												  <option value="">-- Choose category</option>
												  <?php if(isset($data)): ?>
													<?php foreach($data->categories as $category): ?>
														<?php ($selected = ''); ?>
														<?php if(isset($data->info)): ?>
															<?php if((int)$data->info->category->parent->id === (int)$category->id): ?>
																<?php ($selected = 'selected'); ?>
															<?php endif; ?>
														<?php endif; ?>
														
														<option value="<?php echo e($category->id); ?>" <?php echo e($selected); ?>><?php echo e($category->name); ?></option>
													<?php endforeach; ?>
												  <?php endif; ?>
												</select>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Sub Topic *</label>
											  <div class="col-sm-9">
												<select id="post-topics" name="topic" class="form-control">
												  <option value="">-- Choose sub-topic</option>
												  <?php if(isset($data->info)): ?>													
													<?php foreach($data->topics as $topic): ?>
														<?php ($selected = ''); ?>
														<?php if((int)$data->info->category->id === (int)$topic->id): ?>
															<?php ($selected = 'selected'); ?>
														<?php endif; ?>
														
														<option value="<?php echo e($topic->id); ?>" <?php echo e($selected); ?>><?php echo e($topic->name); ?></option>
													<?php endforeach; ?>
												  <?php endif; ?>
												</select>
												<div id="post-spinner"></div>
											  </div>
											</div>											
											<div class="form-group row">
												<label class="col-sm-3 col-form-label">Post Content *</label>
												<div class="col-sm-9">
													<textarea class="form-control" name="content" rows="7" placeholder="Your post content here..."><?php if(isset($data->info)): ?><?php echo e($data->info->content); ?><?php endif; ?></textarea>
												</div>
											</div>
											<fieldset class="form-group row">
											  <label class="col-sm-3">Status</label>
											  <div class="col-sm-9">
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="status" value="1" checked>
													Active
												  </label>
												</div>
												<div class="form-check">
												  <label class="form-check-label">
													<?php if(isset($data->info) && (! $data->info->active)): ?>
														<input class="form-check-input" type="radio" name="status" value="0" checked>
													<?php else: ?>
														<input class="form-check-input" type="radio" name="status" value="0">
													<?php endif; ?>
													Inactive
												  </label>
												</div>
											  </div>
											</fieldset>
											<?php if(isset($data->info)): ?>
												<?php if($data->info->photos->count()): ?>
													<div class="form-group row">
														<label class="col-sm-3 col-form-label">Photos</label>
														<div class="col-sm-9">
															<?php foreach($data->info->photos as $photo): ?>
																<div class="col-md-4 text-center">
																	<img src="<?php echo e($photo->photo->url); ?>" class="img-responsive">
																	<?php if($photo->post->comments->count() === 0): ?>
																	<br/><a href="<?php echo e(url('/admin')); ?>/photos/delete/<?php echo e($photo->id); ?>">Remove</a><br/>
																	<?php endif; ?>
																</div>
															<?php endforeach; ?>
														</div>
													</div>
												<?php endif; ?>
											<?php endif; ?>
											<?php echo Form::close(); ?>


											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Attach Image</label>
											  <div class="col-sm-9">
												
													<?php echo Form::open(array('route' => 'admin.photos.upload', 'method' => 'POST', 'id' => 'photo-dropzone', 'class' => 'form single-dropzone', 'files' => true)); ?>

														<button id="upload-submit" class="btn btn-default margin-t-5"><i class="fa fa-upload"></i> Upload Image</button>
														<div id="img-thumb-preview" class="noshow">
														  <span class="processing-msg" style="display:none;">Processing, please wait...</span>
														  <div class="img-thumbnail">
															<img id="img-thumb" class="user size-lg img-responsive photo-select" src="">
														  </div>
														</div>
													<?php echo Form::close(); ?>

												
											  </div>
											</div>												
											<div class="row">
												<div class="col-md-12 top-margin-20">
													<button onclick="jQuery('#post-form').get(0).submit()" class="btn btn-primary">Save Post</button>
												</div>
											</div>
											
											<!-- /General -->
											
											
											
											
											
										</div>
										<div class="col-md-1"></div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>