<?php ($url = url('/articles/view').'/'.$article->id); ?>
<ul class="share-buttons">
  <li>
	<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>&t=<?php echo e(urlencode($article->title)); ?>" title="Share on Facebook" target="_blank">
		<img alt="Share on Facebook" src="<?php echo e(URL::asset('images/Facebook.png')); ?>">
	</a>
  </li>
  <li>
	<a href="https://twitter.com/intent/tweet?source=<?php echo e($url); ?>&text=<?php echo e(urlencode($article->title)); ?>:%20<?php echo e($url); ?>" target="_blank" title="Tweet">
		<img alt="Tweet" src="<?php echo e(URL::asset('images/Twitter.png')); ?>">
	</a>
  </li>
  <li>
	<a href="https://plus.google.com/share?url=<?php echo e($url); ?>" target="_blank" title="Share on Google+">
		<img alt="Share on Google+" src="<?php echo e(URL::asset('images/GooglePlus.png')); ?>">
	</a>
  </li>
  <li>
	<a href="http://pinterest.com/pin/create/button/?url=<?php echo e($url); ?>&description=<?php echo e(urlencode($article->title)); ?>" target="_blank" title="Pin it">
		<img alt="Pin it" src="<?php echo e(URL::asset('images/Pinterest.png')); ?>">
	</a>
  </li>
  <li>
	<a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo e($url); ?>&title=<?php echo e(urlencode($article->title)); ?>&summary=CG%20Network%20Article&source=<?php echo e($url); ?>" target="_blank" title="Share on LinkedIn">
		<img alt="Share on LinkedIn" src="<?php echo e(URL::asset('images/LinkedIn.png')); ?>">
	</a>
  </li>
</ul>