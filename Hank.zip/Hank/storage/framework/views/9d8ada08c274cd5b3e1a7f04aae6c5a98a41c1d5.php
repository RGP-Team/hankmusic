<!-- Services Section -->
<section>
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 search-results">
				<!-- start of content -->
				<div class="row">
					<div class="col-md-12 search-preview">
						<div class="row">
							<div class="col-md-12 bottom-margin-30">
								<div class="search-title">
									<h3><?php echo e(CustomHelper::lang('lang-freelancers')); ?><br/>
									<small><?php echo e(CustomHelper::lang('lang-freelancer-notes')); ?></small>
									</h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 min-height-300 top-margin-20">
								<div class="row search-results-list">
									<input type="hidden" name="search-csrf" value="<?php echo e(csrf_token()); ?>">
									<?php if($freelancers->count()): ?>
										<?php foreach($freelancers as $user): ?>
											<div class="col-md-6 search-item user-profile text-left">
												<div class="col-md-3">
													<?php if($user->photo): ?>
														<?php ($profile_photo = $user->photo->url); ?>
														<img src="<?php echo e($profile_photo); ?>" alt="">
													<?php else: ?>
														<img src="<?php echo e(URL::asset('images/no-image-profile.jpg')); ?>" alt="">
													<?php endif; ?>
												</div>
												<div class="col-md-9">
													<a href="<?php echo e(url('/user/profile')); ?>/<?php echo e($user->id); ?>"><h3 class="profile-name"><?php echo e(ucwords($user->first_name)); ?> <?php echo e(ucwords($user->last_name)); ?></h3></a>
													<small class="member"><?php echo e(CustomHelper::lang('lang-member-since')); ?> <?php echo e(CustomHelper::show_elapsed_time($user->created_at)); ?></small><br/>									
													<small class="address">
													<?php if(! empty($user->city)): ?><?php echo e($user->city); ?><?php endif; ?>
													<?php if(! empty($user->state)): ?><?php echo e(', '.$user->state); ?><?php endif; ?>
													<?php if(! empty($user->zip)): ?><?php echo e(' '.$user->zip); ?><?php endif; ?>
													<?php if(! empty($user->country)): ?><?php echo e(', '.$user->country); ?><?php endif; ?>
													</small>
													<?php if(! Auth::guest()): ?>
														<?php if($user->id !== Auth::user()->id): ?>
															<?php if(! CustomHelper::isFriendWith( $user->id, Auth::user()->id )): ?>
																<small>
																<?php if($user->pendingRequest): ?>
																	<span class="pending-request"> - Pending Friend Request - </span>
																<?php else: ?>
																	<button class="btn btn-primary btn-xs" data-url="<?php echo e(url('/friends/add/request')); ?>" data-id="<?php echo e($user->id); ?>" onclick="addFriend(this)"><i class="fa fa-user-plus"></i> &nbsp;Add as Friend</button><span class="loader"></span><span class="pending-request noshow"> - Pending Friend Request - </span>
																<?php endif; ?>
																</small>
															<?php else: ?>
																<small>
																	<input type="hidden" name="source_id" value="<?php echo e(Auth::user()->id); ?>" />
																	<input type="hidden" name="target_id" value="<?php echo e($user->id); ?>" />
																	<button type="button" onclick="sendMessage(this)" class="btn btn-primary btn-xs"><i class="fa fa-envelope-o"></i> &nbsp;Send a Message</button>
																</small>
															<?php endif; ?>
														<?php endif; ?>
													<?php endif; ?>
												</div>
											</div>
										<?php endforeach; ?>
									<?php else: ?>
										<div class="col-md-12 text-center top-margin-40">
											There are currently no freelancers registered on the site.
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>

				</div>
				<!-- end of content -->
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>						
						