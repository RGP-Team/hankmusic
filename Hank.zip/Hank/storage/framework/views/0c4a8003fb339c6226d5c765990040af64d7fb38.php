<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">								
									<h3>User</h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>									
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-8 form">
											

											<!-- General -->
														
											<?php echo Form::open(array('route' => 'admin.users.save', 'method' => 'POST', 'id' => 'user-form')); ?>

											<?php if(isset($data->info)): ?>
												<input type="hidden" name="user_id" value="<?php echo e($data->info->id); ?>">
											<?php endif; ?>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">First Name *</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="first_name" class="form-control" value="<?php echo e($data->info->first_name); ?>" placeholder="User first name here...">
												<?php else: ?>
													<input type="text" name="first_name" class="form-control" value="<?php echo e(old('first_name')); ?>" placeholder="User first name here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Last Name *</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="last_name" class="form-control" value="<?php echo e($data->info->last_name); ?>" placeholder="User last name here...">
												<?php else: ?>
													<input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name')); ?>" placeholder="User last name here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">E-mail Address *</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="email" name="email" class="form-control" value="<?php echo e($data->info->email); ?>" placeholder="User email address here...">
												<?php else: ?>
													<input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="User email address here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <legend>Location <small>(optional)</small></legend>
											  <label class="col-sm-3 col-form-label">Address</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="address" class="form-control" value="<?php echo e($data->info->address); ?>" placeholder="User address here...">
												<?php else: ?>
													<input type="text" name="address" class="form-control" value="<?php echo e(old('address')); ?>" placeholder="User address here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">City</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="city" class="form-control" value="<?php echo e($data->info->city); ?>" placeholder="User city here...">
												<?php else: ?>
													<input type="text" name="city" class="form-control" value="<?php echo e(old('city')); ?>" placeholder="User city here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">State</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="state" class="form-control" value="<?php echo e($data->info->state); ?>" placeholder="User state here...">
												<?php else: ?>
													<input type="text" name="state" class="form-control" value="<?php echo e(old('state')); ?>" placeholder="User state here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Zip</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="zip" class="form-control" value="<?php echo e($data->info->zip); ?>" placeholder="User zip here...">
												<?php else: ?>
													<input type="text" name="zip" class="form-control" value="<?php echo e(old('zip')); ?>" placeholder="User zip here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Country</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="country" class="form-control" value="<?php echo e($data->info->country); ?>" placeholder="User country here...">
												<?php else: ?>
													<input type="text" name="country" class="form-control" value="<?php echo e(old('country')); ?>" placeholder="User country here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <?php if(isset($data->info)): ?>
												<legend>Security<br/><small>Leave blank if you don't want to change the current password</small></legend>
												<label class="col-sm-3 col-form-label">Password</label>
											  <?php else: ?>
												<legend>Security</legend>
												<label class="col-sm-3 col-form-label">Password *</label>
											  <?php endif; ?>
											  <div class="col-sm-9">
												<input type="password" name="password" class="form-control" placeholder="Password">
											  </div>
											</div>
											<div class="form-group row">
											  <?php if(isset($data->info)): ?>
												<label class="col-sm-3 col-form-label">Confirm Password</label>
											  <?php else: ?>
												<label class="col-sm-3 col-form-label">Confirm Password *</label>
											  <?php endif; ?>
											  <div class="col-sm-9">
												<input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password">
											  </div>
											</div>	
											<div class="form-group row">
											  <legend>Keyword Tags</legend>
											  <label class="col-sm-3 col-form-label">Tags</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="tags" class="form-control" value="<?php echo e($data->info->tags); ?>" placeholder="User tags in comma separated values here...">
												<?php else: ?>
													<input type="text" name="tags" class="form-control" value="<?php echo e(old('tags')); ?>" placeholder="User tags in comma separated values here...">
												<?php endif; ?>
											  </div>
											</div>											
											<fieldset class="form-group row">
											  <legend>Status</legend>
											  <label class="col-sm-3">Status</label>
											  <div class="col-sm-9">
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="status" value="1" checked>
													Active
												  </label>
												</div>
												<div class="form-check">
												  <label class="form-check-label">
													<?php if(isset($data->info) && (! $data->info->active)): ?>
														<input class="form-check-input" type="radio" name="status" value="0" checked>
													<?php else: ?>
														<input class="form-check-input" type="radio" name="status" value="0">
													<?php endif; ?>
													Inactive
												  </label>
												</div>
											  </div>
											</fieldset>
											<div class="row">
												<div class="col-md-12 top-margin-20">
													<button class="btn btn-primary">Save User</button>
												</div>
											</div>
											<?php echo Form::close(); ?>

											
											<!-- /General -->
											
											
											
											
											
										</div>
										<div class="col-md-1"></div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>