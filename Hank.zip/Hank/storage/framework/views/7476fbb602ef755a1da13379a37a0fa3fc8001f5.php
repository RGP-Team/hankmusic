<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">  
		<div class="row">
			<div class="col-lg-12">
					
					
					<div class="row">
						<div class="col-md-12 admin-data-table bottom-margin-50">
							<div class="row bottom-margin-30">
								<div class="col-md-12">
									<h3>Site Administrator</h3>
									<?php if(session()->has('success_message')): ?>
										<div class="alert alert-success">
											<?php echo e(session()->get('success_message')); ?>

										</div>
									<?php endif; ?>
									<?php if(count($errors->all())): ?>
										<div class="alert alert-danger">
											<ul>
											<?php foreach($errors->all() as $error): ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; ?>
											</ul>
										</div>
									<?php else: ?>
										<?php if(session()->has('error_message')): ?>
										<div class="alert alert-danger">
											<?php echo e(session()->get('error_message')); ?>

										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
					
					
									<div class="row">
										<div class="col-md-8 form">
											

											<!-- General -->
														
											<?php echo Form::open(array('route' => 'admin.admins.save', 'method' => 'POST', 'id' => 'admin-form')); ?>

											<?php if(isset($data->info)): ?>
												<input type="hidden" name="admin_id" value="<?php echo e($data->info->id); ?>">
											<?php endif; ?>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">Name</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="text" name="name" class="form-control" value="<?php echo e($data->info->name); ?>" placeholder="Admin full name here...">
												<?php else: ?>
													<input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Admin full name here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <label class="col-sm-3 col-form-label">E-mail Address</label>
											  <div class="col-sm-9">
												<?php if(isset($data->info)): ?>
													<input type="email" name="email" class="form-control" value="<?php echo e($data->info->email); ?>" placeholder="Admin e-email address here...">
												<?php else: ?>
													<input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Admin e-email address here...">
												<?php endif; ?>
											  </div>
											</div>
											<div class="form-group row">
											  <?php if(isset($data->info)): ?>
												<legend>Security<br/><small>Leave blank if you don't want to change the current password</small></legend>
												<label class="col-sm-3 col-form-label">Password</label>
											  <?php else: ?>
												<legend>Security</legend>
												<label class="col-sm-3 col-form-label">Password *</label>
											  <?php endif; ?>
											  <div class="col-sm-9">
												<input type="password" name="password" class="form-control" placeholder="Password">
											  </div>
											</div>
											<div class="form-group row">
											  <?php if(isset($data->info)): ?>
												<label class="col-sm-3 col-form-label">Confirm Password</label>
											  <?php else: ?>
												<label class="col-sm-3 col-form-label">Confirm Password *</label>
											  <?php endif; ?>
											  <div class="col-sm-9">
												<input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password">
											  </div>
											</div>
											<?php ($disabled = ''); ?>
											<?php if(isset($data->info)): ?>
												<?php if((int)$data->info->id === 1): ?>
													<?php ($disabled = 'disabled'); ?>	
												<?php endif; ?>
											<?php endif; ?>
											<fieldset class="form-group row">
											  <legend>Status</legend>
											  <label class="col-sm-3">Status</label>
											  <div class="col-sm-9">
												<div class="form-check">
												  <label class="form-check-label">
													<input class="form-check-input" type="radio" name="status" value="1" checked <?php echo e($disabled); ?>>
													Active
												  </label>
												</div>
												<div class="form-check">
												  <label class="form-check-label">
													<?php if(isset($data->info) && (! $data->info->active)): ?>
														<input class="form-check-input" type="radio" name="status" value="0" checked <?php echo e($disabled); ?>>
													<?php else: ?>
														<input class="form-check-input" type="radio" name="status" value="0" <?php echo e($disabled); ?>>
													<?php endif; ?>
													Inactive
												  </label>
												</div>
											  </div>
											</fieldset>
											<div class="form-group row top-margin-30">
											  <legend class="col-sm-3 legend">Permissions</legend>
											  <div class="col-sm-9">
												
												
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_post)): ?>
															<input class="form-check-input" name="can_manage_post" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Posts"
														<?php else: ?>
															<input class="form-check-input" name="can_manage_post" type="checkbox" <?php echo e($disabled); ?>> Can manage "Posts"
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_user)): ?>
															<input class="form-check-input" name="can_manage_user" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Users"
														<?php else: ?>
															<input class="form-check-input" name="can_manage_user" type="checkbox" <?php echo e($disabled); ?>> Can manage "Users"
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_admin)): ?>
															<input class="form-check-input" name="can_manage_admin" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Site Administrators"
														<?php else: ?>
															<input class="form-check-input" name="can_manage_admin" type="checkbox" <?php echo e($disabled); ?>> Can manage "Site Administrators"
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_category)): ?>
															<input class="form-check-input" name="can_manage_category" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Categories"
														<?php else: ?>
															<input class="form-check-input" name="can_manage_category" type="checkbox" <?php echo e($disabled); ?>> Can manage "Categories"
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_approval)): ?>
															<input class="form-check-input" name="can_manage_approval" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Pending Approvals"
														<?php else: ?>
															<input class="form-check-input" name="can_manage_approval" type="checkbox" <?php echo e($disabled); ?>> Can manage "Pending Approvals"
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_authorizenet)): ?>
															<input class="form-check-input" name="can_manage_authorizenet" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Authorize.Net" setting
														<?php else: ?>
															<input class="form-check-input" name="can_manage_authorizenet" type="checkbox" <?php echo e($disabled); ?>> Can manage "Authorize.Net" setting
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												<div class="form-group row">
												  <div class="col-sm-12">
													<div class="form-check">
													  <label class="form-check-label">
														<?php if(isset($data->info) && ($data->info->can_manage_plan)): ?>
															<input class="form-check-input" name="can_manage_plan" type="checkbox" checked <?php echo e($disabled); ?>> Can manage "Subscription Plans"
														<?php else: ?>
															<input class="form-check-input" name="can_manage_plan" type="checkbox" <?php echo e($disabled); ?>> Can manage "Subscription Plans"
														<?php endif; ?>
													  </label>
													</div>
												  </div>
												</div>
												
																								
											  </div>
											</div>											
											<div class="row">
												<div class="col-md-12 top-margin-20">
													<button class="btn btn-primary">Save Admin</button>
												</div>
											</div>
											<?php echo Form::close(); ?>

											
											<!-- /General -->
											
											
											
											
											
										</div>
										<div class="col-md-1"></div>
										<div class="col-md-3">
											&nbsp;
										</div>
									</div>
									
									
								</div>
							</div>
						</div>
					</div>
					
				
			</div>
		</div>
	</div> 
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>