<?php 
	$categories = App\Models\Category::where('parent_id', 0)->get();
?>
<!-- Navigation -->
    <nav class="navbar navbar-default">	
        <div id="navbar-container" class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll hidden" href="#page-top">
					<img src="<?php echo e(URL::asset('images/logo-145.png')); ?>" alt="CG Networks Logo" border="0" />
				</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			
				<div id="nav" class="top-nav-container">
					<ul class="nav navbar-nav navbar-left">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li><a id="home-icon" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('images/home-20.png')); ?>" alt="Home" border="0" /></a></li>
						<li><a class="page-scroll" href="<?php echo e(url('/')); ?>"><?php echo e(CustomHelper::lang('lang-home')); ?></a></li>
						
						<?php foreach( $categories as $category ): ?>
							<li><a class="page-scroll" href="<?php echo e(url('/')); ?>/category/<?php echo e($category->slug); ?>"><?php echo e(CustomHelper::lang($category->id, true)); ?></a></li>
						<?php endforeach; ?>
						
						<li class="more"> <a href="javascript://">...</a>
							<div class="overflow-container">
							<ul id="overflow">
							</ul>
							</div>
						</li>
					</ul>
				</div>
				
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>