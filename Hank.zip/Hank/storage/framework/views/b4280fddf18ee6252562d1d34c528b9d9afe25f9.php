<html lang="en-US">
<head>
    <meta charset="text/html">
</head>
<body>
    <p><?php echo e(CustomHelper::lang('lang-hello')); ?> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>,</p>
	   <?php echo e(CustomHelper::lang('lang-email-verification-content')); ?><br/>
	   <a href="<?php echo e($url); ?>"><?php echo e($url); ?></a>
</body>
</html>