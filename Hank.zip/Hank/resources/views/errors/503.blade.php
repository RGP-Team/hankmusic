@extends('../layouts.main')

@section('content')
	@include('../pages.404')
@endsection