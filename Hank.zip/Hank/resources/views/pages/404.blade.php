<!-- Services Section -->
<section id="services">
    <div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10 min-height-200 text-center">
			
				<!-- start of content -->

				<h3>404 Error message here...</h3>

				<!-- end of content -->
				
			</div>
			<div class="col-md-1"></div>
		</div>
    </div>
</section>