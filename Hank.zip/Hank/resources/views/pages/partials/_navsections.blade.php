<div class="row">
	<div class="col-md-12">
		Navigation section here...
	</div>
</div>
<div class="row">
	<div class="col-md-12 spacer"></div>
</div>