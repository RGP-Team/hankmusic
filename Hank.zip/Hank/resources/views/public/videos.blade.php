@extends('layouts.main')

@section('content')
	@include('../pages/public_videos')
@endsection

