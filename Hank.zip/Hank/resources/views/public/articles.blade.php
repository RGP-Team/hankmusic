@extends('layouts.main')

@section('content')
	@include('../pages/public_articles')
@endsection

