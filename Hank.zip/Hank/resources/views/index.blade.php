@extends('layouts.main')

@section('content')
	@include('pages.home')
@endsection

